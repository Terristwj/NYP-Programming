package BookstoreApp.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ItemPageDialogueController {
	
	protected static String promptLabelText = "";
	
	@FXML
	private Button btnConfirm;
	
	@FXML
	private Label promptLabel;
	
	private Stage dialogStage;
	
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	
	@FXML
	void initialize() {
		promptLabel.setText(promptLabelText);           //Sets text and adjust the alignment
		if (promptLabelText.equals("Out of Stock!"))
			promptLabel.setLayoutX(205);
		if (promptLabelText.equals("Favourite is Full!"))
			promptLabel.setLayoutX(177);
		if (promptLabelText.equals("Not Enough Stock!"))
			promptLabel.setLayoutX(155);
	}
	
	@FXML
	private void handleConfirm() {
		dialogStage.close();
	}
}
