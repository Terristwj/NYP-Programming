﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class StorePayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewGridView();
            }
        }

        protected void ViewGridView()
        {
            string sqlCommand = "SELECT * FROM ShoppingItem si";
            sqlCommand += " INNER JOIN Products p ON si.Product_ID = p.Product_ID";
            sqlCommand += " WHERE custID = '" + Request.QueryString["custID"] + "'";

            BLL_Joins innerJoin = new BLL_Joins();
            DataSet ds = new DataSet();

            ds = innerJoin.getShoppingItems(sqlCommand);
            gv_Products.DataSource = ds;
            gv_Products.DataBind();

            if (Session["cardNumber"] != null)
            {
                lb_CardNumber.Text = Session["cardNumber"].ToString();

                if (lb_CardNumber.Text.Substring(0, 1).Equals("5"))
                {
                    img_Card.ImageUrl = "~/Images/Default/MasterCard.jpg";
                }
                else if (lb_CardNumber.Text.Substring(0, 1).Equals("4"))
                {
                    img_Card.ImageUrl = "~/Images/Default/VisaCard.png";
                }

                else if (lb_CardNumber.Text.Substring(0, 1).Equals("3"))
                {
                    img_Card.ImageUrl = "~/Images/Default/American Express.jpg";
                }

                else if (lb_CardNumber.Text.Substring(0, 4).Equals("6011") || lb_CardNumber.Text.Substring(0, 3).Equals("644") || lb_CardNumber.Text.Substring(0, 2).Equals("65"))
                {
                    img_Card.ImageUrl = "~/Images/Default/Discover.jpg";
                }

                Pnl_CreditCardNone.Style.Add("display", "none");
            }
            else
            {
                Pnl_CreditCard.Style.Add("display", "none");
            }


            sqlCommand = "SELECT sum(Unit_Price*Quantity) TotalPrice FROM ShoppingItem si";
            sqlCommand += " INNER JOIN Products p ON si.Product_ID = p.Product_ID";
            sqlCommand += " WHERE custID = '" + Request.QueryString["custID"] + "'";

            string totalPrice = innerJoin.getShoppingItemsTotalPrice(sqlCommand);

            lb_TotalPrice.Text = "$" + totalPrice;
            

            double gst_rate = 7;
            double gst_value = Convert.ToDouble(totalPrice) * (gst_rate / 100);

            lb_GST.Text = "$" + gst_value.ToString("0.00");


            double netPrice = Convert.ToDouble(totalPrice) + gst_value;

            lb_NetPrice.Text = "$" + netPrice.ToString("0.00");

            Random rand = new Random((int)DateTime.Now.Ticks);
            int numIterations = 0;
            numIterations = rand.Next(3, 10);

            lb_DeliveryDate.Text = DateTime.Now.AddDays(numIterations).ToShortDateString() + " 12.00pm - 1.00pm";

            BLL_Customer customer = new BLL_Customer();
            string address = customer.getCustAddress(Request.QueryString["custID"]);
            tb_Address.Text = address;
        }

        protected void btn_Confirm_Click(object sender, EventArgs e)
        {
            string custID = Request.QueryString["custID"];
            string totalPrice = Convert.ToDouble(lb_TotalPrice.Text.Substring(1, lb_TotalPrice.Text.Length - 1)).ToString();
            string netPrice = Convert.ToDouble(lb_NetPrice.Text.Substring(1, lb_NetPrice.Text.Length - 1)).ToString();
            string dateOfOrder = DateTime.Now.ToString();
            string deliveryDate = lb_DeliveryDate.Text;
            string deliveryAddress = tb_Address.Text;

            BLL_CustomerOrder order = new BLL_CustomerOrder();

            //Insert Customer Order
            order.insertCustomerOrder(custID, totalPrice, netPrice, dateOfOrder, deliveryDate, deliveryAddress);

            //Get orderID
            string orderID = order.getOrderID(custID, dateOfOrder);


            foreach (GridViewRow row in gv_Products.Rows)
            {
                Label productName = (Label)row.FindControl("Label1");
                string productNameStr = productName.Text;

                BLL_Product product = new BLL_Product();
                string product_ID = product.getProductID(productNameStr);
                string stock = product.getStock(product_ID);

                Label quantity = (Label)row.FindControl("lb_Qty");
                string quantityStr = quantity.Text;

                //Insert customer order item
                BLL_CustomerOrderItems coItems = new BLL_CustomerOrderItems();
                coItems.insertItem(orderID + "_" + product_ID, orderID, product_ID, quantityStr);


                string newStock = (Convert.ToInt32(stock) - Convert.ToInt32(quantityStr)).ToString();

                //Save new quantity of products into DB
                product.updateStock(newStock, product_ID);



                int reorderPoint = Convert.ToInt32(product.getReorderPoint(product_ID));
                int stocks = Convert.ToInt32(product.getStock(product_ID));

                if (stocks < reorderPoint)
                {
                    BLL_PurchaseOrder pOrder = new BLL_PurchaseOrder();
                    Boolean orderExist = pOrder.getOrderByProd(product_ID);

                    if (orderExist == true)
                    {
                        //Nothing
                    }
                    else   //Create PO since stock=0 and is new item
                    {
                        string dateOfOrder2 = DateTime.Now.ToString("dd/mm/yyyy");
                        int quantity2 = Convert.ToInt32(product.getReorderQuantity(product_ID));
                        string quantityStr2 = quantity2.ToString();

                        double unitPrice = product.getUnitPrice(product_ID);
                        string totalAmount = (quantity2 * unitPrice).ToString("0.00");

                        //Insert Order
                        pOrder = new BLL_PurchaseOrder();
                        pOrder.insertOrder(dateOfOrder2, product_ID, quantityStr2, totalAmount);
                    }
                }
            }


            //Reset cart from DB
            BLL_ShoppingItem shoppingItem = new BLL_ShoppingItem();
            shoppingItem.deleteAllItems(Request.QueryString["custID"]);


            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"] + "&orderID=" + orderID;
            Response.Redirect("~/CataloguePaymentComplete.aspx" + queryString);
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            Session.Remove("cardNumber");

            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/CatalogueShoppingCart.aspx" + queryString);
        }
    }
}