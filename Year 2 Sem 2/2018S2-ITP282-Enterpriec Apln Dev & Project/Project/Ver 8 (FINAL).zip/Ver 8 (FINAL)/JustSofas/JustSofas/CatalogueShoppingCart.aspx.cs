﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class CatalogueShoppingCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sqlCommand = "SELECT * FROM ShoppingItem si";
            sqlCommand += " INNER JOIN Products p ON si.Product_ID = p.Product_ID";
            sqlCommand += " WHERE custID = '" + Request.QueryString["custID"] + "'";

            BLL_Joins innerJoin = new BLL_Joins();
            Boolean hasRows = innerJoin.hasRows(sqlCommand);

            if (Request.QueryString["login"].Equals("false"))
            {
                string queryString = "?login=false";
                Response.Redirect("~/StoreErrorPage.aspx" + queryString);
            }
            else if (Request.QueryString["staffID"] != null)
            {
                string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                Response.Redirect("~/StoreErrorPage.aspx" + queryString);
            }
            else if (hasRows == false)
            {
                string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
                Response.Redirect("~/StoreErrorPage.aspx" + queryString);
            }

            if (!IsPostBack)
            {
                ViewGridView();
            }
        }

        protected void ViewGridView()
        {
            string sqlCommand = "SELECT * FROM ShoppingItem si";
            sqlCommand += " INNER JOIN Products p ON si.Product_ID = p.Product_ID";
            sqlCommand += " WHERE custID = '" + Request.QueryString["custID"] + "'";

            BLL_Joins innerJoin = new BLL_Joins();
            DataSet ds = new DataSet();

            ds = innerJoin.getShoppingItems(sqlCommand);
            gv_Products.DataSource = ds;
            gv_Products.DataBind();

            sqlCommand = "SELECT sum(Unit_Price*Quantity) TotalPrice FROM ShoppingItem si";
            sqlCommand += " INNER JOIN Products p ON si.Product_ID = p.Product_ID";
            sqlCommand += " WHERE custID = '" + Request.QueryString["custID"] + "'";

            string totalPrice = innerJoin.getShoppingItemsTotalPrice(sqlCommand);

            lb_Price.Text = "$" + totalPrice;

        }

        protected void gv_Products_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Update")
            {
                BLL_ShoppingItem shoppingItem = new BLL_ShoppingItem();

                string[] arg = new string[2];
                arg = e.CommandArgument.ToString().Split(';');

                string userID_ProductID = arg[0];

                string rowIndex = arg[1];
                TextBox tb = (TextBox)gv_Products.Rows[Convert.ToInt32(rowIndex)].FindControl("tb_Qty");
                string quantity = tb.Text;

                //Save quantity into DB
                shoppingItem.updateQuantity(quantity, userID_ProductID);

                //Refresh webpage
                Page.Response.Redirect(Page.Request.Url.ToString(), true);

            }
            if (e.CommandName == "Delete")
            {
                BLL_ShoppingItem shoppingItem = new BLL_ShoppingItem();

                //Delete item from DB
                shoppingItem.deleteShoppingItem(e.CommandArgument.ToString());

                //Refresh webpage
                Page.Response.Redirect(Page.Request.Url.ToString(), true);
            }
        }

        protected void btn_Reset_Click(object sender, EventArgs e)
        {
            BLL_ShoppingItem shoppingItem = new BLL_ShoppingItem();

            //Reset cart from DB
            shoppingItem.deleteAllItems(Request.QueryString["custID"]);

            //Refresh webpage
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
        }

        protected void btn_CheckOut_Click(object sender, EventArgs e)
        {
            Boolean itemOutOfStock = false;
            List<string> outStockProducts = new List<string>();
            List<string> outStockValue = new List<string>();

            foreach (GridViewRow row in gv_Products.Rows)
            {
                Label productName = (Label)row.FindControl("Label1");
                string productNameStr = productName.Text;

                BLL_Product product = new BLL_Product();
                string productID = product.getProductID(productNameStr);
                string stock = product.getStock(productID);

                TextBox quantity = (TextBox)row.FindControl("tb_Qty");
                string quantityStr = quantity.Text;

                if (Convert.ToInt32(quantityStr) > Convert.ToInt32(stock))
                {
                    itemOutOfStock = true;
                    outStockProducts.Add(productNameStr);
                    outStockValue.Add(stock);
                }
            }

            if (itemOutOfStock == true)
            {
                if (outStockProducts.Count > 1)
                {
                    string items = "";
                    for (int i = 0; i < outStockProducts.Count; i++)
                    {
                        items += "\\n" + (string)outStockProducts[i] + ". Current Stock: " + (string)outStockValue[i];
                    }
                    Response.Write("<script>alert('Multiple Items Out Of Stock. \\nItems are: " + items + ".')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Item Out Of Stock. \\nItem is " + (string)outStockProducts[0] + ". Current Stock: " + (string)outStockValue[0] + "')</script>");
                }
            }
            else
            {
                string[] account = new string[2];

                BLL_Customer customer = new BLL_Customer();
                string custID = Request.QueryString["custID"];

                string username = customer.getUsername(custID);
                string password = customer.getPassword(custID);

                account[0] = username;
                account[1] = password;

                if (tb_CheckOutUsername.Text.Equals(account[0]) && tb_CheckOutPassword.Text.Equals(account[1]))
                {
                    string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
                    Response.Redirect("~/StoreCreditCard.aspx" + queryString);
                }
                else
                {
                    Response.Write("<script>alert('Incorrect')</script>");
                }
            }
        }
    }
}