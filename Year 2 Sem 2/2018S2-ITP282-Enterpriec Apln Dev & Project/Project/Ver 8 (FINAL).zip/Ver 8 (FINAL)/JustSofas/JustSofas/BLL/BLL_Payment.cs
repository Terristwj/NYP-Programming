﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JustSofas.DAL;
using System.Data;

namespace JustSofas.BLL
{
    public class BLL_Payment
    {
        public void insertPayment(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, DateTime Date)
        {
            DAL_Payment paymentInfo = new DAL_Payment();
            paymentInfo.insertPayment(supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date);
        }
        public void insertPaymentToSupp(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, string Date)
        {
            DAL_Payment paymentInfo = new DAL_Payment();
            paymentInfo.insertPaymentToSupp(supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date);
        }
        public DataSet getAllPayment(string sqlCommand)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getAll(sqlCommand);
        }

        public DataSet getPaymentAll(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getPaymentAll(Id);
        }

        public DataSet getpaymentID(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getpaymentID(Id);
        }

        public DataSet getsupplierName(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getsupplierName(Id);
        }

        public DataSet getamountPayable(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getamountPayable(Id);
        }

        public DataSet getbankAccNum(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getbankAccNum(Id);
        }

        public DataSet getbankAccType(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getbankAccType(Id);
        }
        public DataSet getinvoiceId(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getinvoiceId(Id);
        }
        public DataSet getDate(int Id)
        {
            DAL_Payment payment = new DAL_Payment();
            return payment.getDate(Id);
        }
    }
}