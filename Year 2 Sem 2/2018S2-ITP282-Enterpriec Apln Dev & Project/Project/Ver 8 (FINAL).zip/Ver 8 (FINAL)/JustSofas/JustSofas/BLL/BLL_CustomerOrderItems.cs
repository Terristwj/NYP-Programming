﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_CustomerOrderItems
    {
        public void insertItem(string orderID_Product_ID, string order_ID, string product_ID, string quantity)
        {
            DAL_CustomerOrderItems item = new DAL_CustomerOrderItems();
            item.insertItem(orderID_Product_ID, order_ID, product_ID, quantity);
        }
    }
}