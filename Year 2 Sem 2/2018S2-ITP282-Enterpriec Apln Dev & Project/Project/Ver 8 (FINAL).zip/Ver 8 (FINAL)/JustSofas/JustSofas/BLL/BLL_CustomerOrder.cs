﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_CustomerOrder
    {
        //update status from supplier 
        public DataSet UpdateCustomerOrderStatus(int OrderNO)
        {
            DAL_CustomerOrder dal = new DAL_CustomerOrder();
            return dal.UpdateCustomerOrderStatus(OrderNO);

        }
        public DataSet getAllOrder(string sqlCommand)
        {
            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            return custOrder.getAll(sqlCommand);
        }

        //from supplier
        public DataSet getAllCOfromSupplier(string sqlcommand) {

            DAL_CustomerOrder custOrderFromSup = new DAL_CustomerOrder();
            return custOrderFromSup.getCO(sqlcommand);
        }

        public void insertCustomerOrder(string custID, string totalPrice, string netPrice, string dateOfOrder, string deliveryDate, string deliveryAddress)
        {
            DAL_CustomerOrder order = new DAL_CustomerOrder();
            order.insertCustomerOrder(custID, totalPrice, netPrice, dateOfOrder, deliveryDate, deliveryAddress);
        }

        public string getOrderID(string custID, string dateOfOrder)
        {
            DAL_CustomerOrder order = new DAL_CustomerOrder();
            DataSet myOrder = order.getOrderID(custID, dateOfOrder);

            DataTable dt = new DataTable();
            dt = myOrder.Tables[0];                             // Connect DT to DS

            string orderID = dt.Rows[0]["orderID"].ToString();
            return orderID;
        }

        public string getOrderStatus(string orderID)
        {
            DAL_CustomerOrder order = new DAL_CustomerOrder();
            DataSet myOrder = order.getOrderStatus(orderID);

            DataTable dt = new DataTable();
            dt = myOrder.Tables[0];                             // Connect DT to DS

            string orderStatus = dt.Rows[0]["orderStatus"].ToString();
            return orderStatus;
        }

        public string getCOrderID(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getCOrderID(CustomerOrderID);
        }

        public string getSupName(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getSupName(CustomerOrderID);
        }
     

        public string getSupEmail(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getSupEmail(CustomerOrderID);
        }
      
        public string getSupAddress(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getSupAddress(CustomerOrderID);
        }
        
        public string getSupContact(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getSupContact(CustomerOrderID);
        }
     
        public string getCoyName(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getCoyName(CustomerOrderID);
        }
       
        public string getCoyEmail(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getCoyEmail(CustomerOrderID);
        }
       
        public string getCoyAddress(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getCoyAddress(CustomerOrderID);
        }
     
        public string getCoyContact(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getCoyContact(CustomerOrderID);
        }
 

        public string getDate(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getDate(CustomerOrderID);
        }

        public string getStatus(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getStatus(CustomerOrderID);
        }

        public string getQty(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getQty(CustomerOrderID);
        }

        public string getProductId(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getProductId(CustomerOrderID);
        }

        public string getProductName(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getProductName(CustomerOrderID);
        }

        public string getProductDesc(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getProductDesc(CustomerOrderID);
        }
      
        public string getProductunitPrice(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getProductunitPrice(CustomerOrderID);
        }
      
        public string getProductTotal(int CustomerOrderID)
        {
            DAL_CustomerOrder POrder = new DAL_CustomerOrder();
            return POrder.getProductTotal(CustomerOrderID);
        }
    }
}