﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_Customer
    {
        public Boolean loginStatus(string username, string password)
        {
            Boolean loginStatus = false;

            DAL_Customer account = new DAL_Customer();
            DataSet accounts = account.getAll();

            DataTable dt = new DataTable();
            dt = accounts.Tables[0];                             // Connect DT to DS


            foreach (DataRow dr in dt.Rows)
            {
                if (username.Equals(dr["username"].ToString()) && password.Equals(dr["password"].ToString()))
                {
                    loginStatus = true;
                }
            }

            return loginStatus;
        }

        public Boolean checkUsername(string username)
        {
            Boolean taken = false;

            DAL_Customer account = new DAL_Customer();
            DataSet accounts = account.getAllWhere("username", username);

            DataTable dt = new DataTable();
            dt = accounts.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (username.Equals(dr["username"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }
        public DataSet getAllCustomer(string sqlCommand)
        {
            DAL_Customer custAccount = new DAL_Customer();
            return custAccount.getAll(sqlCommand);
        }

        public string getCustID(string username)
        {
            DAL_Customer custAccount = new DAL_Customer();
            DataSet account = custAccount.getCustID(username);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string custID = dt.Rows[0]["custID"].ToString();
            return custID;
        }

        public string getCustName(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getCustName(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string custName = dt.Rows[0]["custName"].ToString();
            return custName;
        }

        public string getCustEmail(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getCustEmail(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string custEmail = dt.Rows[0]["custEmail"].ToString();
            return custEmail;
        }

        public string getCustAddress(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getCustAddress(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string custAddress = dt.Rows[0]["custAddress"].ToString();
            return custAddress;
        }

        public string getZipCode(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getZipCode(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string zipCode = dt.Rows[0]["zipCode"].ToString();
            return zipCode;
        }

        public string getCustContact(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getCustContact(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string custContact = dt.Rows[0]["custContact"].ToString();
            return custContact;
        }

        public string getUsername(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getUsername(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string username = dt.Rows[0]["username"].ToString();
            return username;
        }

        public string getPassword(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getPassword(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string password = dt.Rows[0]["password"].ToString();
            return password;
        }

        public string getBackgroundUrl(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getBackgroundUrl(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string backgroundUrl = dt.Rows[0]["backgroundUrl"].ToString();
            return backgroundUrl;
        }

        public string getProfileUrl(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getProfileUrl(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string profileUrl = dt.Rows[0]["profileUrl"].ToString();
            return profileUrl;
        }

        public string getAboutDesc(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getAboutDesc(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string aboutDesc = dt.Rows[0]["aboutDesc"].ToString();
            return aboutDesc;
        }

        public string getDateJoined(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getDateJoined(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string dateJoined = dt.Rows[0]["dateJoined"].ToString();
            return dateJoined;
        }

        public string getLastActivity(string custID)
        {
            DAL_Customer customer = new DAL_Customer();
            DataSet account = customer.getLastActivity(custID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string lastActivity = dt.Rows[0]["lastActivity"].ToString();
            return lastActivity;
        }

        public void updateCustName(string custName, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateCustName(custName, custID);
        }
        public void updateCustEmail(string custEmail, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateCustEmail(custEmail, custID);
        }
        public void updateCustAddress(string custAddress, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateCustAddress(custAddress, custID);
        }
        public void updateZipCode(string zipCode, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateZipCode(zipCode, custID);
        }
        public void updateCustContact(string custContact, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateCustContact(custContact, custID);
        }
        public void updatePassword(string password, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updatePassword(password, custID);
        }
        public void updateBackgroundUrl(string backgroundUrl, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateBackgroundUrl(backgroundUrl, custID);
        }
        public void updateProfileUrl(string profileUrl, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateProfileUrl(profileUrl, custID);
        }
        public void updateAboutDesc(string aboutDesc, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateAboutDesc(aboutDesc, custID);
        }
        public void updateLastActivity(string lastActivity, string custID)
        {
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.updateLastActivity(lastActivity, custID);
        }

        public void insertCustomer(string name, string email, string address, string zipCode, string contact, string username, string password)
        {
            DateTime dateJoined = DateTime.Now;
            string dateJoinedStr = dateJoined.ToString("dddd dd MMMM yyyy");

            string aboutDesc = makeAboutDesc(name);
            DAL_Customer custAccount = new DAL_Customer();
            custAccount.insertCustomer(name, email, address, zipCode, contact, username, password, aboutDesc, dateJoinedStr);
        }

        public string makeAboutDesc(string name)
        {
            DateTime dateJoined = DateTime.Now;
            string dateJoinedStr = dateJoined.ToString("dddd dd MMMM yyyy");

            DAL_AboutMeText aboutMeText = new DAL_AboutMeText();
            DataSet aboutMeText_Parts = aboutMeText.getDefaultAboutDesc();

            DataTable dt = new DataTable();
            dt = aboutMeText_Parts.Tables[0];                             // Connect DT to DS

            string start = dt.Rows[0]["Start"].ToString();
            string middle = dt.Rows[0]["Middle"].ToString();
            string end = dt.Rows[0]["End"].ToString();

            string aboutDesc = start + name + middle + dateJoinedStr + end;
            return aboutDesc;
        }
    }
}