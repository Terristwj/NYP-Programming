﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_Product_Ws
    {
        public DataSet getSupplierCatalogue()
        {
            DAL_Product_Ws dal = new DAL_Product_Ws();
            DataSet dataSetOSEPList;
            dataSetOSEPList = dal.getSupplierCatalogue();

            return dataSetOSEPList;
        }

        public DataSet getSupplierCatalogue2(string sqlCommand)
        {
            DAL_Product_Ws dal = new DAL_Product_Ws();
            DataSet dataSetOSEPList;
            dataSetOSEPList = dal.getSupplierCatalogue2(sqlCommand);

            return dataSetOSEPList;
        }

        public string getImageUrl(string product_ID)
        {
            DAL_Product_Ws product = new DAL_Product_Ws();
            DataSet myProduct = product.getImageUrl(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string imageUrl = dt.Rows[0]["ImageUrl"].ToString();
            return imageUrl;
        }

        public string getName(string product_ID)
        {
            DAL_Product_Ws product = new DAL_Product_Ws();
            DataSet myProduct = product.getName(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string name = dt.Rows[0]["Name"].ToString();
            return name;
        }

        public double getUnitPrice(string product_ID)
        {
            DAL_Product_Ws product = new DAL_Product_Ws();
            DataSet myProduct = product.getUnitPrice(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string price = dt.Rows[0]["Unit_Price"].ToString();
            double Unit_Price = Convert.ToDouble(price);

            return Unit_Price;
        }

        public string getDescription(string product_ID)
        {
            DAL_Product_Ws product = new DAL_Product_Ws();
            DataSet myProduct = product.getDescription(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string description = dt.Rows[0]["Description"].ToString();
            return description;
        }

        public string getCategory(string product_ID)
        {
            DAL_Product_Ws product = new DAL_Product_Ws();
            DataSet myProduct = product.getCategory(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string category = dt.Rows[0]["Category"].ToString();
            return category;
        }

        public string getDateCreated(string product_ID)
        {
            DAL_Product_Ws product = new DAL_Product_Ws();
            DataSet myProduct = product.getDateCreated(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string dateCreated = dt.Rows[0]["DateCreated"].ToString();
            return dateCreated;
        }
    }
}