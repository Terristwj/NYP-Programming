﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using JustSofas.DAL;

namespace JustSofas.BLL
{
    public class BLL_DeliveryOrder
    {
        //update status from supplier 
        public DataSet UpdateDeliveryStatus(int DeliveryId)
        {
            DAL_DeliveryOrder dal = new DAL_DeliveryOrder();
            return dal.UpdateDeliveryStatus(DeliveryId);

        }
        public DataSet getAllDeliveryOrder(string sqlCommand)
        {
            DAL_DeliveryOrder dOrder = new DAL_DeliveryOrder();
            return dOrder.getAllDeliveryOrder(sqlCommand);
        }

        public String getDeliveryOrderID(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getDeliveryOrderID(Id);
        }

        public String getDeliveryOrderDate(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getDeliveryOrderDate(Id);
        }

        public String getDeliveryOrderTime(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getDeliveryOrderTime(Id);
        }

        public String getDeliveryOrderStatus(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getDeliveryOrderStatus(Id);
        }

        public String getDeliveryOrderCoy(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getDeliveryOrderCoy(Id);
        }

        public String getProductIdDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getProductIdDO(Id);
        }

        public String getQuantityDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getQuantityDO(Id);
        }

        public String getUnitPriceDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getUnitPriceDO(Id);
        }

        public String getProductNameDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getProductNameDO(Id);
        }

        public String getDispatchDate(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getDispatchDate(Id);
        }

        public String getCompanyNameDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getCompanyNameDO(Id);
        }

        public String getCompanyEmailDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getCompanyEmailDO(Id);
        }

        public String getCompanyContactDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getCompanyContactDO(Id);
        }

        public String getCompanyAddressDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getCompanyAddressDO(Id);
        }

        public String getSupplierNameDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getSupplierNameDO(Id);
        }

        public String getInvoiceStatusDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getInvoiceStatusDO(Id);
        }

        public String getTotalPriceDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getTotalPriceDO(Id);
        }

        public String getSupplierAddressDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getSupplierAddressDO(Id);
        }

        public String getSupplierEmailDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getSupplierEmailDO(Id);
        }

        public String getSupplierContactDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getSupplierContactDO(Id);
        }
        public String getInvoiceDescDO(int Id)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getInvoiceDescDO(Id);
        }
    }
}