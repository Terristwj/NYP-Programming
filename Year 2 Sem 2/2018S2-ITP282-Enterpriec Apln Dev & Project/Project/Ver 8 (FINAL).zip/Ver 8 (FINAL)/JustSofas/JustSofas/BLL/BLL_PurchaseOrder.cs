﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_PurchaseOrder
    {
        public DataSet getAllPurchaseOrder(string sqlCommand)
        {
            DAL_PurchaseOrder custOrder = new DAL_PurchaseOrder();
            return custOrder.getAll(sqlCommand);
        }

        public DataSet getPurchaseOrderDetails(int POId)
        {
            DAL_PurchaseOrder custOrder = new DAL_PurchaseOrder();
            return custOrder.getPurchaseOrderDetails(POId);
        }


        public void insertOrder(string DateOfOrder, string ProductID, string Quantity, string TotalAmount)
        {
            DAL_PurchaseOrder order = new DAL_PurchaseOrder();
            order.insertOrder(DateOfOrder, ProductID, Quantity, TotalAmount);
        }

        public Boolean getOrderByProd(string ProductID)
        {
            Boolean orderExist = false;

            DAL_PurchaseOrder order = new DAL_PurchaseOrder();
            DataSet myOrder = order.getOrderByProd(ProductID);

            DataTable dt = new DataTable();
            dt = myOrder.Tables[0];                             // Connect DT to DS

            try
            {
                string Id = dt.Rows[0]["Id"].ToString();
                orderExist = true;
            }
            catch (Exception ex)
            {

            }
            return orderExist;
        }


        //supplier


        public string getPOrderID(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getPOrderID(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Id"].ToString();
            return purchaseID;


        }


        public string getSupNmame(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getSupName(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["SupplierName"].ToString();
            return purchaseID;


        }



        public string getSupEmail(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getSupEmail(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["SupplierEmail"].ToString();
            return purchaseID;


        }

        public string getSupAddress(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getSupAddress(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["SupplierAddress"].ToString();
            return purchaseID;


        }


        public string getSupContact(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getSupContact(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["SupplierContact"].ToString();
            return purchaseID;


        }

        ////company


        public string getCoyName(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getCoyName(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["CompanyName"].ToString();
            return purchaseID;


        }

        public string getCoyEmail(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getCoyEmail(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Email"].ToString();
            return purchaseID;


        }



        public string getCoyAddress(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getCoyAddress(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Address"].ToString();
            return purchaseID;


        }



        public string getCoyContact(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getCoyContact(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Contact"].ToString();
            return purchaseID;


        }
        ////purchase


        public string getDate(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getDate(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["dateOfOrder"].ToString();
            return purchaseID;


        }



        public string getStatus(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getStatus(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Status"].ToString();
            return purchaseID;


        }


        public string getQty(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getQty(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Quantity"].ToString();
            return purchaseID;


        }


        public string getProductId(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getProductId(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["ProductID"].ToString();
            return purchaseID;


        }


        public string getProductName(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getProductName(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Name"].ToString();
            return purchaseID;


        }


        public string getProductDesc(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getProductDesc(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Description"].ToString();
            return purchaseID;


        }

        public string getProductunitPrice(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getProductunitPrice(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Unit_Price"].ToString();
            return purchaseID;


        }
        public string getProductTotal(int PurchaseID)
        {

            DAL_PurchaseOrder purchaseOrder = new DAL_PurchaseOrder();
            DataSet purchase = purchaseOrder.getProductTotal(PurchaseID);

            DataTable dt = new DataTable();
            dt = purchase.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["TotalAmount"].ToString();
            return purchaseID;


        }
    }
}