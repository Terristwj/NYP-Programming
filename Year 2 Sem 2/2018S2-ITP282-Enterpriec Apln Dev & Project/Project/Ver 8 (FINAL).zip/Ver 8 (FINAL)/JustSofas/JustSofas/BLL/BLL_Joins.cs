﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_Joins
    {
        public Boolean hasRows(string sqlCommand)
        {
            Boolean hasRows = false;

            DAL_Joins joins = new DAL_Joins();
            DataSet myJoins = joins.selectSql(sqlCommand);

            DataTable dt = new DataTable();
            dt = myJoins.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                hasRows = true;
            }

            return hasRows;
        }

        public DataSet getShoppingItems(string sqlCommand)
        {
            DAL_Joins joins = new DAL_Joins();
            DataSet myJoins;
            myJoins = joins.selectSql(sqlCommand);

            return myJoins;
        }

        public DataSet getOrderItems(string sqlCommand)
        {
            DAL_Joins joins = new DAL_Joins();
            DataSet myJoins;
            myJoins = joins.selectSql(sqlCommand);

            return myJoins;
        }

        public string getShoppingItemsTotalPrice(string sqlCommand)
        {
            DAL_Joins joins = new DAL_Joins();
            DataSet myJoins;
            myJoins = joins.selectSql(sqlCommand);

            DataTable dt = new DataTable();
            dt = myJoins.Tables[0];                             // Connect DT to DS

            string quantityStr = Convert.ToDouble(dt.Rows[0]["TotalPrice"].ToString()).ToString("0.00");
            return quantityStr;
        }
    }
}