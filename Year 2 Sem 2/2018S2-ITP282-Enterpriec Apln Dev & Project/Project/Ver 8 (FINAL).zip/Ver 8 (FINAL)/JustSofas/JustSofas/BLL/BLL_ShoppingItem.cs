﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_ShoppingItem
    {
        public Boolean getShoppingItemExist(string custID, string productID)
        {
            Boolean taken = false;

            DAL_ShoppingItem item = new DAL_ShoppingItem();
            string primaryKey = custID + "_" + productID;
            DataSet product = item.getShoppingItem(primaryKey);

            DataTable dt = new DataTable();
            dt = product.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (primaryKey.Equals(dr["custID_ProductID"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public int getQuantity(string custID, string productID)
        {
            DAL_ShoppingItem item = new DAL_ShoppingItem();
            string primaryKey = custID + "_" + productID;
            DataSet product = item.getQuantity(primaryKey);

            DataTable dt = new DataTable();
            dt = product.Tables[0];                             // Connect DT to DS

            string quantityStr = dt.Rows[0]["Quantity"].ToString();
            int quantity = Convert.ToInt32(quantityStr);
            return quantity;
        }

        public void updateQuantity(string newQuantityStr, string custID, string productID)
        {
            DAL_ShoppingItem item = new DAL_ShoppingItem();
            string primaryKey = custID + "_" + productID;
            item.updateQuantity(newQuantityStr, primaryKey);
        }

        public void updateQuantity(string newQuantityStr, string userID_ProductID)
        {
            DAL_ShoppingItem item = new DAL_ShoppingItem();
            string primaryKey = userID_ProductID;
            item.updateQuantity(newQuantityStr, primaryKey);
        }

        public void insertShoppingItem(string primaryKey, string custID, string productID, string quantity)
        {
            DAL_ShoppingItem item = new DAL_ShoppingItem();
            item.insertShoppingItem(primaryKey, custID, productID, quantity);
        }

        public void deleteShoppingItem(string primaryKey)
        {
            DAL_ShoppingItem item = new DAL_ShoppingItem();
            item.deleteShoppingItem(primaryKey);
        }

        public void deleteAllItems(string custID)
        {
            DAL_ShoppingItem item = new DAL_ShoppingItem();
            item.deleteShoppingItem2(custID);
        }
    }
}