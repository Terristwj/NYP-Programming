﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_Product
    {
        public DataSet getAllProduct(string sqlCommand)
        {
            DAL_Product product = new DAL_Product();
            return product.getAll(sqlCommand);
        }

        public string getImageUrl(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getImageUrl(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string imageUrl = dt.Rows[0]["ImageUrl"].ToString();
            return imageUrl;
        }

        public string getName(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getName(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string name = dt.Rows[0]["Name"].ToString();
            return name;
        }

        public double getUnitPrice(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getUnitPrice(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string price = dt.Rows[0]["Unit_Price"].ToString();
            double Unit_Price = Convert.ToDouble(price);

            return Unit_Price;
        }

        public string getDescription(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getDescription(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string description = dt.Rows[0]["Description"].ToString();
            return description;
        }

        public string getCategory(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getCategory(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string category = dt.Rows[0]["Category"].ToString();
            return category;
        }

        public string getStock(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getStock(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string stock = dt.Rows[0]["Stock"].ToString();
            return stock;
        }

        public string getReorderPoint(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getReorderPoint(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string reorderPoint = dt.Rows[0]["Reorder_Point"].ToString();
            return reorderPoint;
        }

        public string getReorderQuantity(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getReorderQuantity(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string reorderQuantity = dt.Rows[0]["Reorder_Quantity"].ToString();
            return reorderQuantity;
        }

        public string getIsDeleted(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getIsDeleted(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string isDeleted = dt.Rows[0]["IsDeleted"].ToString();
            return isDeleted;
        }

        public string getProductID(string name)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getProductID(name);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string Product_ID = dt.Rows[0]["Product_ID"].ToString();
            return Product_ID;
        }

        public void deleteProduct(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.deleteProduct(product_ID);
        }

        public void insertProduct(string Product_ID, string Category, string Name, string Description, string Unit_Price, string ImageUrl, string stock, string Reorder_Point, string Reorder_Quantity)
        {
            DAL_Product product = new DAL_Product();
            product.insertProduct(Product_ID, Category, Name, Description, Unit_Price, ImageUrl, stock, Reorder_Point, Reorder_Quantity);
        }

        public Boolean checkName(string name)
        {
            Boolean taken = false;

            DAL_Product product = new DAL_Product();
            DataSet products = product.getName(name);

            DataTable dt = new DataTable();
            dt = products.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (name.Equals(dr["Name"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public Boolean checkName2(string name, string productID)
        {
            Boolean taken = false;

            DAL_Product product = new DAL_Product();
            DataSet products = product.checkName(name, productID);

            DataTable dt = new DataTable();
            dt = products.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (name.Equals(dr["Name"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public void updateCategory(string category, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateCategory(category, product_ID);
        }

        public void updateName(string Name, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateName(Name, product_ID);
        }

        public void updateUnitPrice(string unitPrice, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateUnitPrice(unitPrice, product_ID);
        }

        public void updateDescription(string desciption, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateUnitPrice(desciption, product_ID);
        }

        public void updateImageUrl(string imageUrl, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateImageUrl(imageUrl, product_ID);
        }

        public void updateStock(string stock, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateStock(stock, product_ID);
        }

        public void updateReorderPoint(string reorderPoint, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateReorderPoint(reorderPoint, product_ID);
        }

        public void updateReorderQuantity(string reorderQuantity, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateReorderQuantity(reorderQuantity, product_ID);
        }

        public void updateIsDeleted(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateIsDeleted(product_ID);
        }
    }
}