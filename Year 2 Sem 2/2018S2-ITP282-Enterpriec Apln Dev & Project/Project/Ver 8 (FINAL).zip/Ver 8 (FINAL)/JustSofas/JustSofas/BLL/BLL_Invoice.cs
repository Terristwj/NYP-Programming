﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using JustSofas.DAL;

namespace JustSofas.BLL
{
    public class BLL_Invoice
    {
        public DataSet getAllInvoice(string sqlCommand)
        {
            DAL_Invoice invoice = new DAL_Invoice();
            return invoice.getInvoice(sqlCommand);
        }

        public string getInvoiceID(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getInvoiceID(invoiceID);
        }

        public string getSupplierName(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getSupplierName(invoiceID);
        }

        public string getInvoiceStatus(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getInvoiceStatus(invoiceID);
        }

        public string getInvoiceDate(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getInvoiceDate(invoiceID);
        }

        public string getSupplierAddress(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getSupplierAddress(invoiceID);
        }

        public string getSupplierEmail(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getSupplierEmail(invoiceID);
        }

        public string getSupplierContact(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getSupplierContact(invoiceID);
        }

        public string getCompanyName(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getCompanyName(invoiceID);
        }

        public string getCompanyEmail(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getCompanyEmail(invoiceID);
        }

        public string getCompanyContact(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getCompanyContact(invoiceID);
        }

        public string getCompanyAddress(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getCompanyAddress(invoiceID);
        }

        public string getProductId(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getProductId(invoiceID);
        }

        public string getProductName(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getProductName(invoiceID);
        }

        public string getQuantity(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getQuantity(invoiceID);
        }

        public string getUnitPriceInvoice(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getUnitPriceInvoice(invoiceID);
        }
        public string getTotalPrice(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getTotalPrice(invoiceID);
        }
        public string getInvoiceDesc(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            return invoiceDetail.getInvoiceDesc(invoiceID);
        }

        public void updateInvoiceStatus(string invoiceStatus, int invoiceID)
        {
            DAL_Invoice Status = new DAL_Invoice();
            Status.updateInvoiceStatus(invoiceStatus, invoiceID);
        }
    }
}