﻿using JustSofas.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.BLL
{
    public class BLL_CreditCard
    {
        public DataSet getAllCreditCard(string custID)
        {
            DAL_CreditCard creditCard = new DAL_CreditCard();
            DataSet creditCards = creditCard.getAll(custID);
            return creditCards;
        }

        public int getNumberCC(string custID)
        {
            DAL_CreditCard creditCard = new DAL_CreditCard();
            int numberCC = creditCard.getNumberCC(custID);
            return numberCC;
        }

        public Boolean checkCC(string pK)
        {
            Boolean taken = false;

            DAL_CreditCard creditCard = new DAL_CreditCard();
            DataSet creditCards = creditCard.getAll2(pK);

            DataTable dt = new DataTable();
            dt = creditCards.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (pK.Equals(dr["cardNumber_userID"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public void insertCreditCard(string customerID, string cardNumber, string cardType, string expires, string country, string firstName, string lastName, string cardImageUrl, string cardNumber_userID)
        {
            DAL_CreditCard creditCard = new DAL_CreditCard();
            creditCard.insertCreditCard(customerID, cardNumber, cardType, expires, country, firstName, lastName, cardImageUrl, cardNumber_userID);
        }

        public void deleteCC(string cardNumber_userID)
        {
            DAL_CreditCard creditCard = new DAL_CreditCard();
            creditCard.deleteCC(cardNumber_userID);
        }
    }
}