﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class AccountUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Customer customer = new BLL_Customer();
            string custID = Request.QueryString["custID"];

            string name = customer.getCustName(custID);
            string background = customer.getBackgroundUrl(custID);
            string profileImg = customer.getProfileUrl(custID);
            string username = customer.getUsername(custID);
            string dateJoined = customer.getDateJoined(custID);
            string lastActivity = customer.getLastActivity(custID);
            string aboutDesc = customer.getAboutDesc(custID);

            LblName.Text = name;

            if (background != "DefaultProfileBackground.jpg")
                ImgProfileBackground.ImageUrl = "~/Images/Users/" + username + "/Background/" + background;
            else
                ImgProfileBackground.ImageUrl = "~/Images/Default/" + background;

            if (profileImg != "DefaultProfileImage.png")
                Image1.ImageUrl = "~/Images/Users/" + username + "/Avatar/" + profileImg;
            else
                Image1.ImageUrl = "~/Images/Default/" + profileImg;


            tb_AboutMe.Text = aboutDesc;

            lb_Membership_Status.Text = "Normal Member";
            lb_Membership_DateJoined.Text = "Date Joined: " + dateJoined;
            lb_Last_Activity.Text = "Last Online: " + lastActivity;
        }

        protected void BtnEditBackground_Click(object sender, EventArgs e)
        {
            BLL_Customer customer = new BLL_Customer();
            string custID = Request.QueryString["custID"];

            string image = "";
            string fullPath = "";
            string currentBackground = customer.getBackgroundUrl(custID);

            string username = customer.getUsername(custID);

            //Creates folder for first time users
            string userFolder = username;
            string path = Server.MapPath("~/Images/Users/" + userFolder + "/Background");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            if (Path.GetExtension(FileUpload.FileName).ToLower() != ".jpg"
                && Path.GetExtension(FileUpload.FileName).ToLower() != ".png"
                && Path.GetExtension(FileUpload.FileName).ToLower() != ".gif"
                && Path.GetExtension(FileUpload.FileName).ToLower() != ".jpeg")
            {
                Response.Write("<script>alert('This is not an image file')</script>");
            }
            else
            {
                //Fist time change
                if (currentBackground != "DefaultProfileBackground.jpg")
                {
                    //Delete image
                    image = "Images\\Users\\" + username + "\\Background\\" + currentBackground;
                    fullPath = Server.MapPath("") + "\\" + image;
                    File.Delete(fullPath);
                }

                //Add image into DB
                customer.updateBackgroundUrl(FileUpload.FileName, custID);

                //Change image
                image = "Images\\Users\\" + username + "\\Background\\" + FileUpload.FileName;
                fullPath = Server.MapPath("") + "\\" + image;
                FileUpload.SaveAs(fullPath);

                //Refresh webpage
                Page.Response.Redirect(Page.Request.Url.ToString(), true);
            }
        }

        protected void BtnEditAcc_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/EditParticulars.aspx" + queryString);
        }

        protected void BtnSignOut_Click(object sender, EventArgs e)
        {
            string queryString = "?login=false";
            Response.Redirect("~/Login.aspx" + queryString);
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/ProfileSearchUser.aspx" + queryString);
        }
    }
}