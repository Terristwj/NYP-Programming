﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class ViewProfilePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Customer customer = new BLL_Customer();
            string custID = Request.QueryString["viewedProfile"];

            string name = customer.getCustName(custID);
            string background = customer.getBackgroundUrl(custID);
            string profileImg = customer.getProfileUrl(custID);
            string username = customer.getUsername(custID);
            string dateJoined = customer.getDateJoined(custID);
            string lastActivity = customer.getLastActivity(custID);
            string aboutDesc = customer.getAboutDesc(custID);

            LblName.Text = name;

            if (background != "DefaultProfileBackground.jpg")
                ImgProfileBackground.ImageUrl = "~/Images/Users/" + username + "/Background/" + background;
            else
                ImgProfileBackground.ImageUrl = "~/Images/Default/" + background;

            if (profileImg != "DefaultProfileImage.png")
                Image1.ImageUrl = "~/Images/Users/" + username + "/Avatar/" + profileImg;
            else
                Image1.ImageUrl = "~/Images/Default/" + profileImg;


            tb_AboutMe.Text = aboutDesc;

            lb_Membership_Status.Text = "Normal Member";
            lb_Membership_DateJoined.Text = "Date Joined: " + dateJoined;
            lb_Last_Activity.Text = "Last Online: " + lastActivity;
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["custID"] != null)
            {
                queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
                Response.Redirect("~/ProfileSearchUser.aspx" + queryString);
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                Response.Redirect("~/ViewUsers.aspx" + queryString);
            }
        }
    }
}