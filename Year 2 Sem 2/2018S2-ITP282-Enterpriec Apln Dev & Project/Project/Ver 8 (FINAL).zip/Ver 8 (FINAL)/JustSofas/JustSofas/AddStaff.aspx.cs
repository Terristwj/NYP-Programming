﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class AddStaff : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Create_Click(object sender, EventArgs e)
        {
            Boolean validAccount = true;

            BLL_StaffAccount accounts = new BLL_StaffAccount();
            Boolean usernameTaken = accounts.checkUsername(tb_Username.Text);
            Boolean nameTaken = accounts.checkName(tb_Name.Text);

            if (usernameTaken == true)
            {
                Response.Write("<script>alert('Username is taken.')</script>");
                validAccount = false;
            }

            if (nameTaken == true)
            {
                Response.Write("<script>alert('Name is taken.')</script>");
                validAccount = false;
            }


            if (validAccount == true)
            {
                BLL_StaffAccount account = new BLL_StaffAccount();
                account.insertAccount(tb_Username.Text, tb_Password.Text, tb_Name.Text, ddl_Position.SelectedValue);
                tb_Name.Text = "";
                tb_Password.Text = "";
                tb_Username.Text = "";
                ddl_Position.SelectedIndex = 0;
                Response.Write("<script>alert('Successfully Created')</script>");
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewStaff.aspx" + queryString);
        }
    }
}