﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JustSofas.BLL;
using System.Data;

namespace JustSofas
{
    public partial class PaymentDetails : System.Web.UI.Page
    {
        

        static string command = "SELECT * FROM StaffPayment";
        static string rewriteCommand = "SELECT * FROM StaffPayment";
        protected void Page_Load(object sender, EventArgs e)
        {
            //BLL_Payment invoice = new BLL_Payment();
            //string orderID = Request.QueryString["staffID"];

            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_Payment paymentList = new BLL_Payment();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = paymentList.getAllPayment(rewriteCommand);
                gv_payment.DataSource = ds;
                gv_payment.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = paymentList.getAllPayment(command);
                    gv_payment.DataSource = ds;
                    gv_payment.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = paymentList.getAllPayment(rewriteCommand);
                    gv_payment.DataSource = ds;
                    gv_payment.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = paymentList.getAllPayment(finalCommand);
                    gv_payment.DataSource = ds;
                    gv_payment.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE supplierName LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }


        //protected void btn_SortOnly_Click(object sender, EventArgs e)
        //{
        //    string value = ddl_SortOnly.SelectedValue;
        //    if (value.Equals("None"))
        //    {
        //        ViewGridView("None", "None");
        //    }
        //    else if (value.Equals("Status - "))
        //    {
        //        ViewGridView("WHERE", "WHERE Status = 'delivered'");

        //    }
        //    else if (value.Equals("Status - pending"))
        //    {
        //        ViewGridView("WHERE", "WHERE Status = 'pending'");

        //    }

        //}

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            //if (value.Equals("Time"))
            //{
            //    ViewGridView("ORDERBY", "ORDER BY Time");
            //}
            //else if (value.Equals("Date"))
            //{
                ViewGridView("ORDERBY", "ORDER BY Date DESC");
           // }
        }


        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/AccountStaff.aspx" + queryString);
        }

        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            ViewGridView("ORDERBY", "ORDER BY supplierName DESC");
        }

        protected void gv_payment_SelectedIndexChanged(object sender, EventArgs e)
        {
            //BLL_StaffAccount account = new BLL_StaffAccount();
            //string position = account.getPosition(Request.QueryString["staffID"]);
            BLL_Payment invoice = new BLL_Payment();
            string orderID = Request.QueryString["staffID"];
          //  int invoiceId = int.Parse(Request.QueryString["Id"]);

            int invoiceId = int.Parse(gv_payment.SelectedDataKey.Value.ToString());
            //Session["invoiceId"] = invoiceId;
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"]+"&Id="+ invoiceId;
            Response.Redirect("~/TransactionDetails.aspx" + queryString);
        }
    }
}