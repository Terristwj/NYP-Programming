﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class CreditCard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Below is the set of credit card information to be loaded
            if (!IsPostBack)   //MUST USE !IsPostBack IF NOT ERROR IN ADDing
            {
                BLL_CreditCard creditCards = new BLL_CreditCard();
                string custID = Request.QueryString["custID"];

                DataSet ds = creditCards.getAllCreditCard(custID);
                dl_CreditCard.DataSource = ds;
                dl_CreditCard.DataBind();
            }
        }

        protected void btn_AddCard_Click(object sender, EventArgs e)
        {
            BLL_CreditCard creditCards = new BLL_CreditCard();
            string custID = Request.QueryString["custID"];

            Boolean furtherValidated1 = false; // For card type + card number combination
            Boolean furtherValidated2 = false; // For expires, MM <= 12
            Boolean furtherValidated3 = false; // Max 4 credit cards
            Boolean furtherValidated4 = true; // Credit card number is already listed

            // We further check if the card is real

            // Check the card number to card type
            if (ddl_CardType.SelectedItem.Value.Equals("MasterCard") && tb_CardNumber.Text.Substring(0, 1).Equals("5") && tb_CardNumber.Text.Length == 16 + 3)
            {
                furtherValidated1 = true;
            }

            if (ddl_CardType.SelectedItem.Value.Equals("Visa") && tb_CardNumber.Text.Substring(0, 1).Equals("4") && tb_CardNumber.Text.Length == 16 + 3)
            {
                furtherValidated1 = true;
            }

            if (ddl_CardType.SelectedItem.Value.Equals("American Express") && tb_CardNumber.Text.Substring(0, 1).Equals("3") && tb_CardNumber.Text.Length == 15 + 3)
            {
                furtherValidated1 = true;
            }

            if (ddl_CardType.SelectedItem.Value.Equals("Discover") && (tb_CardNumber.Text.Substring(0, 4).Equals("6011") || tb_CardNumber.Text.Substring(0, 3).Equals("644") || tb_CardNumber.Text.Substring(0, 2).Equals("65")) && tb_CardNumber.Text.Length == 16 + 3)
            {
                furtherValidated1 = true;
            }


            // Check the expires for validity
            if (Convert.ToInt32(tb_Expires.Text.Substring(0, 1)) == 1 && Convert.ToInt32(tb_Expires.Text.Substring(1, 1)) <= 2)
            {
                furtherValidated2 = true;
            }

            if (Convert.ToInt32(tb_Expires.Text.Substring(0, 1)) == 0)
            {
                furtherValidated2 = true;
            }
            
            
            int numberOfCCards = creditCards.getNumberCC(custID); ;

            if (numberOfCCards < 4)
            {
                furtherValidated3 = true;
            }

            string primaryKey = tb_CardNumber.Text + " " + custID;
            Boolean creditCardUsed = creditCards.checkCC(primaryKey);

            if (creditCardUsed == true)    //// Call Read before accessing data.
            {
                furtherValidated4 = false;
            }


            if (furtherValidated1 == true && furtherValidated2 == true && furtherValidated3 == true && furtherValidated4 == true)
            {
                string cardImageUrl = "";
                if (ddl_CardType.SelectedValue.Equals("MasterCard"))
                {
                    cardImageUrl = "~/Images/Default/MasterCard.jpg";
                }
                else if (ddl_CardType.SelectedValue.Equals("Visa"))
                {
                    cardImageUrl = "~/Images/Default/VisaCard.png";
                }

                else if (ddl_CardType.SelectedValue.Equals("American Express"))
                {
                    cardImageUrl = "~/Images/Default/American Express.jpg";
                }

                else if (ddl_CardType.SelectedValue.Equals("Discover"))
                {
                    cardImageUrl = "~/Images/Default/Discover.jpg";
                }

                creditCards.insertCreditCard(custID, tb_CardNumber.Text, ddl_CardType.SelectedValue, tb_Expires.Text, ddl_Country.SelectedValue, tb_FName.Text, tb_LName.Text, cardImageUrl, tb_CardNumber.Text + " " + custID);

                //Refresh webpage
                Page.Response.Redirect(Page.Request.Url.ToString(), true);
            }
            else if (furtherValidated1 == true && furtherValidated2 == true && furtherValidated3 == false)
            {
                Response.Write("<script>alert('Max credit card limit')</script>");
            }
            else if (furtherValidated1 == true && furtherValidated2 == true && furtherValidated3 == true && furtherValidated4 == false)
            {
                Response.Write("<script>alert('Credit card already listed')</script>");
            }
            else
            {
                Response.Write("<script>alert('An input is invalid')</script>");
            }
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/EditParticulars.aspx" + queryString);
        }

        protected void dl_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "delete")
            {
                BLL_CreditCard creditCards = new BLL_CreditCard();
                string custID = Request.QueryString["custID"];

                string cardNumber = ((Label)dl_CreditCard.Items[e.Item.ItemIndex].FindControl("lb_cardNumberDL")).Text;
                string pK = cardNumber + " " + custID;

                creditCards.deleteCC(pK);

                //Refresh webpage
                Page.Response.Redirect(Page.Request.Url.ToString(), true);
            }
        }
    }
}