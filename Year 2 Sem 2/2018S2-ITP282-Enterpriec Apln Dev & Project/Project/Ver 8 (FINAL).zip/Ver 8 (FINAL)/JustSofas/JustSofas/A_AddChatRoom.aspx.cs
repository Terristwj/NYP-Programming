﻿using JustSofas.WeLoveChairs;
using JustSofas.WeLoveChairs.svc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class A_AddChatRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Create_Click(object sender, EventArgs e)
        {
            WsWeLoveChairsClient QnA = new WsWeLoveChairsClient();
            string roomSize = ddl_RoomSize.SelectedValue;
            string roomTitle = tb_Title.Text;

            //INSERT
            QnA.insertQnARoom(roomSize, roomTitle);

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/A_Rooms.aspx" + queryString);
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/A_Rooms.aspx" + queryString);
        }
    }
}