﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class ProfilePageTransactionsCompleted : System.Web.UI.Page
    {
        static string command = "";
        static string rewriteCommand = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            command = "SELECT * FROM CustomerOrder WHERE custID = '" + Request.QueryString["custID"] + "' AND orderStatus='Completed'";
            rewriteCommand = "SELECT * FROM CustomerOrder WHERE custID = '" + Request.QueryString["custID"] + "' AND orderStatus='Completed'";
            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_CustomerOrder productList = new BLL_CustomerOrder();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = productList.getAllOrder(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
                tb_SearchDateOfOrder.Text = "";
                tb_SearchDeliveryDate.Text = "";
            }
            else if (condition.Equals("None"))
            {
                rewriteCommand = command;
                ds = productList.getAllOrder(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
                tb_Search.Text = "";
            }
            else if (condition.Equals("SearchDateOfOrder"))
            {
                rewriteCommand = command + " " + condition_requirement;
                ds = productList.getAllOrder(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
                tb_Search.Text = "";
                tb_SearchDeliveryDate.Text = "";
            }
            else if (condition.Equals("SearchDeliveryDate"))
            {
                rewriteCommand = command + " " + condition_requirement;
                ds = productList.getAllOrder(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
                tb_Search.Text = "";
                tb_SearchDateOfOrder.Text = "";
            }
            else if (condition.Equals("ORDERBY"))
            {
                string finalCommand = rewriteCommand + " " + condition_requirement;
                ds = productList.getAllOrder(finalCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "";
            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND orderID = '" + value + "'";
            }
            ViewGridView("Search", condition_Requirement);
        }

        protected void btn_SearchDateOfOrder_Click(object sender, EventArgs e)
        {
            string value = tb_SearchDateOfOrder.Text;

            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND dateOfOrder LIKE '" + value + "%'";
            }
            ViewGridView("SearchDateOfOrder", condition_Requirement);
        }

        protected void btn_SearchDeliveryDate_Click(object sender, EventArgs e)
        {
            string value = tb_SearchDeliveryDate.Text;

            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND deliveryDate LIKE '" + value + "%'";
            }
            ViewGridView("SearchDeliveryDate", condition_Requirement);
        }

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            if (value.Equals("Order ID ASC"))
            {
                ViewGridView("ORDERBY", "ORDER BY orderID ASC");
            }
            else if (value.Equals("Order ID DESC"))
            {
                ViewGridView("ORDERBY", "ORDER BY orderID DESC");
            }
            else if (value.Equals("Total Price ASC"))
            {
                ViewGridView("ORDERBY", "ORDER BY totalPrice ASC");
            }
            else if (value.Equals("Total Price DESC"))
            {
                ViewGridView("ORDERBY", "ORDER BY totalPrice DESC");
            }
            else if (value.Equals("Net Price ASC"))
            {
                ViewGridView("ORDERBY", "ORDER BY netPrice ASC");
            }
            else if (value.Equals("Net Price DESC"))
            {
                ViewGridView("ORDERBY", "ORDER BY netPrice DESC");
            }
            else if (value.Equals("Order Date ASC"))
            {
                ViewGridView("ORDERBY", "ORDER BY dateOfOrder ASC");
            }
            else if (value.Equals("Order Date DESC"))
            {
                ViewGridView("ORDERBY", "ORDER BY dateOfOrder DESC");
            }
            else if (value.Equals("Deliv Date ASC"))
            {
                ViewGridView("ORDERBY", "ORDER BY deliveryDate ASC");
            }
            else if (value.Equals("Deliv Date DESC"))
            {
                ViewGridView("ORDERBY", "ORDER BY deliveryDate DESC");
            }
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/EditParticulars.aspx" + queryString);
        }
    }
}