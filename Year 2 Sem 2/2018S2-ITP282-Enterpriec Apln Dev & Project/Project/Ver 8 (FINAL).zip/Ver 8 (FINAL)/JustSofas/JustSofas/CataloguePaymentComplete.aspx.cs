﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class CataloguePaymentComplete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lb_OrderID.Text = Request.QueryString["orderID"];
                ViewGridView();
            }
        }

        protected void ViewGridView()
        {
            BLL_Joins join = new BLL_Joins();
            

            string command = "SELECT * FROM CustomerOrderItems coi";
            command += " INNER JOIN Products p ON coi.product_ID = p.Product_ID";
            command += " INNER JOIN CustomerOrder co ON co.orderID = coi.order_ID";
            command += " WHERE coi.order_ID = '" + Request.QueryString["orderID"] + "'";
            
            DataSet ds = new DataSet();
            ds = join.getOrderItems(command);
            gv_Products.DataSource = ds;
            gv_Products.DataBind();

            DataTable dt = new DataTable();
            dt = ds.Tables[0];

            string totalPrice = Convert.ToDouble(dt.Rows[0]["TotalPrice"].ToString()).ToString("0.00");

            double gst_rate = 7;
            double gst_value = Convert.ToDouble(totalPrice) * (gst_rate / 100);
            string gst_valueStr = gst_value.ToString("0.00");

            string netPrice = Convert.ToDouble(dt.Rows[0]["netPrice"].ToString()).ToString("0.00");
            string deliveryDate = dt.Rows[0]["deliveryDate"].ToString();
            string delieveryAddress = dt.Rows[0]["deliveryAddress"].ToString();

            lb_TotalPrice.Text = "$" + totalPrice;
            lb_GST.Text = "$" + gst_valueStr;
            lb_NetPrice.Text = "$" + netPrice;
            lb_DeliveryDate.Text = deliveryDate;
            tb_Address.Text = delieveryAddress;
        }

        protected void btn_Complete_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/Catalogue.aspx" + queryString);
        }
    }
}