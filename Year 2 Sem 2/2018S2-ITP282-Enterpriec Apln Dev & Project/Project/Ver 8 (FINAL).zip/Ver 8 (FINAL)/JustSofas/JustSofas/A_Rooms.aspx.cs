﻿using JustSofas.BLL;
using JustSofas.WeLoveChairs;
using JustSofas.WeLoveChairs.svc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class A_Rooms : System.Web.UI.Page
    {

        static string command = "";
        static string rewriteCommand = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            command = "SELECT * FROM chatRoom";
            command += " WHERE chatRoomID IS NOT NULL";

            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }

            if (Request.QueryString["failed"] != null)
            {
                Response.Write("<script>alert('Room " + Session["roomID"] + " Is Full.')</script>");
                Session.Remove("roomID");
            }

            if (Session["fail"] != null)
            {
                Session.Remove("fail");
                Response.Write("<script>alert('Failed.\\nThere are users inside.')</script>");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            WsWeLoveChairsClient QnA = new WsWeLoveChairsClient();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = QnA.getChatRooms(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
            }
            else if (condition.Equals("None"))
            {
                rewriteCommand = command;

                ds = QnA.getChatRooms(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
                tb_Search.Text = "";
            }
            else if (condition.Equals("ORDERBY"))
            {
                string finalCommand;
                finalCommand = rewriteCommand + " " + condition_requirement;

                ds = QnA.getChatRooms(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
            }
        }

        protected void btn_SearchTitle_Click(object sender, EventArgs e)
        {
            string value = tb_SearchTitle.Text;
            tb_Search.Text = "";
            tb_RoomSize.Text = "";
            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND roomTitle LIKE '%" + value + "%'";
            }
            ViewGridView("Search", condition_Requirement);
        }


        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            tb_SearchTitle.Text = "";
            tb_RoomSize.Text = "";
            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND chatRoomID = '" + value + "'";
            }
            ViewGridView("Search", condition_Requirement);
        }

        protected void btn_SearchSize_Click(object sender, EventArgs e)
        {
            string value = tb_RoomSize.Text;
            tb_SearchTitle.Text = "";
            tb_Search.Text = "";
            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND roomSize = '" + value + "'";
            }
            ViewGridView("Search", condition_Requirement);
        }

        protected void gv_Products_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Join")
            {
                WsWeLoveChairsClient QnA = new WsWeLoveChairsClient();
                string roomID = e.CommandArgument.ToString();

                string staffID = Request.QueryString["staffID"];
                BLL_StaffAccount staff = new BLL_StaffAccount();
                string name = staff.getName(staffID);

                int currentSize = Convert.ToInt32(QnA.getCurrentSize(roomID));
                int roomSize = Convert.ToInt32(QnA.getRoomSize(roomID));


                currentSize += 1;

                if (currentSize > roomSize)
                {

                    Session.Add("roomID", e.CommandArgument);

                    //Refresh webpage
                    Page.Response.Redirect(Page.Request.Url.ToString() + "&failed=1", true);
                }
                else
                {
                    //Save into DB
                    QnA.updateChatRoom(currentSize.ToString(), roomID);

                    //insert chat room users
                    QnA.insertQnAUser(roomID, "JustSofas", name);

                    string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&roomID=" + e.CommandArgument;
                    Response.Redirect("~/A_QnA_RoomChatRoom.aspx" + queryString);
                }
            }
            else if (e.CommandName == "Delete")
            {
                WsWeLoveChairsClient QnA = new WsWeLoveChairsClient();
                string roomID = e.CommandArgument.ToString();

                int currentSize = Convert.ToInt32(QnA.getCurrentSize(roomID));

                if (currentSize != 0)
                {
                    Session["fail"] = "1";

                    //Refresh webpage
                    Page.Response.Redirect(Page.Request.Url.ToString(), true);
                }
                else
                {
                    //Delete from database
                    QnA.deleteQnARoom(roomID);

                    //Refresh webpage
                    Page.Response.Redirect(Page.Request.Url.ToString(), true);
                }
            }
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/AccountStaff.aspx" + queryString);
        }

        protected void btn_RefreshPage_Click(object sender, EventArgs e)
        {
            ViewGridView("None", "None");
        }

        protected void btn_Add_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/A_AddChatRoom.aspx" + queryString);
        }
    }
}