﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class ViewCompanyCatalogue : System.Web.UI.Page
    {
        static string command = "SELECT * FROM Products WHERE IsDeleted='False'";
        static string rewriteCommand = "SELECT * FROM Products WHERE IsDeleted='False'";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["delete"] != null)
                {
                    if (Request.QueryString["delete"].Equals("fail"))
                        Response.Write("<script>alert('Account not authorized to delete.')</script>");
                    else if (Request.QueryString["delete"].Equals("fail2"))
                        Response.Write("<script>alert('Can only delete when stock is zero(0).')</script>");
                }

                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_Product productList = new BLL_Product();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = productList.getAllProduct(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = productList.getAllProduct(command);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = productList.getAllProduct(rewriteCommand);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = productList.getAllProduct(finalCommand);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE Name LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }

        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_SortOnly.SelectedValue;
            if (value.Equals("None"))
            {
                ViewGridView("None", "None");
            }
            else if (value.Equals("Category - Ottoman"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Ottoman'");
            }
            else if (value.Equals("Category - Single"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Single'");
            }
            else if (value.Equals("Category - Long"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Long'");
            }
            else if (value.Equals("Category - Cushion"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Cushion'");
            }
        }

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            if (value.Equals("Product ID"))
            {
                ViewGridView("ORDERBY", "ORDER BY Product_ID ASC");
            }
            else if (value.Equals("Category"))
            {
                ViewGridView("ORDERBY", "ORDER BY Category ASC");
            }
            else if (value.Equals("Name"))
            {
                ViewGridView("ORDERBY", "ORDER BY Name ASC");
            }
            else if (value.Equals("High Price"))
            {
                ViewGridView("ORDERBY", "ORDER BY Unit_Price DESC");
            }
            else if (value.Equals("Low Price"))
            {
                ViewGridView("ORDERBY", "ORDER BY Unit_Price ASC");
            }
        }

        protected void gv_Products_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            if (position.Equals("Junior"))
            {
                if (e.CommandName == "Delete")
                {
                    string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&delete=fail";
                    Response.Redirect("~/ViewCompanyCatalogue.aspx" + queryString);
                }
            }
            else
            {
                if (e.CommandName == "Delete")
                {

                    BLL_Product product = new BLL_Product();
                    string productID = e.CommandArgument.ToString();

                    /*
                    //Delete image of item
                    string productImage = "Images\\Products\\" + currentImageUrl;
                    string fullPath = Server.MapPath("") + "\\" + productImage;
                    File.Delete(fullPath);
                    */

                    string stock = product.getStock(productID);

                    if (stock.Equals("0"))
                    {
                        //Delete from database
                        product.deleteProduct(e.CommandArgument.ToString());

                        //Refresh webpage
                        string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                        Response.Redirect("~/ViewCompanyCatalogue.aspx" + queryString);
                    }
                    else
                    {
                        string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&delete=fail2";
                        Response.Redirect("~/ViewCompanyCatalogue.aspx" + queryString);
                    }
                }
            }
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/AccountStaff.aspx" + queryString);
        }

    }

}
