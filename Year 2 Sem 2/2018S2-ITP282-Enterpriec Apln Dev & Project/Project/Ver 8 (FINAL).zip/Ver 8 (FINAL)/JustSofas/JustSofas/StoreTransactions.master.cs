﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class StoreTransactions : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_ViewSupplier(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/StoreTransactionsDelivering.aspx" + queryString);
        }

        protected void storeMenuItem(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/StoreTransactionsCompleted.aspx" + queryString);
        }
    }
}