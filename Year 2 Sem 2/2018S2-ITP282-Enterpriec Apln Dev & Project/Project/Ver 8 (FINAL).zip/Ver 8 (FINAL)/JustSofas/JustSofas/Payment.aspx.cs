﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JustSofas.BLL;

namespace JustSofas
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DateTime Date = DateTime.Now;
            tb_Date.Text = Date.ToString();
            BLL_StaffAccount payment = new BLL_StaffAccount();
            string queryString = Request.QueryString["staffID"];
            lbl_SupplierName.Text = Session["supplierName"].ToString();
            lbl_amtPayable.Text = Session["amt"].ToString();
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            //string supplierName = lbl_SupplierName.Text;
            //double amountPayable = double.Parse(lbl_amtPayable.Text);
            //int bankAccNum = int.Parse(tb_accNum.Text);
            //string bankAccType = tb_accType.Text;
            int invoiceId = int.Parse(Session["invoiceId"].ToString());
            DateTime Date = DateTime.Now;
            BLL_Payment payment = new BLL_Payment();
            BLL_Invoice invoice = new BLL_Invoice();

            payment.insertPayment(lbl_SupplierName.Text, double.Parse(lbl_amtPayable.Text), int.Parse(tb_accNum.Text), tb_accType.Text, invoiceId, Date);
            payment.insertPaymentToSupp(lbl_SupplierName.Text, double.Parse(lbl_amtPayable.Text), int.Parse(tb_accNum.Text), tb_accType.Text, invoiceId, Date.ToString());
            invoice.updateInvoiceStatus("paid", invoiceId);
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/Transaction.aspx" + queryString);
        }

        protected void btnback_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/Invoice.aspx" + queryString);
        }
    }
}