﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class EditProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Product product = new BLL_Product();
            string productID = Request.QueryString["product"];
            string creatorName = "WeLoveChairs";

            string category = product.getCategory(productID);
            string name = product.getName(productID);
            string imageUrl = product.getImageUrl(productID);

            string stock = product.getStock(productID);
            double price = product.getUnitPrice(productID);
            string desc = product.getDescription(productID);

            string reorderPoint = product.getReorderPoint(productID);
            string reorderQuantity = product.getReorderQuantity(productID);

            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            if (position.Equals("Junior"))
            {
                btn_Update.Enabled = false;
                btn_Update.Style.Add("cursor", "not-allowed");
                btn_Update.ToolTip = "Junior No Access";
            }

            if (!IsPostBack)   //MUST USE !IsPostBack IF NOT ERROR IN UPDATE
            {
                tb_ProductID.Text = Request.QueryString["product"];
                if (category.Equals("Ottoman"))
                {
                    ddl_Category.SelectedIndex = 0;
                }
                if (category.Equals("Single"))
                {
                    ddl_Category.SelectedIndex = 1;
                }
                if (category.Equals("Long"))
                {
                    ddl_Category.SelectedIndex = 2;
                }
                if (category.Equals("Cushion"))
                {
                    ddl_Category.SelectedIndex = 3;
                }

                tb_StaffName.Text = creatorName;
                img_Product.ImageUrl = imageUrl;

                tb_Name.Text = name;
                tb_Stock.Text = stock;
                tb_Price.Text = price.ToString("0.00");
                tb_Desc.Text = desc;

                tb_ReorderPoint.Text = reorderPoint;
                tb_ReorderQuantity.Text = reorderQuantity;
            }
        }

        protected void btn_Update_Click(object sender, EventArgs e)
        {
            BLL_Product product = new BLL_Product();
            string productID = Request.QueryString["product"];

            string Stock = product.getStock(productID);
            double Unit_Price = product.getUnitPrice(productID);
            string Description = product.getDescription(productID);
            string currentProductImage = product.getImageUrl(productID);
            string reorderPoint = product.getReorderPoint(productID);
            string reorderQuantity = product.getReorderQuantity(productID);

            string price = Unit_Price.ToString("0.00");

            if (!tb_Stock.Text.Equals(Stock))
            {
                //Save unit price code into DB
                product.updateStock(tb_Stock.Text, productID);
            }

            if (!tb_Price.Text.Equals(price))
            {
                //Save unit price code into DB
                product.updateUnitPrice(tb_Price.Text, productID);
            }

            if (!tb_Desc.Text.Equals(Description))
            {
                //Save description into DB
                product.updateDescription(tb_Desc.Text, productID);
            }

            if (!tb_ReorderPoint.Text.Equals(reorderPoint))
            {
                //Save reorder point into DB
                product.updateReorderPoint(tb_ReorderPoint.Text, productID);
            }

            if (!tb_ReorderQuantity.Text.Equals(reorderQuantity))
            {
                //Save reorder quantity into DB
                product.updateReorderQuantity(tb_ReorderQuantity.Text, productID);
            }

            if (tb_ReorderPoint.Text.Equals(reorderPoint)
                    && tb_Price.Text.Equals(price) && tb_Stock.Equals(Stock)
                    && tb_Desc.Text.Equals(Description) && tb_ReorderQuantity.Text.Equals(reorderQuantity))
            {
                Response.Write("<script>alert('No changes made')</script>");
            }
            else //Changes made
            {
                //Goes back to previous page
                string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                Response.Redirect("~/ViewCompanyCatalogue.aspx" + queryString);
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewCompanyCatalogue.aspx" + queryString);
        }
    }
}