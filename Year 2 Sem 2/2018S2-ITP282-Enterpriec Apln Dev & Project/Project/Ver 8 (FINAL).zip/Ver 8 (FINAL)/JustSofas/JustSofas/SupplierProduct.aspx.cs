﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class SupplierProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Product_Ws product = new BLL_Product_Ws();
            string productID = Request.QueryString["product"];

            string category = product.getCategory(productID);
            string imageUrl = product.getImageUrl(productID);
            string name = product.getName(productID);
            double price = product.getUnitPrice(productID);
            string desc = product.getDescription(productID);
            string creatorName = "WeLoveChairs";
            string dateCreated = product.getDateCreated(productID);

            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            if (position.Equals("Junior"))
            {
                btn_Update.Enabled = false;
                btn_Update.Style.Add("cursor", "not-allowed");
                btn_Update.ToolTip = "Junior No Access";
            }

            if (!IsPostBack)   //MUST USE !IsPostBack IF NOT ERROR IN UPDATE
            {
                tb_ProductID.Text = Request.QueryString["product"];
                if (category.Equals("Ottoman"))
                {
                    ddl_Category.SelectedIndex = 0;
                }
                if (category.Equals("Single"))
                {
                    ddl_Category.SelectedIndex = 1;
                }
                if (category.Equals("Long"))
                {
                    ddl_Category.SelectedIndex = 2;
                }
                if (category.Equals("Cushion"))
                {
                    ddl_Category.SelectedIndex = 3;
                }

                tb_Name.Text = name;

                img_Product.ImageUrl = "http://localhost:13342/Images/Products/" + productID + "/" + imageUrl;

                tb_Stock.Text = "0";
                tb_Price.Text = price.ToString("0.00");

                tb_Desc.Text = desc;

                tb_StaffName.Text = creatorName;
                tb_DateCreated.Text = dateCreated;

                tb_ReorderPoint.Text = "50";
                tb_ReorderQuantity.Text = "100";
            }
        }

        protected void btn_Update_Click(object sender, EventArgs e)
        {
            string productID = Request.QueryString["product"];

            BLL_Product_Ws wsProduct = new BLL_Product_Ws();
            string imageUrl = "http://localhost:13342/Images/Products/" + productID + "/" + wsProduct.getImageUrl(productID);

            BLL_Product product = new BLL_Product();
            Boolean nameTaken = product.checkName2(tb_Name.Text, productID);

            Boolean createProduct = false;

            if (nameTaken == true)
            {
                string isDeleted = product.getIsDeleted(productID);

                if (isDeleted.Equals("False"))
                    Response.Write("<script>alert('Product already added')</script>");
                else if (isDeleted.Equals("True"))
                {
                    //Recover product that was deleted before
                    product.updateIsDeleted(productID);

                    createProduct = true;
                }
            }
            else
            {
                // INSERT PRODUCT
                product.insertProduct(productID, ddl_Category.SelectedValue, tb_Name.Text, tb_Desc.Text, tb_Price.Text, imageUrl, tb_Stock.Text, tb_ReorderPoint.Text, tb_ReorderQuantity.Text);

                createProduct = true;
            }

            if (createProduct == true)
            {
                int reorderPoint = Convert.ToInt32(product.getReorderPoint(productID));
                int stock = Convert.ToInt32(product.getStock(productID));
                
                if (stock < reorderPoint)
                {
                    BLL_PurchaseOrder order = new BLL_PurchaseOrder();
                    Boolean orderExist = order.getOrderByProd(productID);

                    if (orderExist == true)
                    {
                        //Nothing
                    }
                    else   //Create PO since stock=0 and is new item
                    {
                        string dateOfOrder = DateTime.Now.ToString("dd/mm/yyyy");
                        int quantity = Convert.ToInt32(product.getReorderQuantity(productID));
                        string quantityStr = quantity.ToString();

                        double unitPrice = product.getUnitPrice(productID);
                        string totalAmount = (quantity * unitPrice).ToString("0.00");

                        //Insert Order
                        order = new BLL_PurchaseOrder();
                        order.insertOrder(dateOfOrder, productID, quantityStr, totalAmount);
                    }
                }

                //Goes back to previous page
                string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                Response.Redirect("~/ViewSupplierCatalogue.aspx" + queryString);
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewSupplierCatalogue.aspx" + queryString);
        }
    }
}