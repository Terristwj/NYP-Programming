﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class ViewSupplierCatalogue : System.Web.UI.Page
    {
        static string command = "SELECT * FROM Products";
        static string rewriteCommand = "SELECT * FROM Products";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {

            BLL_Product_Ws productList = new BLL_Product_Ws();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = productList.getSupplierCatalogue2(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = productList.getSupplierCatalogue2(command);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = productList.getSupplierCatalogue2(rewriteCommand);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = productList.getSupplierCatalogue2(finalCommand);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE Name LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }

        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_SortOnly.SelectedValue;
            if (value.Equals("None"))
            {
                ViewGridView("None", "None");
            }
            else if (value.Equals("Category - Ottoman"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Ottoman'");
            }
            else if (value.Equals("Category - Single"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Single'");
            }
            else if (value.Equals("Category - Long"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Long'");
            }
            else if (value.Equals("Category - Cushion"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Cushion'");
            }
        }

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            if (value.Equals("Product ID"))
            {
                ViewGridView("ORDERBY", "ORDER BY Product_ID ASC");
            }
            else if (value.Equals("Category"))
            {
                ViewGridView("ORDERBY", "ORDER BY Category ASC");
            }
            else if (value.Equals("Name"))
            {
                ViewGridView("ORDERBY", "ORDER BY Name ASC");
            }
            else if (value.Equals("High Price"))
            {
                ViewGridView("ORDERBY", "ORDER BY Unit_Price DESC");
            }
            else if (value.Equals("Low Price"))
            {
                ViewGridView("ORDERBY", "ORDER BY Unit_Price ASC");
            }
        }

        protected void gv_Products_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //Nothing
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/AccountStaff.aspx" + queryString);
        }
        
    }
}