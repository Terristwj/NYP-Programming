﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using JustSofas.BLL;

namespace JustSofas
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "WsJustSofas" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select WsJustSofas.svc or WsJustSofas.svc.cs at the Solution Explorer and start debugging.
    public class WsJustSofas : IWsJustSofas
    {
        //payment 
        public DataSet getAllPayment(string sqlCommand)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getAllPayment(sqlCommand);
        }


        public DataSet getPaymentAll(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getPaymentAll(Id);
        }

        public DataSet getpaymentID(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getpaymentID(Id);
        }
        public DataSet getsupplierName(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getsupplierName(Id);
        }

        public DataSet getamountPayable(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getamountPayable(Id);
        }

        public DataSet getbankAccNum(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getbankAccNum(Id);
        }

        public DataSet getbankAccType(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getbankAccType(Id);
        }

        public DataSet getinvoiceId(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getinvoiceId(Id);
        }
        public DataSet getpaymentDate(int Id)
        {
            BLL_Payment doList = new BLL_Payment();
            return doList.getDate(Id);
        }
        public DataSet GetPurchaseOrder(string sqlCommand) {

            JustSofas.BLL.BLL_PurchaseOrder bizLayerPurchaseOrder;
            bizLayerPurchaseOrder = new JustSofas.BLL.BLL_PurchaseOrder();

            return bizLayerPurchaseOrder.getAllPurchaseOrder(sqlCommand);

        }

        public DataSet GetPurchaseOrderDetails(int POId)
        {

            JustSofas.BLL.BLL_PurchaseOrder bizLayerPurchaseOrder;
            bizLayerPurchaseOrder = new JustSofas.BLL.BLL_PurchaseOrder();

            return bizLayerPurchaseOrder.getPurchaseOrderDetails(POId);

        }


        public string getPOrderID(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getPOrderID(PurchaseID);

        }
        public string getSupNmame(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getSupNmame(PurchaseID);

        }


        public string getSupEmail(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getSupEmail(PurchaseID);

        }



        public string getSupAddress(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getSupAddress(PurchaseID);

        }

        public string getSupContact(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getSupContact(PurchaseID);

        }


        //////company


        public string getCoyName(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getCoyName(PurchaseID);

        }


        public string getCoyEmail(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getCoyEmail(PurchaseID);

        }


        public string getCoyAddress(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getCoyAddress(PurchaseID);

        }


        public string getCoyContact(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getCoyContact(PurchaseID);

        }

        //////purchase


        public string getDate(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getDate(PurchaseID);

        }



        public string getStatus(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getStatus(PurchaseID);

        }



        public string getQty(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getQty(PurchaseID);

        }

        public string getProductId(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getProductId(PurchaseID);

        }

        public string getProductName(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getProductName(PurchaseID);

        }


        public string getProductDesc(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getProductDesc(PurchaseID);

        }

        public string getProductunitPrice(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getProductunitPrice(PurchaseID);

        }

        public string getProductTotal(int PurchaseID)
        {

            BLL_PurchaseOrder product = new BLL_PurchaseOrder();
            return product.getProductTotal(PurchaseID);

        }

    }
}
