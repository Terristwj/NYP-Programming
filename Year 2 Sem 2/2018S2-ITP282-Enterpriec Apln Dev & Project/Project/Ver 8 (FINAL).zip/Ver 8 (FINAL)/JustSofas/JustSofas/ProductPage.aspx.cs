﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class ProductPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Product product = new BLL_Product();

            string productID = Request.QueryString["product"];
            string imageUrl = product.getImageUrl(productID);
            string name = product.getName(productID);
            string stock = product.getStock(productID);
            double price = product.getUnitPrice(productID);
            string desc = product.getDescription(productID);

            if (!IsPostBack)
            {
                lb_Name.Text = name;
                img_Product.ImageUrl = imageUrl;

                lb_Stock.Text = "Stock: " + stock;
                lb_Price.Text = "Price: $" + price.ToString("0.00"); ;

                tb_Desc.Text = "Description: " + desc;
                tb_Qty.Text = "1";
            }

            Page.Title = name;

            if (Request.QueryString["login"].Equals("false") || Request.QueryString["staffID"] != null)
            {
                tb_Qty.Enabled = false;
                tb_Qty.Text = "";
                tb_Qty.Style.Add("cursor", "not-allowed");

                btn_Add.Enabled = false;
                btn_Add.Style.Add("cursor", "not-allowed");
            }
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["login"] == "false")
            {
                queryString = "?login=false";
            }
            else if (Request.QueryString["custID"] != null)
            {
                queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            }


            BLL_Product product = new BLL_Product();
            string productID = Request.QueryString["product"];
            string Category = product.getCategory(productID);

            string btn_BackUrl = "";

            if (Category.Equals("Ottoman"))
                btn_BackUrl = "~/CatalogueOttoman.aspx";
            else if (Category.Equals("Single"))
                btn_BackUrl = "~/CatalogueSingle.aspx";
            else if (Category.Equals("Long"))
                btn_BackUrl = "~/CatalogueLong.aspx";
            else if (Category.Equals("Cushion"))
                btn_BackUrl = "~/CatalogueCusion.aspx";

            Response.Redirect(btn_BackUrl + queryString);
        }
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if (tb_Qty.Text.Length > 1 && tb_Qty.Text.Substring(0, 1).Equals("0"))
            {
                Response.Write("<script>alert('Invalid Qauntity. Cannot start with 0.')</script>");
            }
            else
            {
                BLL_Product product = new BLL_Product();
                string productID = Request.QueryString["product"];
                string custID = Request.QueryString["custID"];

                string stockString = product.getStock(productID);
                int stock = Convert.ToInt32(stockString);

                if (stock > 0)
                {
                    if (Convert.ToInt32(tb_Qty.Text) <= stock)
                    {
                        BLL_ShoppingItem item = new BLL_ShoppingItem();
                        Boolean shoppingItemExist = item.getShoppingItemExist(custID, productID);

                        if (shoppingItemExist == true)
                        {
                            int quantity = item.getQuantity(custID, productID);

                            int newQuantity = quantity + Convert.ToInt32(tb_Qty.Text);
                            string newQuantityStr = newQuantity.ToString();

                            //Save into DB
                            item.updateQuantity(newQuantityStr, custID, productID);
                        }
                        else
                        {
                            string primaryKey = custID + "_" + productID;
                            string quantity = tb_Qty.Text;

                            //Insert into DB
                            item.insertShoppingItem(primaryKey, custID, productID, quantity);
                        }

                        Response.Write("<script>alert('Item Added')</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Not Enough Stock')</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Item Out Of Stock')</script>");
                }
            }
        }
    }
}