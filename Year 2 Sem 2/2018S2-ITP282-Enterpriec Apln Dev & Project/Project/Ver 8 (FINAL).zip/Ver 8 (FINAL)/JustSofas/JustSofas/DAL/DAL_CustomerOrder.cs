﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using JustSofas.WeLoveChairs;
using System.Web;
using JustSofas.WeLoveChairs.svc;

namespace JustSofas.DAL
{
    public class DAL_CustomerOrder
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        //update status from supplier
        public DataSet UpdateCustomerOrderStatus(int OrderNO)
        {
            WsWeLoveChairsClient status = new WsWeLoveChairsClient();
            return status.UpdateCustomerOrderStatus(OrderNO);
        }
        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet order;

            SqlConnection conn = dbConn.GetConnection();
            order = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(order);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return order;
        }

        public void insertCustomerOrder(string custID, string totalPrice, string netPrice, string dateOfOrder, string deliveryDate, string deliveryAddress)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [CustomerOrder](custID, totalPrice, netPrice, dateOfOrder, deliveryDate, deliveryAddress) VALUES(@custID, @totalPrice, @netPrice, @dateOfOrder, @deliveryDate, @deliveryAddress)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@custID", custID);
                com.Parameters.AddWithValue("@totalPrice", totalPrice);
                com.Parameters.AddWithValue("@netPrice", netPrice);
                com.Parameters.AddWithValue("@dateOfOrder", dateOfOrder);
                com.Parameters.AddWithValue("@deliveryDate", deliveryDate);
                com.Parameters.AddWithValue("@deliveryAddress", deliveryAddress);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet getOrderID(string custID, string dateOfOrder)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT orderID FROM CustomerOrder WHERE custID=@custID AND dateOfOrder=@dateOfOrder");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@custID", custID);
                da.SelectCommand.Parameters.AddWithValue("@dateOfOrder", dateOfOrder);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet commonGet(string selectVariable, string orderID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM CustomerOrder WHERE orderID=@orderID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@orderID", orderID);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet getOrderStatus(string orderID)
        {
            return commonGet("orderStatus", orderID);
        }

        //supplier CO
        public DataSet getCO(string sqlcommand)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getAllCustomerOrder(sqlcommand);
        }


        public string getCOrderID(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCOrderID(CustomerOrderID);
        }

    
        public string getSupName(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupName(CustomerOrderID);
        }

        public string getSupEmail(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupEmail(CustomerOrderID);
        }

   
        public string getSupAddress(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupAddress(CustomerOrderID);
        }
       
        public string getSupContact(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupContact(CustomerOrderID);
        }
   
        public string getCoyName(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCoyName(CustomerOrderID);
        }
    
        public string getCoyEmail(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCoyEmail(CustomerOrderID);
        }
  
        public string getCoyAddress(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCoyAddress(CustomerOrderID);
        }

        public string getCoyContact(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCoyContact(CustomerOrderID);
        }
 
        public string getDate(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDate(CustomerOrderID);
        }

 
        public string getStatus(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getStatus(CustomerOrderID);
        }

        public string getQty(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getQty(CustomerOrderID);
        }

        public string getProductId(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductId(CustomerOrderID);
        }

        public string getProductName(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductName(CustomerOrderID);
        }
    
        public string getProductDesc(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductDesc(CustomerOrderID);
        }
   
        public string getProductunitPrice(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductunitPrice(CustomerOrderID);
        }
        public string getProductTotal(int CustomerOrderID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductTotal(CustomerOrderID);
        }
    }
}