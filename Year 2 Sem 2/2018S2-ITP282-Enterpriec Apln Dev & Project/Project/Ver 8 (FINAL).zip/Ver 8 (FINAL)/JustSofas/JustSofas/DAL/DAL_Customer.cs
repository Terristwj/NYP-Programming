﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_Customer
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public DataSet getAll()
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet customerData;

            SqlConnection conn = dbConn.GetConnection();
            customerData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM Customer");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(customerData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return customerData;
        }

        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet custAccountsData;

            SqlConnection conn = dbConn.GetConnection();
            custAccountsData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(custAccountsData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return custAccountsData;
        }

        public DataSet getAllWhere(string whereCondition, string whereValue)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet customerAccountData;

            SqlConnection conn = dbConn.GetConnection();
            customerAccountData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM Customer WHERE " + whereCondition + "=@whereValue");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@whereValue", whereValue);
                da.Fill(customerAccountData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return customerAccountData;
        }

        public DataSet getCustID(string username)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet custAccountData;

            SqlConnection conn = dbConn.GetConnection();
            custAccountData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT custID FROM Customer WHERE username=@username");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@username", username);
                da.Fill(custAccountData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return custAccountData;
        }

        public DataSet commonGet(string selectVariable, string custID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM Customer WHERE custID=@custID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@custID", custID);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet getCustName(string product_ID)
        {
            return commonGet("custName", product_ID);
        }

        public DataSet getCustEmail(string product_ID)
        {
            return commonGet("custEmail", product_ID);
        }

        public DataSet getCustAddress(string product_ID)
        {
            return commonGet("custAddress", product_ID);
        }

        public DataSet getZipCode(string product_ID)
        {
            return commonGet("zipCode", product_ID);
        }

        public DataSet getCustContact(string product_ID)
        {
            return commonGet("custContact", product_ID);
        }

        public DataSet getUsername(string product_ID)
        {
            return commonGet("username", product_ID);
        }

        public DataSet getPassword(string product_ID)
        {
            return commonGet("password", product_ID);
        }

        public DataSet getBackgroundUrl(string product_ID)
        {
            return commonGet("backgroundUrl", product_ID);
        }

        public DataSet getProfileUrl(string product_ID)
        {
            return commonGet("profileUrl", product_ID);
        }

        public DataSet getAboutDesc(string product_ID)
        {
            return commonGet("aboutDesc", product_ID);
        }

        public DataSet getDateJoined(string product_ID)
        {
            return commonGet("dateJoined", product_ID);
        }

        public DataSet getLastActivity(string product_ID)
        {
            return commonGet("lastActivity", product_ID);
        }

        public void insertCustomer(string name, string email, string address, string zipCode, string contact, string username, string password, string aboutDesc, string dateJoinedStr)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [Customer](custName, custEmail, custAddress, zipCode, custContact, username, password, aboutDesc, dateJoined, lastActivity) values(@custName, @custEmail, @custAddress, @zipCode, @custContact, @username, @password, @aboutDesc, @dateJoined, @lastActivity)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@custName", name);
                com.Parameters.AddWithValue("@custEmail", email);
                com.Parameters.AddWithValue("@custAddress", address);
                com.Parameters.AddWithValue("@zipCode", zipCode);
                com.Parameters.AddWithValue("@custContact", contact);
                com.Parameters.AddWithValue("@username", username);
                com.Parameters.AddWithValue("@password", password);

                com.Parameters.AddWithValue("@aboutDesc", aboutDesc);
                com.Parameters.AddWithValue("@dateJoined", dateJoinedStr);
                com.Parameters.AddWithValue("@lastActivity", dateJoinedStr);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void commonUpdate(string updateVariable, string updateVariableValue, string custID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("UPDATE Customer SET " + updateVariable + "=@updateVariableValue WHERE custID=@custID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@updateVariableValue", updateVariableValue);
                com.Parameters.AddWithValue("@custID", custID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
        public void updateCustName(string custName, string custID)
        {
            commonUpdate("custName", custName, custID);
        }
        public void updateCustEmail(string custEmail, string custID)
        {
            commonUpdate("custEmail", custEmail, custID);
        }
        public void updateCustAddress(string custAddress, string custID)
        {
            commonUpdate("custAddress", custAddress, custID);
        }
        public void updateZipCode(string zipCode, string custID)
        {
            commonUpdate("zipCode", zipCode, custID);
        }
        public void updateCustContact(string custContact, string custID)
        {
            commonUpdate("custContact", custContact, custID);
        }
        public void updatePassword(string password, string custID)
        {
            commonUpdate("password", password, custID);
        }
        public void updateBackgroundUrl(string backgroundUrl, string custID)
        {
            commonUpdate("backgroundUrl", backgroundUrl, custID);
        }
        public void updateProfileUrl(string profileUrl, string custID)
        {
            commonUpdate("profileUrl", profileUrl, custID);
        }
        public void updateAboutDesc(string aboutDesc, string custID)
        {
            commonUpdate("aboutDesc", aboutDesc, custID);
        }
        public void updateLastActivity(string lastActivity, string custID)
        {
            commonUpdate("lastActivity", lastActivity, custID);
        }
    }
}