﻿using JustSofas.WeLoveChairs.svc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_Product_Ws
    {
        public DataSet getSupplierCatalogue()
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.GetSupplierCatalogue();
        }

        public DataSet getSupplierCatalogue2(string sqlCommand)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.GetSupplierCatalogue2(sqlCommand);
        }

        public DataSet getImageUrl(string productID)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.getImageUrl(productID);
        }

        public DataSet getName(string productID)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.getName(productID);
        }

        public DataSet getUnitPrice(string productID)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.getUnitPrice(productID);
        }

        public DataSet getDescription(string productID)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.getDescription(productID);
        }

        public DataSet getCategory(string productID)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.getCategory(productID);
        }

        public DataSet getDateCreated(string productID)
        {
            WsWeLoveChairsClient WeLoveChairsClient = new WsWeLoveChairsClient();
            return WeLoveChairsClient.getDateCreated(productID);
        }
    }
}