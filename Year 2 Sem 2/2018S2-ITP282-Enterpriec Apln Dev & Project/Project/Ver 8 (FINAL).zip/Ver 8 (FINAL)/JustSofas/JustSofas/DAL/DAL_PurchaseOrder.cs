﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_PurchaseOrder
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet PurchaseOrderData;

            SqlConnection conn = dbConn.GetConnection();
            PurchaseOrderData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(PurchaseOrderData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return PurchaseOrderData;
        }

        public DataSet getPurchaseOrderDetails(int POId) {

            StringBuilder sql;
            SqlDataAdapter da;
            DataSet PurchaseOrderData;

            SqlConnection conn = dbConn.GetConnection();
            PurchaseOrderData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT Id, CompanyName, Address, Email, dateOfOrder, Status, po.ProductID, PName, Quantity, TotalAmount");
            sql.AppendLine("FROM PurchaseOrder po");
            sql.AppendLine("INNER JOIN Products p ON po.ProductID = p.Product_ID");
            sql.AppendLine("WHERE Id=@paraid");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("paraid", POId);
                da.Fill(PurchaseOrderData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return PurchaseOrderData;

        }
        public void insertOrder(string DateOfOrder, string ProductID, string Quantity, string TotalAmount)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [PurchaseOrder](DateOfOrder, ProductID, Quantity, TotalAmount) VALUES(@DateOfOrder, @ProductID, @Quantity, @TotalAmount)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@DateOfOrder", DateOfOrder);
                com.Parameters.AddWithValue("@ProductID", ProductID);
                com.Parameters.AddWithValue("@Quantity", Quantity);
                com.Parameters.AddWithValue("@TotalAmount", TotalAmount);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet getOrderByProd(string ProductID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM PurchaseOrder WHERE ProductID=@ProductID AND Status!='rejected'");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@ProductID", ProductID);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet commonGet(string selectVariable, int Id)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM PurchaseOrder po INNER JOIN Products p ON po.ProductID = p.Product_ID WHERE Id=@Id");
            
            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@Id", Id);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }



        //supplier

        public DataSet getPOrderID(int PurchaseID)
        {

            return commonGet("Id", PurchaseID);

        }
        public DataSet getSupName(int PurchaseID)
        {

            return commonGet("SupplierName", PurchaseID);

        }

        public DataSet getSupEmail(int PurchaseID)
        {

            return commonGet("SupplierEmail", PurchaseID);

        }

        public DataSet getSupAddress(int PurchaseID)
        {

            return commonGet("SupplierAddress", PurchaseID);

        }

        public DataSet getSupContact(int PurchaseID)
        {

            return commonGet("SupplierContact", PurchaseID);

        }

        //company
        public DataSet getCoyName(int PurchaseID)
        {

            return commonGet("CompanyName", PurchaseID);

        }

        public DataSet getCoyEmail(int PurchaseID)
        {

            return commonGet("Email", PurchaseID);

        }

        public DataSet getCoyAddress(int PurchaseID)
        {

            return commonGet("Address", PurchaseID);

        }

        public DataSet getCoyContact(int PurchaseID)
        {

            return commonGet("Contact", PurchaseID);

        }
        //purchase
        public DataSet getDate(int PurchaseID)
        {

            return commonGet("dateOfOrder", PurchaseID);

        }

        public DataSet getStatus(int PurchaseID)
        {

            return commonGet("Status", PurchaseID);

        }

        public DataSet getQty(int PurchaseID)
        {

            return commonGet("Quantity", PurchaseID);

        }

        public DataSet getProductId(int PurchaseID)
        {

            return commonGet("ProductID", PurchaseID);

        }

        public DataSet getProductName(int PurchaseID)
        {

            return commonGet("Name", PurchaseID);

        }
        public DataSet getProductDesc(int PurchaseID)
        {

            return commonGet("Description", PurchaseID);

        }

        public DataSet getProductunitPrice(int PurchaseID)
        {

            return commonGet("Unit_Price", PurchaseID);

        }
        public DataSet getProductTotal(int PurchaseID)
        {

            return commonGet("TotalAmount", PurchaseID);

        }
    }
}