﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_Product
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet getProductID(string name)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT Product_ID FROM Products WHERE Name=@Name");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@Name", name);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet checkName(string name, string product_ID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT Name FROM Products WHERE Name=@Name AND Product_ID=@Product_ID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@Name", name);
                da.SelectCommand.Parameters.AddWithValue("@Product_ID", product_ID);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet commonGet(string selectVariable, string product_ID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM Products WHERE Product_ID=@product_ID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@product_ID", product_ID);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet getImageUrl(string product_ID)
        {
            return commonGet("ImageUrl", product_ID);
        }

        public DataSet getName(string product_ID)
        {
            return commonGet("Name", product_ID);
        }

        public DataSet getUnitPrice(string product_ID)
        {
            return commonGet("Unit_Price", product_ID);
        }

        public DataSet getDescription(string product_ID)
        {
            return commonGet("Description", product_ID);
        }

        public DataSet getCategory(string product_ID)
        {
            return commonGet("Category", product_ID);
        }

        public DataSet getStock(string product_ID)
        {
            return commonGet("Stock", product_ID);
        }

        public DataSet getReorderPoint(string product_ID)
        {
            return commonGet("Reorder_Point", product_ID);
        }

        public DataSet getReorderQuantity(string product_ID)
        {
            return commonGet("Reorder_Quantity", product_ID);
        }

        public DataSet getIsDeleted(string product_ID)
        {
            return commonGet("IsDeleted", product_ID);
        }

        public void deleteProduct(string product_ID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("UPDATE Products SET IsDeleted=@IsDeleted WHERE Product_ID=@Product_ID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@IsDeleted", "True");
                com.Parameters.AddWithValue("@Product_ID", product_ID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void insertProduct(string Product_ID, string Category, string Name, string Description, string Unit_Price, string ImageUrl, string Stock, string Reorder_Point, string Reorder_Quantity)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [Products](Product_ID, Category, Name, Description, Unit_Price, ImageUrl, Stock, Reorder_Point, Reorder_Quantity) VALUES(@Product_ID, @Category, @Name, @Description, @Unit_Price, @ImageUrl, @Stock, @Reorder_Point, @Reorder_Quantity)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@Product_ID", Product_ID);
                com.Parameters.AddWithValue("@Category", Category);
                com.Parameters.AddWithValue("@Name", Name);
                com.Parameters.AddWithValue("@Description", Description);
                com.Parameters.AddWithValue("@Unit_Price", Unit_Price);
                com.Parameters.AddWithValue("@ImageUrl", ImageUrl);
                com.Parameters.AddWithValue("@Stock", Stock);
                com.Parameters.AddWithValue("@Reorder_Point", Reorder_Point);
                com.Parameters.AddWithValue("@Reorder_Quantity", Reorder_Quantity);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void commonUpdate(string updateVariable, string updateVariableValue, string Product_ID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("UPDATE Products SET " + updateVariable + "=@updateVariableValue WHERE Product_ID=@Product_ID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@updateVariableValue", updateVariableValue);
                com.Parameters.AddWithValue("@Product_ID", Product_ID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void updateCategory(string Category, string Product_ID)
        {
            commonUpdate("Category", Category, Product_ID);
        }

        public void updateName(string Name, string Product_ID)
        {
            commonUpdate("Name", Name, Product_ID);
        }

        public void updateUnitPrice(string Unit_Price, string Product_ID)
        {
            commonUpdate("Unit_Price", Unit_Price, Product_ID);
        }

        public void updateDescription(string Description, string Product_ID)
        {
            commonUpdate("Description", Description, Product_ID);
        }

        public void updateImageUrl(string ImageUrl, string Product_ID)
        {
            commonUpdate("ImageUrl", ImageUrl, Product_ID);
        }

        public void updateStock(string Stock, string Product_ID)
        {
            commonUpdate("Stock", Stock, Product_ID);
        }

        public void updateReorderPoint(string Reorder_Point, string Product_ID)
        {
            commonUpdate("Reorder_Point", Reorder_Point, Product_ID);
        }

        public void updateReorderQuantity(string Reorder_Quantity, string Product_ID)
        {
            commonUpdate("Reorder_Quantity", Reorder_Quantity, Product_ID);
        }

        public void updateIsDeleted(string Product_ID)
        {
            commonUpdate("IsDeleted", "False", Product_ID);
        }
    }
}