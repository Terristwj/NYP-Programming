﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_CreditCard
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public DataSet getAll(string customerID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet creditCardData;

            SqlConnection conn = dbConn.GetConnection();
            creditCardData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM creditCard WHERE customerID=@customerID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@customerID", customerID);
                da.Fill(creditCardData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return creditCardData;
        }

        public DataSet getAll2(string cardNumber_userID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet creditCardData;

            SqlConnection conn = dbConn.GetConnection();
            creditCardData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM creditCard WHERE cardNumber_userID=@cardNumber_userID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@cardNumber_userID", cardNumber_userID);
                da.Fill(creditCardData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return creditCardData;
        }

        public int getNumberCC(string customerID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet creditCardData;
            int numberCC = 0;

            SqlConnection conn = dbConn.GetConnection();
            creditCardData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT COUNT(*) FROM creditCard WHERE customerID=@customerID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@customerID", customerID);
                da.Fill(creditCardData);

                DataTable dt = new DataTable();
                dt = creditCardData.Tables[0];                             // Connect DT to DS

                numberCC = Convert.ToInt32(dt.Rows[0]["COUNT(*)"].ToString());
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return numberCC;
        }

        public void insertCreditCard(string customerID, string cardNumber, string cardType, string expires, string country, string firstName, string lastName, string cardImageUrl, string cardNumber_userID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [creditCard](customerID, cardNumber, cardType, expires, country, firstName, lastName, cardImageUrl, cardNumber_userID) VALUES(@custID, @cardNumber, @cardType, @expires, @country, @firstName, @lastName, @cardImageUrl, @cardNumber_userID)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@custID", customerID);
                com.Parameters.AddWithValue("@cardNumber", cardNumber);
                com.Parameters.AddWithValue("@cardType", cardType);
                com.Parameters.AddWithValue("@expires", expires);
                com.Parameters.AddWithValue("@country", country);
                com.Parameters.AddWithValue("@firstName", firstName);
                com.Parameters.AddWithValue("@lastName", lastName);
                com.Parameters.AddWithValue("@cardImageUrl", cardImageUrl);
                com.Parameters.AddWithValue("@cardNumber_userID", cardNumber_userID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void deleteCC(string cardNumber_userID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("DELETE creditCard WHERE cardNumber_userID = @cardNumber_userID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@cardNumber_userID", cardNumber_userID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}