﻿using JustSofas.WeLoveChairs.svc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_DeliveryOrder
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        //update status from supplier
        public DataSet UpdateDeliveryStatus(int DeliveryId)
        {
            WsWeLoveChairsClient status = new WsWeLoveChairsClient();
            return status.UpdateDeliveryStatus(DeliveryId);
        }
        //getfromsupplier
        public DataSet getAllDeliveryOrder(string sqlCommand)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getAllDeliveryOrder(sqlCommand);
        }
        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet deliveryOrderData;

            SqlConnection conn = dbConn.GetConnection();
            deliveryOrderData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(deliveryOrderData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return deliveryOrderData;
        }



        public string getDeliveryOrderID(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDeliveryOrderID(Id);
        }

        public string getDeliveryOrderDate(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDeliveryOrderDate(Id);
        }

        public string getDeliveryOrderTime(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDeliveryOrderTime(Id);
        }

        public string getDeliveryOrderStatus(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDeliveryOrderStatus(Id);
        }

        public string getDeliveryOrderCoy(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDeliveryOrderCoy(Id);
        }

        public string getProductIdDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductIdDO(Id);
        }

        public string getQuantityDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getQuantityDO(Id);
        }

        public string getUnitPriceDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getUnitPriceDO(Id);
        }

        public string getProductNameDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductNameDO(Id);
        }

        public string getDispatchDate(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getDispatchDate(Id);
        }

        public string getCompanyNameDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyNameDO(Id);
        }

        public string getCompanyEmailDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyEmailDO(Id);
        }

        public string getCompanyContactDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyContactDO(Id);
        }

        public string getCompanyAddressDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyAddressDO(Id);
        }

        public string getSupplierNameDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierNameDO(Id);
        }

        public string getInvoiceStatusDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getInvoiceStatusDO(Id);
        }

        public string getTotalPriceDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getTotalPriceDO(Id);
        }

        public string getSupplierAddressDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierAddressDO(Id);
        }

        public string getSupplierEmailDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierEmailDO(Id);
        }

        public string getSupplierContactDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierContactDO(Id);
        }

        public string getInvoiceDescDO(int Id)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getInvoiceDescDO(Id);
        }
    }
}