﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using JustSofas.WeLoveChairs;
using JustSofas.WeLoveChairs.svc;

namespace JustSofas.DAL
{
    public class DAL_Invoice
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();


        //invoice from supplier 
        public DataSet getInvoice(string sqlCommand)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getAllInvoice(sqlCommand);
        }

        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet InvoiceData;

            SqlConnection conn = dbConn.GetConnection();
            InvoiceData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(InvoiceData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return InvoiceData;
        }

        public string getInvoiceID(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getInvoiceID(invoiceID);
        }

        public string getSupplierName(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierName(invoiceID);
        }

        public string getInvoiceStatus(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getInvoiceStatus(invoiceID);
        }

        public string getInvoiceDate(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getInvoiceDate(invoiceID);
        }

        public string getSupplierAddress(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierAddress(invoiceID);
        }

        public string getSupplierEmail(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierEmail(invoiceID);
        }

        public string getSupplierContact(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getSupplierContact(invoiceID);
        }

        public string getCompanyName(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyName(invoiceID);
        }

        public string getCompanyEmail(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyEmail(invoiceID);
        }

        public string getCompanyContact(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyContact(invoiceID);
        }

        public string getCompanyAddress(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getCompanyAddress(invoiceID);
        }

        public string getProductId(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductId(invoiceID);
        }

        public string getProductName(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getProductName(invoiceID);
        }

        public string getQuantity(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getQuantity(invoiceID);
        }

        public string getUnitPriceInvoice(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getUnitPriceInvoice(invoiceID);
        }

        public string getTotalPrice(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getTotalPrice(invoiceID);
        }
        public string getInvoiceDesc(int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            return weLoveChairsClient.getInvoiceDesc(invoiceID);
        }

        public void updateInvoiceStatus(string invoiceStatus, int invoiceID)
        {
            WsWeLoveChairsClient weLoveChairsClient;
            weLoveChairsClient = new WsWeLoveChairsClient();
            weLoveChairsClient.UpdateInvoiceStatus(invoiceStatus, invoiceID);
        }
    }
}