﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_AboutMeText
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public DataSet getDefaultAboutDesc()
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet aboutMeData;

            SqlConnection conn = dbConn.GetConnection();
            aboutMeData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM AboutMeText");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(aboutMeData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return aboutMeData;
        }
    }
}