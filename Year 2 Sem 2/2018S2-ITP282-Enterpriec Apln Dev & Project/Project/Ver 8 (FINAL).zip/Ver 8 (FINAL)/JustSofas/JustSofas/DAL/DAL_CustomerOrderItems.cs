﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_CustomerOrderItems
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public void insertItem(string orderID_Product_ID, string order_ID, string product_ID, string quantity)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [CustomerOrderItems](orderID_Product_ID, order_ID, product_ID, quantity) VALUES(@orderID_Product_ID, @order_ID, @product_ID, @quantity)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@orderID_Product_ID", orderID_Product_ID);
                com.Parameters.AddWithValue("@order_ID", order_ID);
                com.Parameters.AddWithValue("@product_ID", product_ID);
                com.Parameters.AddWithValue("@quantity", quantity);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}