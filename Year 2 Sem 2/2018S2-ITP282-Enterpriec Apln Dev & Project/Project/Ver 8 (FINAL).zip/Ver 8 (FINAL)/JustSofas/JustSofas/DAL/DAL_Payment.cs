﻿using JustSofas.WeLoveChairs.svc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_Payment
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public void insertPayment(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, DateTime Date)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO StaffPayment (supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date) ");
            sql.AppendLine(" ");
            sql.AppendLine("VALUES(@supplierName, @amountPayable, @bankAccNum, @bankAccType, @invoiceId, @Date)");

            try
            {
                conn.Open();
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@supplierName", supplierName);
                com.Parameters.AddWithValue("@amountPayable", amountPayable);
                com.Parameters.AddWithValue("@bankAccNum", bankAccNum);
                com.Parameters.AddWithValue("@bankAccType", bankAccType);
                com.Parameters.AddWithValue("@invoiceId", invoiceId);
                com.Parameters.AddWithValue("@Date", Date);
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet paymentData;

            SqlConnection conn = dbConn.GetConnection();
            paymentData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(paymentData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return paymentData;
        }
        public DataSet getPaymentDetail(string selectVariable, int Id)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet PaymentData;

            SqlConnection conn = dbConn.GetConnection();
            PaymentData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM StaffPayment WHERE paymentID=@Id");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@Id", Id);
                da.Fill(PaymentData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return PaymentData;
        }
        public DataSet getPaymentAll(int Id)
        {
            return getPaymentDetail("*", Id);
        }
        public DataSet getpaymentID(int Id)
        {
            return getPaymentDetail("paymentID", Id);
        }
        public DataSet getsupplierName(int Id)
        {
            return getPaymentDetail("supplierName", Id);
        }
        public DataSet getamountPayable(int Id)
        {
            return getPaymentDetail("amountPayable", Id);
        }
        public DataSet getbankAccNum(int Id)
        {
            return getPaymentDetail("bankAccNum", Id);
        }
        public DataSet getbankAccType(int Id)
        {
            return getPaymentDetail("bankAccType", Id);
        }
        public DataSet getinvoiceId(int Id)
        {
            return getPaymentDetail("invoiceId", Id);
        }
        public DataSet getDate(int Id)
        {
            return getPaymentDetail("Date", Id);
        }

        public void insertPaymentToSupp(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, string Date)
        {
            WsWeLoveChairsClient weLoveChairsClient = new WsWeLoveChairsClient();
            weLoveChairsClient.insertPayment(supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date);
        }
    }
}