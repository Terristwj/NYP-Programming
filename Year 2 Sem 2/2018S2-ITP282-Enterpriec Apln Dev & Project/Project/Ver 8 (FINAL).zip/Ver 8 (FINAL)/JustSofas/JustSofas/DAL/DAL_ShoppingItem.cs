﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace JustSofas.DAL
{
    public class DAL_ShoppingItem
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();
        public DataSet getShoppingItem(string primaryKey)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM ShoppingItem WHERE custID_ProductID=@PrimaryKey");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@PrimaryKey", primaryKey);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet getQuantity(string primaryKey)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT Quantity FROM ShoppingItem WHERE custID_ProductID=@primaryKey");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@primaryKey", primaryKey);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public void updateQuantity(string Quantity, string custID_ProductID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("UPDATE ShoppingItem SET Quantity=@Quantity WHERE custID_ProductID=@custID_ProductID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@Quantity", Quantity);
                com.Parameters.AddWithValue("@custID_ProductID", custID_ProductID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void insertShoppingItem(string custID_ProductID, string custID, string Product_ID, string Quantity)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [ShoppingItem](custID_ProductID, custID, Product_ID, Quantity) VALUES(@custID_ProductID, @custID, @Product_ID, @Quantity)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@custID_ProductID", custID_ProductID);
                com.Parameters.AddWithValue("@custID", custID);
                com.Parameters.AddWithValue("@Product_ID", Product_ID);
                com.Parameters.AddWithValue("@Quantity", Quantity);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void deleteShoppingItem(string custID_ProductID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("DELETE FROM ShoppingItem WHERE custID_ProductID=@custID_ProductID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@custID_ProductID", custID_ProductID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        public void deleteShoppingItem2(string custID)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("DELETE FROM ShoppingItem WHERE custID=@custID");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@custID", custID);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}