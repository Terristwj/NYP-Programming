﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class AA_Sample : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Image image = new Image();
            image.ImageUrl = "~/Images/Default/Favicon.png";
            string imageurl = "asd";
            byte[] bytes = File.ReadAllBytes(Server.MapPath(imageurl));

            //Save the Byte Array as File.
            /**
            string filePath = "~/Files/" + Path.GetFileName(FileUpload1.FileName);
            File.WriteAllBytes(Server.MapPath(filePath), bytes);
            */

            //Display the Image File.
            string filePath = image.ImageUrl;
            Image1.ImageUrl = filePath;
        }
    }
}