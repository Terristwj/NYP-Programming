﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_LoginStaff_Click(object sender, EventArgs e)
        {
            BLL_StaffAccount accounts = new BLL_StaffAccount();
            Boolean accountLogin = accounts.loginStatus(tb_staffID.Text, tb_staffPassword.Text);

            if (accountLogin == true)
            {
                string staffID = accounts.getStaffID(tb_staffID.Text);
                string queryString = "?login=true" + "&staffID=" + staffID;
                Response.Redirect("~/AccountStaff.aspx" + queryString);
            }
            else
            {
                Response.Write("<script>alert('Incorrect Login')</script>");
            }
            /*   string queryString = "?login=true";
               Response.Redirect("AccountUser.aspx" + queryString);*/
        }

        protected void btn_LoginUser_Click(object sender, EventArgs e)
        {
            BLL_Customer accounts = new BLL_Customer();
            Boolean accountLogin = accounts.loginStatus(tb_username.Text, tb_password.Text);

            if (accountLogin == true)
            {
                string custID = accounts.getCustID(tb_username.Text);

                //Save last activity into DB
                DateTime currentDate = DateTime.Now;
                string currentDateStr = currentDate.ToString("dddd dd MMMM yyyy");
                accounts.updateLastActivity(currentDateStr, custID);

                // To the next page
                string queryString = "?login=true" + "&custID=" + custID;
                Response.Redirect("~/AccountUser.aspx" + queryString);
            }
            else
            {
                Response.Write("<script>alert('Incorrect Login')</script>");
            }

            /*   string queryString = "?login=true";
               Response.Redirect("AccountUser.aspx" + queryString);*/
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (RegisTxtUsername.Text != "" && RegisTxtPassword.Text != "" && RegisTxtName.Text != "" && RegisTxtEmail.Text != "" && RegisTxtAddr.Text != "" && RegisTxtZC.Text != "" && RegisTxtPN.Text != "")
            {
                BLL_Customer accounts = new BLL_Customer();
                Boolean usernameTaken = accounts.checkUsername(RegisTxtUsername.Text);

                if (usernameTaken == true)
                {
                    Response.Write("<script>alert('Username is taken')</script>");
                }
                else
                {
                    // Insert customer
                    accounts.insertCustomer(RegisTxtName.Text, RegisTxtEmail.Text, RegisTxtAddr.Text, RegisTxtZC.Text, RegisTxtPN.Text, RegisTxtUsername.Text, RegisTxtPassword.Text);
                }

                if (usernameTaken == false)
                {
                    string custID = accounts.getCustID(RegisTxtUsername.Text);
                    string queryString = "?login=true" + "&custID=" + custID;
                    Response.Redirect("~/AccountUser.aspx" + queryString);
                }
            }
            else
            {
                Response.Write("<script>alert('Please fill in all feilds')</script>");
            }
        }
    }
}