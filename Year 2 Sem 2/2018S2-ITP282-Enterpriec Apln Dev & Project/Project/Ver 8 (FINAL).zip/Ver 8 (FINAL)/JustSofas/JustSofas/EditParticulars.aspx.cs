﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class EditParticulars : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Customer customer = new BLL_Customer();
            string custID = Request.QueryString["custID"];

            string name = customer.getCustName(custID);
            string background = customer.getBackgroundUrl(custID);
            string profileImg = customer.getProfileUrl(custID);
            string username = customer.getUsername(custID);
            string email = customer.getCustEmail(custID);
            string address = customer.getCustAddress(custID);
            string zipCode = customer.getZipCode(custID);
            string phoneNumber = customer.getCustContact(custID);
            string aboutDesc = customer.getAboutDesc(custID);

            // Below is the set of information to be loaded
            if (!IsPostBack)   //MUST USE !IsPostBack IF NOT ERROR IN UPDATE
            {
                tb_name.Text = name;
                tb_Email.Text = email;
                tb_Address.Text = address;
                tb_ZipCode.Text = zipCode;
                tb_PhoneNo.Text = phoneNumber;
                tb_AboutMe.Text = aboutDesc;
            }

            if (profileImg != "DefaultProfileImage.png")
            {
                Image1.ImageUrl = "~/Images/Users/" + username + "/Avatar/" + profileImg;
                Image2.ImageUrl = "~/Images/Users/" + username + "/Avatar/" + profileImg;
                Image3.ImageUrl = "~/Images/Users/" + username + "/Avatar/" + profileImg;
            }
            else
            {
                Image1.ImageUrl = "~/Images/Default/" + profileImg;
                Image2.ImageUrl = "~/Images/Default/" + profileImg;
                Image3.ImageUrl = "~/Images/Default/" + profileImg;
            }


            if (background != "DefaultProfileBackground.jpg")
                Img_Background.ImageUrl = "~/Images/Users/" + username + "/Background/" + background;
            else
                Img_Background.ImageUrl = "~/Images/Default/" + background;
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            string avatarImage = "";
            string backgroundImage = "";
            string fullPath = "";

            Boolean passwordIsWrong = false;
            Boolean newPasswordIsEmpty = false;
            Boolean passwordEqualNewPassword = false;

            BLL_Customer customer = new BLL_Customer();
            string custID = Request.QueryString["custID"];

            string username = customer.getUsername(custID); ;
            string name = customer.getCustName(custID);
            string currentAvatarImage = customer.getProfileUrl(custID);
            string currentBackgroundImage = customer.getBackgroundUrl(custID);
            string email = customer.getCustEmail(custID);
            string address = customer.getCustAddress(custID);
            string zipCode = customer.getZipCode(custID);
            string phoneNumber = customer.getCustContact(custID);
            string password = customer.getPassword(custID);
            string aboutDesc = customer.getAboutDesc(custID);
            string dateJoined = customer.getDateJoined(custID);

            //Creates folder for first time users
            string userFolder = username;
            string path = Server.MapPath("~/Images/Users/" + userFolder + "/Avatar");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = Server.MapPath("~/Images/Users/" + userFolder + "/Background");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            if (fu_profileimage.HasFile
                && Path.GetExtension(fu_profileimage.FileName).ToLower() != ".jpg"
                && Path.GetExtension(fu_profileimage.FileName).ToLower() != ".png"
                && Path.GetExtension(fu_profileimage.FileName).ToLower() != ".gif"
                && Path.GetExtension(fu_profileimage.FileName).ToLower() != ".jpeg")
            {
                Response.Write("<script>alert('This is not an image file')</script>");
            }
            else if (fu_backgroundimage.HasFile
                && Path.GetExtension(fu_backgroundimage.FileName).ToLower() != ".jpg"
                && Path.GetExtension(fu_backgroundimage.FileName).ToLower() != ".png"
                && Path.GetExtension(fu_backgroundimage.FileName).ToLower() != ".gif"
                && Path.GetExtension(fu_backgroundimage.FileName).ToLower() != ".jpeg")
            {
                Response.Write("<script>alert('This is not an image file')</script>");
            }
            else   //After checking the images validation, proceed to each section.
            {
                if (!tb_name.Text.Equals(name))
                {
                    //Save name into DB
                    customer.updateCustName(tb_name.Text, custID);
                }

                if (!tb_Email.Text.Equals(email))
                {
                    //Save email into DB
                    customer.updateCustEmail(tb_Email.Text, custID);
                }

                if (!tb_ZipCode.Text.Equals(zipCode))
                {
                    //Save zip code into DB
                    customer.updateZipCode(tb_ZipCode.Text, custID);
                }

                if (!tb_Address.Text.Equals(address))
                {
                    //Save address into DB
                    customer.updateCustAddress(tb_Address.Text, custID);
                }

                if (!tb_PhoneNo.Text.Equals(phoneNumber))
                {
                    //Save phone number into DB
                    customer.updateCustContact(tb_PhoneNo.Text, custID);
                }

                if (tb_Password.Text.Length != 0)   //Check password
                {
                    if (tb_NewPassword.Text.Length != 0)    //Check new password
                    {
                        if (!tb_Password.Text.Equals(tb_NewPassword.Text))   //Check if new password = current password
                        {
                            if (tb_Password.Text.Equals(password))              //Check if password is correct
                            {
                                //Save password into DB
                                customer.updatePassword(tb_NewPassword.Text, custID);
                            }
                            else                                                //If password is wrong
                            {
                                passwordIsWrong = true;
                            }
                        }
                        else                                                    //If new password = current password
                        {
                            passwordEqualNewPassword = true;
                        }
                    }
                    else
                    {
                        newPasswordIsEmpty = true;
                    }
                }


                if (!tb_AboutMe.Text.Equals(aboutDesc))
                {
                    if (!tb_AboutMe.Text.Equals(""))
                    {
                        //Save about me text into DB
                        customer.updateAboutDesc(tb_AboutMe.Text, custID);
                    }
                    else    //If user keys in nothing, we auto generate them with default
                    {
                        aboutDesc = customer.makeAboutDesc(tb_name.Text);
                        customer.updateAboutDesc(aboutDesc, custID);
                    }
                }

                if (fu_profileimage.HasFile)
                {
                    //Not fist time change
                    if (currentAvatarImage != "DefaultProfileImage.png")
                    {
                        //Delete image
                        avatarImage = "Images\\Users\\" + username + "\\Avatar\\" + currentAvatarImage;
                        fullPath = Server.MapPath("") + "\\" + avatarImage;
                        File.Delete(fullPath);
                    }

                    //Add image into DB
                    customer.updateProfileUrl(fu_profileimage.FileName, custID);

                    //Change image
                    avatarImage = "Images\\Users\\" + username + "\\Avatar\\" + fu_profileimage.FileName;
                    fullPath = Server.MapPath("") + "\\" + avatarImage;
                    fu_profileimage.SaveAs(fullPath);
                }

                if (fu_backgroundimage.HasFile)
                {
                    //Fist time change
                    if (currentBackgroundImage != "DefaultProfileBackground.jpg")
                    {
                        //Delete image
                        backgroundImage = "Images\\Users\\" + username + "\\Background\\" + currentBackgroundImage;
                        fullPath = Server.MapPath("") + "\\" + backgroundImage;
                        File.Delete(fullPath);
                    }

                    //Add image into DB
                    customer.updateBackgroundUrl(fu_backgroundimage.FileName, custID);

                    //Change image
                    backgroundImage = "Images\\Users\\" + username + "\\Background\\" + fu_backgroundimage.FileName;
                    fullPath = Server.MapPath("") + "\\" + backgroundImage;
                    fu_backgroundimage.SaveAs(fullPath);
                }

                if (!fu_profileimage.HasFile && !fu_backgroundimage.HasFile && tb_name.Text.Equals(name)
                    && tb_Email.Text.Equals(email) && tb_Address.Text.Equals(address) && tb_ZipCode.Text.Equals(zipCode)
                    && tb_PhoneNo.Text.Equals(phoneNumber) && tb_Password.Text.Length == 0 && tb_AboutMe.Text.Equals(aboutDesc))
                {
                    Response.Write("<script>alert('No changes made')</script>");
                }

                else if (passwordIsWrong == true || newPasswordIsEmpty == true)
                {
                    Response.Write("<script>alert('Password Change Failed')</script>");
                }

                else if (passwordEqualNewPassword == true)
                {
                    Response.Write("<script>alert('Password Is The Same')</script>");
                }
                else //Changes made
                {
                    //Refresh webpage
                    Page.Response.Redirect(Page.Request.Url.ToString(), true);
                }
            }
        }

        protected void btn_back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
            Response.Redirect("~/AccountUser.aspx" + queryString);
        }

        protected void btn_AddFunds_Click(object sender, EventArgs e)
        {
            string[] account = checkUser();

            if (tb_AddFundsUsername.Text.Equals(account[0]) && tb_AddFundsPassword.Text.Equals(account[1]))
            {
                string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
                Response.Redirect("~/CreditCard.aspx" + queryString);
            }
            else
            {
                Response.Write("<script>alert('Incorrect')</script>");
            }
        }

        protected void btn_Transactions_Click(object sender, EventArgs e)
        {
            string[] account = checkUser();

            if (tb_TransactionsUsername.Text.Equals(account[0]) && tb_TransactionsPassword.Text.Equals(account[1]))
            {
                string queryString = "?login=true" + "&custID=" + Request.QueryString["custID"];
                Response.Redirect("~/ProfilePageTransactions.aspx" + queryString);
            }
            else
            {
                Response.Write("<script>alert('Incorrect')</script>");
            }
        }

        private string[] checkUser()
        {
            string[] account = new string[2];

            BLL_Customer customer = new BLL_Customer();
            string custID = Request.QueryString["custID"];

            string username = customer.getUsername(custID);
            string password = customer.getPassword(custID);

            account[0] = username;
            account[1] = password;

            return account;
        }
    }
}