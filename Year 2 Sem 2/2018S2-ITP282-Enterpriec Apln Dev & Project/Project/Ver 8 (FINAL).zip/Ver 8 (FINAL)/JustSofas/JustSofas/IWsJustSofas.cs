﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace JustSofas
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IWsJustSofas" in both code and config file together.
    [ServiceContract]
    public interface IWsJustSofas
    {
        //payment 
        [OperationContract]
        DataSet getAllPayment(string sqlCommand);

        [OperationContract]
        DataSet getPaymentAll(int Id);

        [OperationContract]
        DataSet getpaymentID(int Id);

        [OperationContract]
        DataSet getsupplierName(int Id);

        [OperationContract]
        DataSet getamountPayable(int Id);

        [OperationContract]
        DataSet getbankAccNum(int Id);

        [OperationContract]
        DataSet getbankAccType(int Id);

        [OperationContract]
        DataSet getinvoiceId(int Id);

        [OperationContract]
        DataSet getpaymentDate(int Id);

        [OperationContract]
        DataSet GetPurchaseOrder(string sqlCommand);

        [OperationContract]
        DataSet GetPurchaseOrderDetails(int POId);

        [OperationContract]
        string getPOrderID(int PurchaseID);

        [OperationContract]
        string getSupNmame(int PurchaseID);


        [OperationContract]
        string getSupEmail(int PurchaseID);


        [OperationContract]
        string getSupAddress(int PurchaseID);



        [OperationContract]
        string getSupContact(int PurchaseID);

        ////////company

        [OperationContract]
        string getCoyName(int PurchaseID);


        [OperationContract]

        string getCoyEmail(int PurchaseID);



        [OperationContract]
        string getCoyAddress(int PurchaseID);

        [OperationContract]
        string getCoyContact(int PurchaseID);

        //purchase

        [OperationContract]
        string getDate(int PurchaseID);


        [OperationContract]
        string getStatus(int PurchaseID);


        [OperationContract]
        string getQty(int PurchaseID);


        [OperationContract]
        string getProductId(int PurchaseID);

        [OperationContract]
        string getProductName(int PurchaseID);

        [OperationContract]
        string getProductunitPrice(int PurchaseID);

        [OperationContract]
        string getProductDesc(int PurchaseID);

        [OperationContract]
        string getProductTotal(int PurchaseID);

    }
}
