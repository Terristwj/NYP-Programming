﻿using JustSofas.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JustSofas
{
    public partial class AccountStaff : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_StaffAccount account = new BLL_StaffAccount();
            string staffName = account.getName(Request.QueryString["staffID"]);
            string staffPosition = account.getPosition(Request.QueryString["staffID"]);
            
            tb_name.Text = staffName;
            tb_ID.Text = (Convert.ToInt32(Request.QueryString["staffID"]).ToString("D5"));
            tb_Position.Text = staffPosition;
        }

        protected void btn_SignOut_Click(object sender, EventArgs e)
        {
            string queryString = "?login=false";
            Response.Redirect("~/Login.aspx" + queryString);
        }

        protected void btn_ManageCatalogue_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/EditStoreHome.aspx" + queryString);
        }
        protected void btn_ViewUsers_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewUsers.aspx" + queryString);
        }

        protected void btn_ViewStaff_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewStaff.aspx" + queryString);
        }

        protected void btn_ViewDocuments_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewDocuments.aspx" + queryString);
        }

        protected void btn_Qna_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/A_Rooms.aspx" + queryString);
        }
    }
}