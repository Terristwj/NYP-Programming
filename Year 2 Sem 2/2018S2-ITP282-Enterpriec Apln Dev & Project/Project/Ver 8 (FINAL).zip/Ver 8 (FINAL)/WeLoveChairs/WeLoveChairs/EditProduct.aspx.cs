﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class EditProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Product product = new BLL_Product();
            string productID = Request.QueryString["product"];

            string category = product.getCategory(productID);
            string imageUrl = product.getImageUrl(productID);
            string name = product.getName(productID);
            double price = product.getUnitPrice(productID);
            string desc = product.getDescription(productID);
            string creatorName = product.getCreatorName(productID);
            string dateCreated = product.getDateCreated(productID);
            
            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            if (position.Equals("Junior"))
            {
                btn_Update.Enabled = false;
                btn_Update.Style.Add("cursor", "not-allowed");
                btn_Update.ToolTip = "Junior No Access";
            }

            if (!IsPostBack)   //MUST USE !IsPostBack IF NOT ERROR IN UPDATE
            {
                tb_ProductID.Text = Request.QueryString["product"];
                if (category.Equals("Ottoman"))
                {
                    ddl_Category.SelectedIndex = 0;
                }
                if (category.Equals("Single"))
                {
                    ddl_Category.SelectedIndex = 1;
                }
                if (category.Equals("Long"))
                {
                    ddl_Category.SelectedIndex = 2;
                }
                if (category.Equals("Cushion"))
                {
                    ddl_Category.SelectedIndex = 3;
                }

                tb_Name.Text = name;

                img_Product.ImageUrl = "~/Images/Products/" + productID + "/" + imageUrl;
                
                tb_Price.Text = price.ToString("0.00");

                tb_Desc.Text = desc;

                tb_StaffName.Text = creatorName;
                tb_DateCreated.Text = dateCreated;
            }
        }

        protected void btn_Update_Click(object sender, EventArgs e)
        {
            BLL_Product product = new BLL_Product();
            string productID = Request.QueryString["product"];

            Boolean nameTaken = product.checkName2(tb_Name.Text, productID);
            
            if (nameTaken == true)
            {
                Response.Write("<script>alert('Product Name is taken')</script>");
            }
            else
            {
                string Category = product.getCategory(productID);
                string Name = product.getName(productID);
                double Unit_Price = product.getUnitPrice(productID);
                string Description = product.getDescription(productID);
                string currentProductImage = product.getImageUrl(productID);

                string price = Unit_Price.ToString("0.00");

                if (fu_ProductImg.HasFile
                    && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".jpg"
                    && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".png"
                    && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".gif"
                    && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".jpeg")
                {
                    Response.Write("<script>alert('This is not an image file')</script>");
                }
                else   //After checking the images validation, proceed to each section.
                {
                    if (!ddl_Category.SelectedValue.Equals(Category))
                    {
                        //Save category into DB
                        product.updateCategory(ddl_Category.SelectedValue, productID);
                    }

                    if (!tb_Name.Text.Equals(Name))
                    {
                        //Save name into DB
                        product.updateName(tb_Name.Text, productID);
                    }

                    if (!tb_Price.Text.Equals(price))
                    {
                        //Save unit price code into DB
                        product.updateUnitPrice(tb_Price.Text, productID);
                    }

                    if (!tb_Desc.Text.Equals(Description))
                    {
                        //Save description into DB
                        product.updateDescription(tb_Desc.Text, productID);
                    }

                    if (fu_ProductImg.HasFile)
                    {
                        //Delete old image
                        string productImage = "Images\\Products\\" + Request.QueryString["product"] + "\\" + currentProductImage;
                        string fullPath = Server.MapPath("") + "\\" + productImage;
                        File.Delete(fullPath);

                        //Add image into DB
                        product.updateImageUrl(fu_ProductImg.FileName, productID);

                        //Change image
                        productImage = "Images\\Products\\" + Request.QueryString["product"] + "\\" + fu_ProductImg.FileName;
                        fullPath = Server.MapPath("") + "\\" + productImage;
                        fu_ProductImg.SaveAs(fullPath);
                    }

                    if (!fu_ProductImg.HasFile && tb_Name.Text.Equals(Name)
                        && tb_Price.Text.Equals(price)
                        && tb_Desc.Text.Equals(Description) && ddl_Category.SelectedValue.Equals(Category))
                    {
                        Response.Write("<script>alert('No changes made')</script>");
                    }

                    else //Changes made
                    {
                        //Refresh webpage
                        Page.Response.Redirect(Page.Request.Url.ToString(), true);
                    }
                }
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/EditStore.aspx" + queryString);
        }
    }
}