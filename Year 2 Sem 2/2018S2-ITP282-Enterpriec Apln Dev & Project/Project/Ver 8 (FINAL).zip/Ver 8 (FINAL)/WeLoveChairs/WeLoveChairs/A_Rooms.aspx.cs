﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class A_Rooms : System.Web.UI.Page
    {
        static string command = "";
        static string rewriteCommand = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            command = "SELECT * FROM chatRoom";
            command += " WHERE chatRoomID IS NOT NULL";

            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }

            if (Request.QueryString["failed"] != null)
            {
                Response.Write("<script>alert('Room " + Session["roomID"] + " Is Full.')</script>");
                Session.Remove("roomID");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            A_BLL_QnA QnA = new A_BLL_QnA();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = QnA.getAllProduct(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
            }
            else if (condition.Equals("None"))
            {
                rewriteCommand = command;

                ds = QnA.getAllProduct(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
                tb_Search.Text = "";
            }
            else if (condition.Equals("ORDERBY"))
            {
                string finalCommand;
                finalCommand = rewriteCommand + " " + condition_requirement;

                ds = QnA.getAllProduct(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();
            }
        }

        protected void btn_SearchTitle_Click(object sender, EventArgs e)
        {
            string value = tb_SearchTitle.Text;
            tb_Search.Text = "";
            tb_RoomSize.Text = "";
            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND roomTitle LIKE '%" + value + "%'";
            }
            ViewGridView("Search", condition_Requirement);
        }


        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            tb_SearchTitle.Text = "";
            tb_RoomSize.Text = "";
            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND chatRoomID = '" + value + "'";
            }
            ViewGridView("Search", condition_Requirement);
        }

        protected void btn_SearchSize_Click(object sender, EventArgs e)
        {
            string value = tb_RoomSize.Text;
            tb_SearchTitle.Text = "";
            tb_Search.Text = "";
            string condition_Requirement = "";

            if (value.Equals(""))
            {

            }
            else
            {
                condition_Requirement = "AND roomSize = '" + value + "'";
            }
            ViewGridView("Search", condition_Requirement);
        }

        protected void gv_Products_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            A_BLL_QnA QnA = new A_BLL_QnA();
            string roomID = e.CommandArgument.ToString();

            string staffID = Request.QueryString["staffID"];
            BLL_StaffAccount staff = new BLL_StaffAccount();
            string name = staff.getName(staffID);

            int currentSize = Convert.ToInt32(QnA.getCurrentSize(roomID));
            int roomSize = Convert.ToInt32(QnA.getRoomSize(roomID));


            currentSize += 1;

            if (currentSize > roomSize)
            {

                Session.Add("roomID", e.CommandArgument);

                //Refresh webpage
                Page.Response.Redirect(Page.Request.Url.ToString() + "&failed=1", true);
            }
            else
            {
                //Save into DB
                QnA.updateChatRoom(currentSize.ToString(), roomID);

                //insert chat room users
                QnA.insertQnAUser(roomID, "WeLoveChairs", name);

                string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&roomID=" + e.CommandArgument;
                Response.Redirect("~/A_QnA_RoomChatRoom.aspx" + queryString);
            }
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/StaffPage.aspx" + queryString);
        }

        protected void btn_RefreshPage_Click(object sender, EventArgs e)
        {
            ViewGridView("None", "None");
        }
    }
}