﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class EditStore : System.Web.UI.Page
    {
        static string command = "SELECT * FROM Products";
        static string rewriteCommand = "SELECT * FROM Products";
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            if (position.Equals("Junior"))
            {
                btn_Add.Enabled = false;
                btn_Add.Style.Add("cursor", "not-allowed");
                btn_Add.ToolTip = "Junior No Access";
            }

            if (Request.QueryString["delete"] != null)
            {
                Response.Write("<script>alert('Failed.\\nJunior Account No Access.')</script>");
            }

            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_Product product = new BLL_Product();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = product.getAllProduct(rewriteCommand);
                gv_Products.DataSource = ds;
                gv_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = product.getAllProduct(command);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = product.getAllProduct(rewriteCommand);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = product.getAllProduct(finalCommand);
                    gv_Products.DataSource = ds;
                    gv_Products.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE Name LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }

        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_SortOnly.SelectedValue;
            if (value.Equals("None"))
            {
                ViewGridView("None", "None");
            }
            else if (value.Equals("Category - Ottoman"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Ottoman'");
            }
            else if (value.Equals("Category - Single"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Single'");
            }
            else if (value.Equals("Category - Long"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Long'");
            }
            else if (value.Equals("Category - Cushion"))
            {
                ViewGridView("WHERE", "WHERE Category = 'Cushion'");
            }
        }

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            if (value.Equals("Product ID"))
            {
                ViewGridView("ORDERBY", "ORDER BY Product_ID ASC");
            }
            else if (value.Equals("Category"))
            {
                ViewGridView("ORDERBY", "ORDER BY Category ASC");
            }
            else if (value.Equals("Name"))
            {
                ViewGridView("ORDERBY", "ORDER BY Name ASC");
            }
            else if (value.Equals("High Price"))
            {
                ViewGridView("ORDERBY", "ORDER BY Unit_Price DESC");
            }
            else if (value.Equals("Low Price"))
            {
                ViewGridView("ORDERBY", "ORDER BY Unit_Price ASC");
            }
        }

        protected void gv_Products_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            if (position.Equals("Junior"))
            {
                if (e.CommandName == "Delete")
                {
                    Page.Response.Redirect(Page.Request.Url.ToString() + "&delete=fail", true);
                }
            }
            else
            {
                if (e.CommandName == "Delete")
                {

                    BLL_Product product = new BLL_Product();
                    string currentImageUrl = product.getImageUrl(e.CommandArgument.ToString());


                    //Delete image of item
                    string productImage = "Images\\Products\\" + e.CommandArgument + "\\" + currentImageUrl;
                    string fullPath = Server.MapPath("") + "\\" + productImage;
                    File.Delete(fullPath);

                    //Delete folder of item
                    Directory.Delete(Server.MapPath("") + "\\Images\\Products\\" + e.CommandArgument);

                    //Delete from database
                    product.deleteProduct(e.CommandArgument.ToString());

                    //Refresh webpage
                    Page.Response.Redirect(Page.Request.Url.ToString(), true);
                }
            }
        }

        protected void btn_Add_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/AddProduct.aspx" + queryString);
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/StaffPage.aspx" + queryString);
        }
    }
}