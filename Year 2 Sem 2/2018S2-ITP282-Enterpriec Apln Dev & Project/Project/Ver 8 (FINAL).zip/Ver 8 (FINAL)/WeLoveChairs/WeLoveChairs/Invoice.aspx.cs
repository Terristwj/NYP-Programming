﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;


namespace WeLoveChairs
{
    public partial class Invoice : System.Web.UI.Page
    {
        static string command = "SELECT * FROM Invoice";
        static string rewriteCommand = "SELECT * FROM Invoice";
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_CustomerOrder custorderList = new BLL_CustomerOrder();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = custorderList.getAllCustomerOrder(rewriteCommand);
                gv_Invoice.DataSource = ds;
                gv_Invoice.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = custorderList.getAllCustomerOrder(command);
                    gv_Invoice.DataSource = ds;
                    gv_Invoice.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = custorderList.getAllCustomerOrder(rewriteCommand);
                    gv_Invoice.DataSource = ds;
                    gv_Invoice.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = custorderList.getAllCustomerOrder(finalCommand);
                    gv_Invoice.DataSource = ds;
                    gv_Invoice.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE Name LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }


        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_SortOnly.SelectedValue;
            if (value.Equals("None"))
            {
                ViewGridView("None", "None");
            }
            else if (value.Equals("Status - sent"))
            {
                ViewGridView("WHERE", "WHERE InvoiceStatus = 'paid'");

            }
            else if (value.Equals("Status - pending"))
            {
                ViewGridView("WHERE", "WHERE InvoiceStatus = 'pending'");

            }

        }

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            //if (value.Equals("Time"))
            //{
            //    ViewGridView("ORDERBY", "ORDER BY ITime");
            //}
            //else if (value.Equals("Date"))
            //{
                ViewGridView("ORDERBY", "ORDER BY Date DESC");
           // }
        }


        //protected void gv_CustOrders_RowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    BLL_StaffAccount account = new BLL_StaffAccount();
        //    string position = account.getPosition(Request.QueryString["staffID"]);

        //    if (e.CommandName == "Select")
        //    {
        //        string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&Id=" + e.CommandArgument;
        //        Response.Redirect("~/InvoiceDetails.aspx" + queryString);
        //    }
        //}


        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewDocuments.aspx" + queryString);
        }

      
        protected void gv_Invoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            GridViewRow row = gv_Invoice.SelectedRow;
            int invoiceId = int.Parse(row.Cells[0].Text);

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&Id=" + invoiceId;
            Response.Redirect("~/InvoiceDetail.aspx" + queryString);
        }
    }
}