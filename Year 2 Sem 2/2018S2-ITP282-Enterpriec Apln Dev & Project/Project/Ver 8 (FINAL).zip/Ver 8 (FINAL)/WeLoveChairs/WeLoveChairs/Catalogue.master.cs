﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WeLoveChairs
{
    public partial class Catalogue1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Ottoman_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["login"] == "false")
            {
                queryString = "?login=false";
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            }

            Response.Redirect("~/CatalogueOttoman.aspx" + queryString);
        }

        protected void btn_Single_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["login"] == "false")
            {
                queryString = "?login=false";
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            }

            Response.Redirect("~/CatalogueSingle.aspx" + queryString);
        }

        protected void btn_Long_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["login"] == "false")
            {
                queryString = "?login=false";
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            }

            Response.Redirect("~/CatalogueLong.aspx" + queryString);
        }

        protected void btn_Cusion_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["login"] == "false")
            {
                queryString = "?login=false";
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            }

            Response.Redirect("~/CatalogueCusion.aspx" + queryString);
        }
    }
}