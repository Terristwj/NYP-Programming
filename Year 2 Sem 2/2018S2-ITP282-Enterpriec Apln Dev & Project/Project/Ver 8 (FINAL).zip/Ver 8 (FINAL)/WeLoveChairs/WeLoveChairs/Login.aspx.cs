﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["login"] == "true")
            {
                if (Request.QueryString["staffID"] != null)
                {
                    string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                    Response.Redirect("~/StaffPage.aspx" + queryString);
                }
            }

            if (IsPostBack) //The web page is loaded by itself
            {

            }
        }

        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            BLL_StaffAccount accounts = new BLL_StaffAccount();
            Boolean accountLogin = accounts.loginStatus(TxtUsername.Text, TxtPassword.Text);

            if (accountLogin == true)
            {
                string staffID = accounts.getStaffID(TxtUsername.Text);
                string queryString = "?login=true" + "&staffID=" + staffID;
                Response.Redirect("~/StaffPage.aspx" + queryString);
            }
            else
            {
                Response.Write("<script>alert('Incorrect Login')</script>");
            }
        }
    }
}