﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class CustomerOrderDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string orderID = Request.QueryString["staffID"];
            int custOrderID = int.Parse(Request.QueryString["OrderNO"]);
            BLL_CustomerOrder custorder = new BLL_CustomerOrder();

            string orderid = custorder.getCOrderID(custOrderID);
            string supname = custorder.getSupName(custOrderID);
            string supemail = custorder.getSupEmail(custOrderID);
            string supaddress = custorder.getSupAddress(custOrderID);
            string supcontact = custorder.getSupContact(custOrderID);

            string coyname = custorder.getCoyName(custOrderID);
            string coyemail = custorder.getCoyEmail(custOrderID);
            string coyaddress = custorder.getCoyAddress(custOrderID);
            string coycontact = custorder.getCoyContact(custOrderID);

            string date = custorder.getDate(custOrderID);
            string status = custorder.getStatus(custOrderID);
            string qty = custorder.getQty(custOrderID);
            string prodId = custorder.getProductId(custOrderID);
            string prodName = custorder.getProductName(custOrderID);
            string desc = custorder.getProductDesc(custOrderID);
            string unitp = custorder.getProductunitPrice(custOrderID);
            string amt = custorder.getProductTotal(custOrderID);

            OrderNo.Text = orderid;
            SupplierName.Text = supname;
            SupplierEmail.Text = supemail;
            SupplierAdd.Text = supaddress;
            SupplierContact.Text = supcontact.ToString();

            CompanyName.Text = coyname;
            CompanyEmail.Text = coyemail;
            CompanyAdd.Text = coyaddress;
            CompanyConatact.Text = coycontact.ToString();

            //dont have order Id 

            Date.Text = date;
            PID.Text = prodId;
            PQty.Text = qty.ToString();
            PUnitPrice.Text = unitp;
            PName.Text = prodName;
            PDesc.Text = desc;
            PTotalPrice.Text = amt.ToString();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/CustomerOrder.aspx" + queryString);
        }

        protected void btnConvert_Click(object sender, EventArgs e)
        {
            BLL_DeliveryOrder convertCO = new BLL_DeliveryOrder();
            convertCO.insertCOtoDO(SupplierName.Text, SupplierEmail.Text, SupplierAdd.Text, Convert.ToInt32(SupplierContact.Text), Date.Text, CompanyName.Text, CompanyEmail.Text, CompanyAdd.Text, Convert.ToInt32(CompanyConatact.Text), PID.Text, PName.Text, PDesc.Text, PUnitPrice.Text, Convert.ToInt32(PQty.Text), Convert.ToDecimal(PTotalPrice.Text));

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/DeliveryOrder.aspx" + queryString);
        }
    }
}