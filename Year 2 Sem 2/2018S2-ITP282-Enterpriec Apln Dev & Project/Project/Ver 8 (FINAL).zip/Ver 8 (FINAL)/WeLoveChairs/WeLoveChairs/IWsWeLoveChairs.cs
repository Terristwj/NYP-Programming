﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WeLoveChairs
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IWsWeLoveChairs" in both code and config file together.
    [ServiceContract]
    public interface IWsWeLoveChairs
    {
        //update status 
        [OperationContract]
        DataSet UpdateCustomerOrderStatus(int OrderNO);

        [OperationContract]
        DataSet UpdateDeliveryStatus(int DeliveryId);

        [OperationContract]
        DataSet GetSupplierCatalogue();

        [OperationContract]
        DataSet GetSupplierCatalogue2(string sqlCommand);

        [OperationContract]
        DataSet getAllCustomerOrder(string sqlCommand);

        [OperationContract]
        string getCOrderID(int CustomerOrderID);

        [OperationContract]
        string getSupName(int CustomerOrderID);

        [OperationContract]
        string getSupEmail(int CustomerOrderID);

        [OperationContract]
        string getSupAddress(int CustomerOrderID);

        [OperationContract]
        string getSupContact(int CustomerOrderID);

        [OperationContract]
        string getCoyName(int CustomerOrderID);

        [OperationContract]
        string getCoyEmail(int CustomerOrderID);

        [OperationContract]
        string getCoyAddress(int CustomerOrderID);

        [OperationContract]
        string getCoyContact(int CustomerOrderID);

        [OperationContract]
        string getDate(int CustomerOrderID);


        [OperationContract]
        string getStatus(int CustomerOrderID);

        [OperationContract]
        string getQty(int CustomerOrderID);

        [OperationContract]
        string getProductId(int CustomerOrderID);


        [OperationContract]
        string getProductName(int CustomerOrderID);

        [OperationContract]
        string getProductDesc(int CustomerOrderID);

        [OperationContract]
        string getProductunitPrice(int CustomerOrderID);


        [OperationContract]
        string getProductTotal(int CustomerOrderID);

        [OperationContract]
        DataSet getAllDeliveryOrder(string sqlCommand);

        [OperationContract]
        string getDeliveryOrderID(int Id);
        [OperationContract]
        string getDeliveryOrderDate(int Id);
        [OperationContract]
        string getDeliveryOrderTime(int Id);
        [OperationContract]
        string getDeliveryOrderStatus(int Id);
        [OperationContract]
        string getDeliveryOrderCoy(int Id);
        [OperationContract]
        string getDispatchDate(int Id);

        [OperationContract]
        string getProductIdDO(int Id);

        [OperationContract]
        string getQuantityDO(int Id);

        [OperationContract]
        string getUnitPriceDO(int Id);

        [OperationContract]
        string getProductNameDO(int Id);

        [OperationContract]
        string getCompanyNameDO(int Id);

        [OperationContract]
        string getCompanyEmailDO(int Id);

        [OperationContract]
        string getCompanyContactDO(int Id);

        [OperationContract]
        string getCompanyAddressDO(int Id);

        [OperationContract]
        string getSupplierNameDO(int Id);

        [OperationContract]
        string getInvoiceStatusDO(int Id);

        [OperationContract]
        string getTotalPriceDO(int Id);

        [OperationContract]
        string getSupplierAddressDO(int Id);
        [OperationContract]
        string getSupplierEmailDO(int Id);

        [OperationContract]
        string getSupplierContactDO(int Id);

        [OperationContract]
        string getInvoiceDescDO(int Id);


        [OperationContract]
        DataSet getAllInvoice(string sqlCommand);

        //[OperationContract]
        //string getInvoiceAll(int invoiceID);

        [OperationContract]
        string getInvoiceID(int invoiceID);

        [OperationContract]
        string getSupplierName(int invoiceID);

        [OperationContract]
        string getInvoiceStatus(int invoiceID);

        [OperationContract]
        string getInvoiceDate(int invoiceID);

        [OperationContract]
        string getSupplierAddress(int invoiceID);

        [OperationContract]
        string getSupplierEmail(int invoiceID);

        [OperationContract]
        string getSupplierContact(int invoiceID);

        [OperationContract]
        string getCompanyName(int invoiceID);

        [OperationContract]
        string getCompanyEmail(int invoiceID);

        [OperationContract]
        string getCompanyContact(int invoiceID);

        [OperationContract]
        string getCompanyAddress(int invoiceID);

        [OperationContract]
        string getProductIdInvoice(int invoiceID);

        [OperationContract]
        string getProductNameInvoice(int invoiceID);

        [OperationContract]
        string getQuantity(int invoiceID);

        [OperationContract]
        string getUnitPriceInvoice(int invoiceID);

        [OperationContract]
        string getTotalPrice(int invoiceID);
        [OperationContract]
        string getInvoiceDesc(int invoiceID);

        [OperationContract]
        void insertPayment(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, string Date);

        [OperationContract]
        void UpdateInvoiceStatus(string invoiceStatus, int invoiceId);

        [OperationContract]
        DataSet getImageUrl(string productID);

        [OperationContract]
        DataSet getName(string productID);

        [OperationContract]
        DataSet getUnitPrice(string productID);

        [OperationContract]
        DataSet getDescription(string productID);

        [OperationContract]
        DataSet getCategory(string productID);

        [OperationContract]
        DataSet getDateCreated(string productID);

        //CHAT ROOM
        [OperationContract]
        void insertQnARoom(string roomSize, string roomTitle);

        [OperationContract]
        DataSet getChatRooms(string sqlCommand);

        [OperationContract]
        string getCurrentSize(string id);

        [OperationContract]
        string getRoomSize(string id);

        [OperationContract]
        void updateChatRoom(string currentSize, string chatRoomID);

        [OperationContract]
        void insertQnAUser(string chatRoomID, string userType, string name);

        [OperationContract]
        void insertQnAMessage(string chatRoomID, string staffName, string message);

        [OperationContract]
        void deleteQnAUser(string userType, string name);

        [OperationContract]
        void deleteQnARoom(string chatRoomID);

    }
}
