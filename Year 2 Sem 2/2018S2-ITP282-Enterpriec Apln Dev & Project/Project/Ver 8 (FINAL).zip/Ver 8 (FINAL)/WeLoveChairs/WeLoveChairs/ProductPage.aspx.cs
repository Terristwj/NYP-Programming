﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class ProductPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Product product = new BLL_Product();

            string productID = Request.QueryString["product"];
            string imageUrl = product.getImageUrl(productID);
            string name = product.getName(productID);
            double price = product.getUnitPrice(productID);
            string desc = product.getDescription(productID);

            if (!IsPostBack)
            {
                lb_Name.Text = name;
                img_Product.ImageUrl = "~/Images/Products/" + Request.QueryString["product"] + "/" + imageUrl;
                
                lb_Price.Text = "Price: $" + price.ToString("0.00"); ;

                tb_Desc.Text = "Description: " + desc;
            }

            Page.Title = name;
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "";
            if (Request.QueryString["login"] == "false")
            {
                queryString = "?login=false";
            }
            else if (Request.QueryString["staffID"] != null)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            }


            BLL_Product product = new BLL_Product();
            string productID = Request.QueryString["product"];
            string Category = product.getCategory(productID);

            string btn_BackUrl = "";

            if (Category.Equals("Ottoman"))
                btn_BackUrl = "~/CatalogueOttoman.aspx";
            else if (Category.Equals("Single"))
                btn_BackUrl = "~/CatalogueSingle.aspx";
            else if (Category.Equals("Long"))
                btn_BackUrl = "~/CatalogueLong.aspx";
            else if (Category.Equals("Cushion"))
                btn_BackUrl = "~/CatalogueCusion.aspx";

            Response.Redirect(btn_BackUrl + queryString);
        }
    }
}