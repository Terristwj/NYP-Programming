﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "WsWeLoveChairs" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select WsWeLoveChairs.svc or WsWeLoveChairs.svc.cs at the Solution Explorer and start debugging.
    public class WsWeLoveChairs : IWsWeLoveChairs
    {
        //update status 
        public void insertPayment(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, string Date)
        {
            BLL_Payment payment = new BLL_Payment();
            payment.insertPayment(supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date);
        }

        public void UpdateInvoiceStatus(string invoiceStatus, int invoiceId)
        {
            BLL_Invoice invoice = new BLL_Invoice();
            invoice.UpdateStatus(invoiceStatus, invoiceId);
        }
        public DataSet UpdateDeliveryStatus(int DeliveryId)
        {
            BLL_DeliveryOrder status = new BLL_DeliveryOrder();
            return status.UpdateDeliveryStatus(DeliveryId);
        }

        public DataSet UpdateCustomerOrderStatus(int OrderNO)
        {
            BLL_CustomerOrder status = new BLL_CustomerOrder();
            return status.UpdateCustomerOrderStatus(OrderNO);
        }
        public DataSet GetSupplierCatalogue()
        {
            BLL_WsProduct productList = new BLL_WsProduct();
            return productList.GetProducts();
        }

        public DataSet GetSupplierCatalogue2(string sqlCommand)
        {
            BLL_WsProduct productList = new BLL_WsProduct();
            return productList.getAllProduct(sqlCommand);
        }

        public DataSet getAllCustomerOrder(string sqlCommand)
        {
            BLL_CustomerOrder customerList = new BLL_CustomerOrder();
            return customerList.getAllCustomerOrder(sqlCommand);
        }

        public DataSet getAllDeliveryOrder(string sqlCommand)
        {
            BLL_DeliveryOrder doList = new BLL_DeliveryOrder();
            return doList.getAllDeliveryOrder(sqlCommand);
        }

        public DataSet getAllInvoice(string sqlCommand)
        {
            BLL_Invoice doList = new BLL_Invoice();
            return doList.getAllInvoice(sqlCommand);
        }


        public string getCOrderID(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getCOrderID(CustomerOrderID);

        }


        public string getSupName(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getSupName(CustomerOrderID);

        }

        public string getSupEmail(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getSupEmail(CustomerOrderID);

        }

        public string getSupAddress(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getSupAddress(CustomerOrderID);

        }


        public string getSupContact(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getSupContact(CustomerOrderID);

        }

        public string getCoyName(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getCoyName(CustomerOrderID);

        }


        public string getCoyEmail(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getCoyEmail(CustomerOrderID);

        }

        public string getCoyAddress(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getCoyAddress(CustomerOrderID);

        }

        public string getCoyContact(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getCoyContact(CustomerOrderID);

        }

        public string getDate(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getDate(CustomerOrderID);

        }

        public string getStatus(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getStatus(CustomerOrderID);

        }

        public string getQty(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getQty(CustomerOrderID);

        }

        public string getProductId(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getProductId(CustomerOrderID);

        }

        public string getProductName(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getProductName(CustomerOrderID);

        }

        public string getProductDesc(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getProductDesc(CustomerOrderID);

        }

        public string getProductunitPrice(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getProductunitPrice(CustomerOrderID);

        }

        public string getProductTotal(int CustomerOrderID)
        {

            BLL_CustomerOrder product = new BLL_CustomerOrder();
            return product.getProductTotal(CustomerOrderID);

        }
        public DataSet getImageUrl(string productID)
        {
            BLL_WsProduct product = new BLL_WsProduct();
            return product.getImageUrl(productID);
        }

        public DataSet getName(string productID)
        {
            BLL_WsProduct product = new BLL_WsProduct();
            return product.getName(productID);
        }

        public DataSet getUnitPrice(string productID)
        {
            BLL_WsProduct product = new BLL_WsProduct();
            return product.getUnitPrice(productID);
        }

        public DataSet getDescription(string productID)
        {
            BLL_WsProduct product = new BLL_WsProduct();
            return product.getDescription(productID);
        }

        public DataSet getCategory(string productID)
        {
            BLL_WsProduct product = new BLL_WsProduct();
            return product.getCategory(productID);
        }

        public DataSet getDateCreated(string productID)
        {
            BLL_WsProduct product = new BLL_WsProduct();
            return product.getDateCreated(productID);
        }

        //invoice order


        public string getInvoiceID(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getInvoiceID(invoiceID);
        }


        public string getSupplierName(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getSupplierName(invoiceID);
        }

        public string getInvoiceStatus(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getInvoiceStatus(invoiceID);
        }

        public string getInvoiceDate(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getInvoiceDate(invoiceID);
        }

        public string getSupplierAddress(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getSupplierAddress(invoiceID);
        }

        public string getSupplierEmail(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getSupplierEmail(invoiceID);
        }

        public string getSupplierContact(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getSupplierContact(invoiceID);
        }
        public string getCompanyName(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getCompanyName(invoiceID);
        }
        public string getCompanyEmail(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getCompanyEmail(invoiceID);
        }

        public string getCompanyContact(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getCompanyContact(invoiceID);
        }

        public string getCompanyAddress(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getCompanyAddress(invoiceID);
        }
        public string getProductIdInvoice(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getProductId(invoiceID);
        }

        public string getProductNameInvoice(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getProductName(invoiceID);
        }

        public string getQuantity(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getQuantity(invoiceID);
        }
        public string getUnitPriceInvoice(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getUnitPriceInvoice(invoiceID);
        }
        public string getTotalPrice(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getTotalPrice(invoiceID);
        }
        public string getInvoiceDesc(int invoiceID)
        {
            BLL_Invoice invoiceDetail = new BLL_Invoice();
            return invoiceDetail.getInvoiceDesc(invoiceID);
        }

        //delivery
        public string getDeliveryOrderID(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getDeliveryOrderID(Id);
        }

        public string getDeliveryOrderDate(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getDeliveryOrderDate(Id);
        }

        public string getDeliveryOrderTime(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getDeliveryOrderTime(Id);
        }

        public string getDeliveryOrderStatus(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getDeliveryOrderStatus(Id);
        }

        public string getDeliveryOrderCoy(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getDeliveryOrderCoy(Id);
        }

        public string getDispatchDate(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getDispatchDate(Id);
        }
        //string getProductIdDO(int Id);
        public string getProductIdDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getProductIdDO(Id);
        }
        //[OperationContract]
        //string getQuantityDO(int Id);
        public string getQuantityDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getQuantityDO(Id);
        }
        //[OperationContract]
        //string getUnitPriceDO(int Id);
        public string getUnitPriceDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getUnitPriceDO(Id);
        }
        //[OperationContract]
        //string getProductNameDO(int Id);
        public string getProductNameDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getProductNameDO(Id);
        }
        //[OperationContract]
        //string getCompanyNameDO(int Id);
        public string getCompanyNameDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getCompanyNameDO(Id);
        }
        //[OperationContract]
        //string getCompanyEmailDO(int Id);
        public string getCompanyEmailDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getCompanyEmailDO(Id);
        }
        //[OperationContract]
        //string getCompanyContactDO(int Id);
        public string getCompanyContactDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getCompanyContactDO(Id);
        }
        //[OperationContract]
        //string getCompanyAddressDO(int Id);
        public string getCompanyAddressDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getCompanyAddressDO(Id);
        }
        //[OperationContract]
        //string getSupplierNameDO(int Id);
        public string getSupplierNameDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getSupplierNameDO(Id);
        }
        //[OperationContract]
        //string getInvoiceStatusDO(int Id);
        public string getInvoiceStatusDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getInvoiceStatusDO(Id);
        }
        //[OperationContract]
        //string getTotalPriceDO(int Id);
        public string getTotalPriceDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getTotalPriceDO(Id);
        }
        //[OperationContract]
        //string getSupplierAddressDO(int Id);
        public string getSupplierAddressDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getSupplierAddressDO(Id);
        }
        //[OperationContract]
        //string getSupplierEmailDO(int Id);
        public string getSupplierEmailDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getSupplierEmailDO(Id);
        }
        //[OperationContract]
        //string getSupplierContactDO(int Id);
        public string getSupplierContactDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getSupplierContactDO(Id);
        }
        //[OperationContract]
        //string getInvoiceDescDO(int Id);
        public string getInvoiceDescDO(int Id)
        {
            BLL_DeliveryOrder DeliveryOrderDetail = new BLL_DeliveryOrder();
            return DeliveryOrderDetail.getInvoiceDescDO(Id);
        }

        // CHAT ROOM CODES
        public DataSet getChatRooms(string sqlCommand)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            return QnA.getAllProduct(sqlCommand);
        }

        public string getCurrentSize(string id)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            return QnA.getCurrentSize(id);
        }

        public string getRoomSize(string id)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            return QnA.getRoomSize(id);
        }

        public void updateChatRoom(string currentSize, string chatRoomID)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            QnA.updateChatRoom(currentSize, chatRoomID);
        }

        public void insertQnARoom(string roomSize, string roomTitle)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            QnA.insertQnARoom(roomSize, roomTitle);
        }

        public void insertQnAUser(string chatRoomID, string userType, string name)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            QnA.insertQnAUser(chatRoomID, userType, name);
        }

        public void insertQnAMessage(string chatRoomID, string staffName, string message)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            QnA.insertQnAMessage(chatRoomID, staffName, message);
        }

        public void deleteQnARoom(string chatRoomID)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            QnA.deleteQnARoom(chatRoomID);
        }

        public void deleteQnAUser(string userType, string name)
        {
            A_BLL_WsQnA QnA = new A_BLL_WsQnA();
            QnA.deleteQnAUser(userType, name);
        }
    }
}
