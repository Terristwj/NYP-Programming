﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class A_QnA_RoomChatRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadChatbox();
            LoadUsers();
        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            LoadUsers();
        }
        public void LoadUsers()
        {
            string roomID = Request.QueryString["roomID"];
            string command = "SELECT * FROM chatRoom cr";
            command += " INNER JOIN chatRoomUsers cru ON cru.chatRoomID = cr.chatRoomID";
            command += " WHERE cr.chatRoomID = '" + Request.QueryString["roomID"] + "'";

            A_BLL_QnA Qna = new A_BLL_QnA();
            DataSet ds = Qna.getAllProduct(command);

            dl_RoomUsers.DataSource = ds;
            dl_RoomUsers.DataBind();
        }

        protected void Timer2_Tick(object sender, EventArgs e)
        {
            LoadChatbox();
        }
        public void LoadChatbox()
        {
            string command = "SELECT * FROM chatRoom cr";
            command += " INNER JOIN chatRoomMessages crm ON crm.chatRoomID = cr.chatRoomID";
            command += " WHERE cr.chatRoomID = '" + Request.QueryString["roomID"] + "'";

            A_BLL_QnA Qna = new A_BLL_QnA();
            DataSet ds = Qna.getAllProduct(command);

            gv_Message.DataSource = ds;
            gv_Message.DataBind();
        }

        protected void btn_Send_Click(object sender, EventArgs e)
        {
            if (!tb_Message.Equals(""))
            {
                string chatRoomID = Request.QueryString["roomID"];
                string staffID = Request.QueryString["staffID"];
                BLL_StaffAccount staff = new BLL_StaffAccount();
                string staffName = staff.getName(staffID);
                string message = tb_Message.Text;

                A_BLL_QnA QnA = new A_BLL_QnA();

                //Insert Message
                QnA.insertQnAMessage(chatRoomID, staffName, message);

                tb_Message.Text = null;
            }
        }

        protected void btn_Exit_Click(object sender, EventArgs e)
        {
            A_BLL_QnA QnA = new A_BLL_QnA();
            string roomID = Request.QueryString["roomID"];
            string staffID = Request.QueryString["staffID"];
            BLL_StaffAccount staff = new BLL_StaffAccount();
            string name = staff.getName(staffID);
            string userType = "WeLoveChairs";

            int currentSize = Convert.ToInt32(QnA.getCurrentSize(roomID));
            int roomSize = Convert.ToInt32(QnA.getRoomSize(roomID));

            currentSize -= 1;

            //Save into DB
            QnA.updateChatRoom(currentSize.ToString(), roomID);

            //Delete Staff
            QnA.deleteQnAUser(userType, name);

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/A_Rooms.aspx" + queryString);
        }
    }
}