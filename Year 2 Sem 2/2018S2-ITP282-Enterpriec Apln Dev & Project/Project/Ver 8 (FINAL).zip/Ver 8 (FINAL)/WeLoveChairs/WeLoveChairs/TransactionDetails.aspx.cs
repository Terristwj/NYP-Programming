﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class TransactionDetails : System.Web.UI.Page
    {
        static string command = "SELECT * FROM Payment";
        static string rewriteCommand = "SELECT * FROM Payment";
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_Payment paymentList = new BLL_Payment();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = paymentList.getAllPayment(rewriteCommand);
                gv_payment.DataSource = ds;
                gv_payment.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = paymentList.getAllPayment(command);
                    gv_payment.DataSource = ds;
                    gv_payment.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = paymentList.getAllPayment(rewriteCommand);
                    gv_payment.DataSource = ds;
                    gv_payment.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = paymentList.getAllPayment(finalCommand);
                    gv_payment.DataSource = ds;
                    gv_payment.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE Payer LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }


        //protected void btn_SortOnly_Click(object sender, EventArgs e)
        //{
        //    string value = ddl_SortOnly.SelectedValue;
        //    if (value.Equals("None"))
        //    {
        //        ViewGridView("None", "None");
        //    }
        //    else if (value.Equals("Status - "))
        //    {
        //        ViewGridView("WHERE", "WHERE Status = 'delivered'");

        //    }
        //    else if (value.Equals("Status - pending"))
        //    {
        //        ViewGridView("WHERE", "WHERE Status = 'pending'");

        //    }

        //}

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            //if (value.Equals("Time"))
            //{
            //    ViewGridView("ORDERBY", "ORDER BY Time");
            //}
            //else if (value.Equals("Date"))
            //{
            ViewGridView("ORDERBY", "ORDER BY Date DESC");
            // }
        }
        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            ViewGridView("ORDERBY", "ORDER BY Payer DESC");
        }

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/AccountStaff.aspx" + queryString);
        }

    }
}