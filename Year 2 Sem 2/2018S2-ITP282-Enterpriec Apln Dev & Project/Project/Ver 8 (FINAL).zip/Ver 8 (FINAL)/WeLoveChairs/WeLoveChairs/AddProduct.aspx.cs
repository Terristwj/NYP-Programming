﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if (tb_Name.Text != "" && tb_Price.Text != "" && fu_ProductImg.HasFile)
            {
                BLL_Product product = new BLL_Product();
                Boolean nameTaken = product.checkName(tb_Name.Text);

                if (nameTaken == true)
                {
                    Response.Write("<script>alert('Product Name is taken')</script>");
                }
                else
                {
                    if (fu_ProductImg.HasFile
                        && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".jpg"
                        && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".png"
                        && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".gif"
                        && Path.GetExtension(fu_ProductImg.FileName).ToLower() != ".jpeg")
                    {
                        Response.Write("<script>alert('This is not an image file')</script>");
                    }
                    else   //After checking the images validation and stock, proceed to each section.
                    {
                        DateTime DateCreated = DateTime.Now;
                        string DateCreatedStr = DateCreated.ToString("dd MMMM yyyy");
                        
                        BLL_StaffAccount account = new BLL_StaffAccount();
                        string staffName = account.getName(Request.QueryString["staffID"]);

                        // INSERT PRODUCT
                        product.insertProduct(ddl_Category.SelectedValue, tb_Name.Text, tb_Desc.Text, tb_Price.Text, "", staffName, DateCreatedStr);
                        
                        string Product_ID = product.getProductID(tb_Name.Text);

                        //Creates folder for the product images
                        string productFolder = Product_ID;
                        string path = Server.MapPath("~/Images/Products/" + productFolder);
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }


                        if (fu_ProductImg.HasFile)
                        {
                            //Add image into DB
                            product.updateImageUrl(fu_ProductImg.FileName, Product_ID);

                            //Save actual image
                            string productImage = "Images\\Products\\" + productFolder + "\\" + fu_ProductImg.FileName;
                            string fullPath = Server.MapPath("") + "\\" + productImage;
                            fu_ProductImg.SaveAs(fullPath);
                        }

                        tb_Desc.Text = "";
                        tb_Name.Text = "";
                        tb_Price.Text = "";
                        ddl_Category.SelectedIndex = 0;
                    }
                }
            }
            else if (!fu_ProductImg.HasFile)
            {
                Response.Write("<script>alert('Please insert an image file')</script>");
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/EditStore.aspx" + queryString);
        }
    }
}