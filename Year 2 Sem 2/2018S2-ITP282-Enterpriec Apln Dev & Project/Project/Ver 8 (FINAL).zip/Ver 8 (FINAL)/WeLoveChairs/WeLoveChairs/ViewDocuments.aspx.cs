﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WeLoveChairs
{
    public partial class ViewDocuments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_ViewCO_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/CustomerOrder.aspx" + queryString);
        }

        protected void btn_ViewPO_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/PurchaseOrder.aspx" + queryString);
        }

        protected void btn_ViewdO_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/DeliveryOrder.aspx" + queryString);
        }

        protected void btn_ViewInvoice_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/Invoice.aspx" + queryString);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/StaffPage.aspx" + queryString);
        }
    }
}