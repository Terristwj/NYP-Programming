﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WeLoveChairs
{
    public partial class WeLoveChairs : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["login"] != null)   //If login query string exists
            {
                if (Request.QueryString["login"] == "true")
                {
                    hl_Login.Text = "Account";
                    hl_Login2.Text = "Account";
                    urlQueryString(1);
                }
                else if (Request.QueryString["login"] == "false")
                {
                    hl_Login.Text = "Login";
                    hl_Login2.Text = "Login";

                    urlQueryString(-1);
                }
            }
            else
            {
                urlQueryString(-1);
            }
        }

        private void urlQueryString(int index)
        {
            string queryString = "";

            if (index == -1)
            {
                queryString = "?login=false";
                hl_Login.NavigateUrl = "~/Login.aspx" + queryString;
                hl_Login2.NavigateUrl = "~/Login.aspx" + queryString;
            }
            else if (index == 1)
            {
                queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                hl_Login.NavigateUrl = "~/StaffPage.aspx" + queryString;
                hl_Login2.NavigateUrl = "~/StaffPage.aspx" + queryString;
            }

            hl_Home.NavigateUrl = "~/Home.aspx" + queryString;
            hl_Home2.NavigateUrl = "~/Home.aspx" + queryString;


            hl_Catalogue.NavigateUrl = "~/Catalogue.aspx" + queryString;
            hl_Catalogue2.NavigateUrl = "~/Catalogue.aspx" + queryString;


            hl_Support.NavigateUrl = "~/Support.aspx" + queryString;
            hl_Support2.NavigateUrl = "~/Support.aspx" + queryString;
        }

        protected void img_Logo_Click(object sender, ImageClickEventArgs e)
        {
            string queryString = "";

            if (Request.QueryString["login"] != null)   //If login query string exists
            {
                if (Request.QueryString["login"] == "true")
                {
                    queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                    Response.Redirect("Home.aspx" + queryString);
                }
                else if (Request.QueryString["login"] == "false")
                {
                    queryString = "?login=false";
                    Response.Redirect("Home.aspx" + queryString);
                }
            }
            else
            {
                queryString = "?login=false";
                Response.Redirect("Home.aspx" + queryString);
            }
        }
    }
}