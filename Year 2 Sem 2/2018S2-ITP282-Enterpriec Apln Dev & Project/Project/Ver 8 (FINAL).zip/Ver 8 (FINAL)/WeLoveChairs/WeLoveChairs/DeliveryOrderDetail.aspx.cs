﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class DeliveryOrderDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_DeliveryOrder delivery = new BLL_DeliveryOrder();
            string orderID = Request.QueryString["staffID"];
            int Id = int.Parse(Request.QueryString["DeliveryId"]);

            string orderid = delivery.getDeliveryOrderID(Id);
            string supname = delivery.getSupplierNameDO(Id);
            string supemail = delivery.getSupplierEmailDO(Id);
            string supaddress = delivery.getSupplierAddressDO(Id);
            string supcontact = delivery.getSupplierContactDO(Id);

            string coyname = delivery.getCompanyNameDO(Id);
            string coyemail = delivery.getCompanyEmailDO(Id);
            string coyaddress = delivery.getCompanyAddressDO(Id);
            string coycontact = delivery.getCompanyContactDO(Id);

            string date = delivery.getDeliveryOrderDate(Id);
            string status = delivery.getDeliveryOrderStatus(Id);
            string qty = delivery.getQuantityDO(Id);
            string prodId = delivery.getProductIdDO(Id);
            string prodName = delivery.getProductNameDO(Id);
            string desc = delivery.getInvoiceDescDO(Id);
            string unitp = delivery.getUnitPriceDO(Id);
            string amt = delivery.getTotalPriceDO(Id);

            OrderNo.Text = orderid;
            SupplierName.Text = supname;
            SupplierEmail.Text = supemail;
            SupplierAdd.Text = supaddress;
            SupplierContact.Text = supcontact;

            CompanyName.Text = coyname;
            CompanyEmail.Text = coyemail;
            CompanyAdd.Text = coyaddress;
            CompanyConatact.Text = coycontact;

            //dont have order Id 

            Date.Text = date;
            PID.Text = prodId;
            PQty.Text = qty;
            PUnitPrice.Text = unitp;
            PName.Text = prodName;
            PDesc.Text = desc;
            PTotalPrice.Text = amt;
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/DeliveryOrder.aspx" + queryString);
        }

        protected void btnConvert_Click(object sender, EventArgs e)
        {
            //DateTime date = Convert.ToDateTime(Date.Text);
            BLL_Invoice convertCO = new BLL_Invoice();
            convertCO.insertDOtoInvoice(SupplierName.Text, SupplierEmail.Text, SupplierAdd.Text, int.Parse(SupplierContact.Text), Date.Text, CompanyName.Text, CompanyEmail.Text, CompanyAdd.Text, int.Parse(CompanyConatact.Text), PID.Text, PName.Text, PDesc.Text, PUnitPrice.Text, Convert.ToDecimal(PTotalPrice.Text), int.Parse(PQty.Text));

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/Invoice.aspx" + queryString);
        }
    }
}