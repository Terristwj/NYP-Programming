﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class InvoiceDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_Invoice invoice = new BLL_Invoice();
            string orderID = Request.QueryString["staffID"];
            int invoiceId = int.Parse(Request.QueryString["Id"]);

            string orderid = invoice.getInvoiceID(invoiceId);
            string supname = invoice.getSupplierName(invoiceId);
            string supemail = invoice.getSupplierEmail(invoiceId);
            string supaddress = invoice.getSupplierAddress(invoiceId);
            string supcontact = invoice.getSupplierContact(invoiceId);

            string coyname = invoice.getCompanyName(invoiceId);
            string coyemail = invoice.getCompanyEmail(invoiceId);
            string coyaddress = invoice.getCompanyAddress(invoiceId);
            string coycontact = invoice.getCompanyContact(invoiceId);

            string date = invoice.getInvoiceDate(invoiceId);
            string status = invoice.getInvoiceStatus(invoiceId);
            string qty = invoice.getQuantity(invoiceId);
            string prodId = invoice.getProductId(invoiceId);
            string prodName = invoice.getProductName(invoiceId);
            string desc = invoice.getInvoiceDesc(invoiceId);
            string unitp = invoice.getUnitPriceInvoice(invoiceId);
            string amt = invoice.getTotalPrice(invoiceId);

            OrderNo.Text = orderid;
            SupplierName.Text = supname;
            SupplierEmail.Text = supemail;
            SupplierAdd.Text = supaddress;
            SupplierContact.Text = supcontact;

            CompanyName.Text = coyname;
            CompanyEmail.Text = coyemail;
            CompanyAdd.Text = coyaddress;
            CompanyConatact.Text = coycontact;

            //dont have order Id 

            Date.Text = date;
            PID.Text = prodId;
            PQty.Text = qty;
            PUnitPrice.Text = unitp;
            PName.Text = prodName;
            PDesc.Text = desc;
            PTotalPrice.Text = amt;


        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/Invoice.aspx" + queryString);
        }

        
    }
}