﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class DeliveryOrder : System.Web.UI.Page
    {
       
            static string command = "SELECT * FROM DeliveryOrder";
            static string rewriteCommand = "SELECT * FROM DeliveryOrder";
        protected void Page_Load(object sender, EventArgs e)
        {
            string queryString = Request.QueryString["staffID"];
            if (!IsPostBack)
            {
                ViewGridView("None", "None");
            }
        }

        protected void ViewGridView(string condition, string condition_requirement)
        {
            BLL_DeliveryOrder dorderList = new BLL_DeliveryOrder();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = dorderList.getAllDeliveryOrder(rewriteCommand);
                gv_DOrders.DataSource = ds;
                gv_DOrders.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;
                    ds = dorderList.getAllDeliveryOrder(command);
                    gv_DOrders.DataSource = ds;
                    gv_DOrders.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("WHERE"))
                {
                    rewriteCommand = command + " " + condition_requirement;
                    ds = dorderList.getAllDeliveryOrder(rewriteCommand);
                    gv_DOrders.DataSource = ds;
                    gv_DOrders.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    ds = dorderList.getAllDeliveryOrder(finalCommand);
                    gv_DOrders.DataSource = ds;
                    gv_DOrders.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "WHERE Name LIKE '%" + value + "%'";
            ViewGridView("Search", condition_Requirement);
        }


        protected void btn_SortOnly_Click(object sender, EventArgs e)
        {
            string value = ddl_SortOnly.SelectedValue;
            if (value.Equals("None"))
            {
                ViewGridView("None", "None");
            }
            else if (value.Equals("Status - delivered"))
            {
                ViewGridView("WHERE", "WHERE Status = 'delivered'");

            }
            else if (value.Equals("Status - pending"))
            {
                ViewGridView("WHERE", "WHERE Status = 'pending'");

            }

        }

        protected void btn_Sort_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            if (value.Equals("Time"))
            {
                ViewGridView("ORDERBY", "ORDER BY Time");
            }
            else if (value.Equals("Date"))
            {
                ViewGridView("ORDERBY", "ORDER BY Date DESC");
            }
        }


     

        protected void btn_Back_Click(object sender, EventArgs e)
        {
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/ViewDocuments.aspx" + queryString);
        }

        
        protected void gv_DOrders_SelectedIndexChanged1(object sender, EventArgs e)
        {
            BLL_StaffAccount account = new BLL_StaffAccount();
            string position = account.getPosition(Request.QueryString["staffID"]);

            GridViewRow row = gv_DOrders.SelectedRow;
            int DeliveryId = int.Parse(row.Cells[0].Text);

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&DeliveryId=" + DeliveryId;
            Response.Redirect("~/DeliveryOrderDetail.aspx" + queryString);
        }

        //protected void gv_DOrders_RowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    BLL_StaffAccount account = new BLL_StaffAccount();
        //    string position = account.getPosition(Request.QueryString["staffID"]);

        //    if (e.CommandName == "Select")
        //    {
        //        string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"] + "&DeliveryId=" + e.CommandArgument;
        //        Response.Redirect("~/DeliveryOrderDetails.aspx" + queryString);
        //    }
        //}
    }
}
