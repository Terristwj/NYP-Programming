﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class A_BLL_QnA
    {
        public DataSet getAllProduct(string sqlCommand)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            return QnA.getAll(sqlCommand);
        }

        public string getCurrentSize(string id)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            string command = "SELECT currentSize, roomSize from ChatRoom WHERE chatRoomID = '" + id + "' ";
            DataSet myQnA = QnA.getAll(command);

            DataTable dt = new DataTable();
            dt = myQnA.Tables[0];                             // Connect DT to DS

            string data = dt.Rows[0]["currentSize"].ToString();
            return data;
        }

        public string getRoomSize(string id)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            string command = "SELECT currentSize, roomSize from ChatRoom WHERE chatRoomID = '" + id + "' ";
            DataSet myQnA = QnA.getAll(command);

            DataTable dt = new DataTable();
            dt = myQnA.Tables[0];                             // Connect DT to DS

            string data = dt.Rows[0]["roomSize"].ToString();
            return data;
        }

        public void updateChatRoom(string currentSize, string chatRoomID)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            QnA.updateChatRoom(currentSize, chatRoomID);
        }

        public void insertQnAUser(string chatRoomID, string userType, string name)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            QnA.insertQnAUser(chatRoomID, userType, name);
        }

        public void insertQnAMessage(string chatRoomID, string staffName, string message)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            QnA.insertQnAMessage(chatRoomID, staffName, message);
        }

        public void deleteQnAUser(string userType, string name)
        {
            A_DAL_QnA QnA = new A_DAL_QnA();
            QnA.deleteQnAUser(userType, name);
        }
    }
}