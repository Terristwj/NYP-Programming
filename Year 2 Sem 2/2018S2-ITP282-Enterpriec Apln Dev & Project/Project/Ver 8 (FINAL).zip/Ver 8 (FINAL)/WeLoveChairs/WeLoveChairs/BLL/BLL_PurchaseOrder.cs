﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;
using WeLoveChairs.SvcRefJustSofas;

namespace WeLoveChairs.BLL
{
    public class BLL_PurchaseOrder
    {
        public DataSet getAllPurchaseOrder(string sqlCommand)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.GetPurchaseOrder(sqlCommand);
        }

        public DataSet getAllPurchaseOrderDetails(int POId)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.GetPurchaseOrderDetails(POId);
        }

       
        public string getPOrderID(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getPOrderID(PurchaseID);
        }

        public string getSupName(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getSupName(PurchaseID);
        }

   
        public string getSupEmail(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getSupEmail(PurchaseID);
        }


        public string getSupAddress(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getSupAddress(PurchaseID);
        }

       
        public string getSupContact(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getSupContact(PurchaseID);
        }


        ////////company

        public string getCoyName(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getCoyName(PurchaseID);
        }

        public string getCoyEmail(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getCoyEmail(PurchaseID);
        }

        public string getCoyAddress(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getCoyAddress(PurchaseID);
        }


        public string getCoyContact(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getCoyContact(PurchaseID);
        }

        ////////purchase


        public string getDate(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getDate(PurchaseID);
        }


        public string getStatus(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getStatus(PurchaseID);
        }

        public string getQty(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getQty(PurchaseID);
        }


   
        public string getProductId(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getProductId(PurchaseID);
        }

        public string getProductName(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getProductName(PurchaseID);
        }


        public string getProductDesc(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getProductDesc(PurchaseID);
        }


        public string getProductunitPrice(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getProductunitPrice(PurchaseID);
        }
        public string getProductTotal(int PurchaseID)
        {
            DAL_PurchaseOrder POrder = new DAL_PurchaseOrder();
            return POrder.getProductTotal(PurchaseID);
        }

    }
}