﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_Payment
    {
        public void insertPayment(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, string Date)
        {
            DAL_Payment payment = new DAL_Payment();
            payment.insertPayment(supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date);
        }
        public DataSet getAllPayment(string sqlCommand)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getAllPayment(sqlCommand);
        }
        public DataSet getPaymentAll(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getPaymentAll(Id);
        }
        public DataSet getpaymentID(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getpaymentID(Id);
        }
        public DataSet getsupplierName(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getsupplierName(Id);
        }
        public DataSet getamountPayable(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getamountPayable(Id);
        }
        public DataSet getbankAccNum(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getbankAccNum(Id);
        }
        public DataSet getbankAccType(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getbankAccType(Id);
        }
        public DataSet getinvoiceId(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getinvoiceId(Id);
        }
        public DataSet getPaymentDate(int Id)
        {
            DAL_Payment custOrder = new DAL_Payment();
            return custOrder.getPaymentDate(Id);
        }
    }
}