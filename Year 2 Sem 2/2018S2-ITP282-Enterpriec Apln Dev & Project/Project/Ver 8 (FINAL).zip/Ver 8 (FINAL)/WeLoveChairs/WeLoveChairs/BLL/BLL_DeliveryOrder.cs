﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_DeliveryOrder
    {
        //update status
        public DataSet UpdateDeliveryStatus(int DeliveryId)
        {
            DAL_DeliveryOrder dataLayerStatus = new DAL_DeliveryOrder();
            return dataLayerStatus.UpdateDeliveryStatus(DeliveryId);
        }

        public DataSet getAllDeliveryOrder(string sqlCommand)
        {
            DAL_DeliveryOrder custOrder = new DAL_DeliveryOrder();
            return custOrder.getAll(sqlCommand);
        }

        public void insertCOtoDO(string Name, string Email, string Address, int Contact, string Date, string CompanyName, string CompanyEmail, string CompanyAddress, int CompanyContact, string Product_ID, string Product_Name, string PDesc, string UnitPrice, int Quantity, decimal SubTotal)
        {

            DAL_DeliveryOrder insert = new DAL_DeliveryOrder();
            insert.insertCOtoDO(Name, Email, Address, Contact, Date, CompanyName, CompanyEmail, CompanyAddress, CompanyContact, Product_ID, Product_Name, PDesc, UnitPrice, Quantity, SubTotal);


        }
        public string getDeliveryOrderID(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getDeliveryOrderID(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["DeliveryId"].ToString();
            return date;
        }
        public string getDeliveryOrderDate(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getDeliveryOrderDate(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Date"].ToString();
            return date;
        }
        //public DataSet getDeliveryOrderTime(int Id)
        //{
        //    return getDeliveryOrderDetail("Time", Id);
        //}
        public string getDeliveryOrderTime(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getDeliveryOrderTime(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Time"].ToString();
            return date;
        }
        public string getDeliveryOrderStatus(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getDeliveryOrderStatus(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Status"].ToString();
            return date;
        }
        public string getDeliveryOrderCoy(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getDeliveryOrderCoy(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["DeliveryCoy"].ToString();
            return date;
        }
        public string getProductIdDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getProductIdDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["ProductId"].ToString();
            return date;
        }
        public string getQuantityDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getQuantityDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Qty"].ToString();
            return date;
        }
        public string getUnitPriceDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getUnitPriceDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Unit_price"].ToString();
            return date;
        }
        public string getProductNameDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getProductNameDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["ProductName"].ToString();
            return date;
        }
        //public DataSet getDispatchDate(int Id)
        //{
        //    return getDeliveryOrderDetail("DispatchDate", Id);
        //}
        public string getDispatchDate(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getDispatchDate(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["DispatchDate"].ToString();
            return date;
        }
        public string getCompanyNameDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getCompanyNameDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyName"].ToString();
            return date;
        }
        public string getCompanyEmailDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getCompanyEmailDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyEmail"].ToString();
            return date;
        }
        public string getCompanyContactDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getCompanyContactDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyContact"].ToString();
            return date;
        }
        public string getCompanyAddressDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getCompanyAddressDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyAddress"].ToString();
            return date;
        }
        public string getSupplierNameDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getSupplierNameDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Name"].ToString();
            return date;
        }
        public string getInvoiceStatusDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getInvoiceStatusDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["InvoiceStatus"].ToString();
            return date;
        }
        public string getTotalPriceDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getTotalPriceDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["SubTotal"].ToString();
            return date;
        }
        public string getSupplierAddressDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getSupplierAddressDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Address"].ToString();
            return date;
        }
        public string getSupplierEmailDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getSupplierEmailDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Email"].ToString();
            return date;
        }
        public string getSupplierContactDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getSupplierContactDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Contact"].ToString();
            return date;
        }
        public string getInvoiceDescDO(int Id)
        {
            DAL_DeliveryOrder DeliveryOrderDetail = new DAL_DeliveryOrder();
            DataSet myDeliveryOrder = DeliveryOrderDetail.getInvoiceDescDO(Id);

            DataTable dt = new DataTable();
            dt = myDeliveryOrder.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["PDesc"].ToString();
            return date;
        }
    }
}