﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_StaffAccount
    {
        public Boolean loginStatus(string username, string password)
        {
            Boolean loginStatus = false;

            DAL_StaffAccount account = new DAL_StaffAccount();
            DataSet accounts = account.getAll();

            DataTable dt = new DataTable();
            dt = accounts.Tables[0];                             // Connect DT to DS


            foreach (DataRow dr in dt.Rows)
            {
                if (username.Equals(dr["username"].ToString()) && password.Equals(dr["password"].ToString()))
                {
                    loginStatus = true;
                }
            }

            return loginStatus;
        }
        
        public string getStaffID(string username)
        {
            DAL_StaffAccount staffAccount = new DAL_StaffAccount();
            DataSet account = staffAccount.getStaffID(username);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string userID = dt.Rows[0]["staffID"].ToString();
            return userID;
        }

        public string getName(string staffID)
        {
            DAL_StaffAccount staffAccount = new DAL_StaffAccount();
            DataSet account = staffAccount.getName(staffID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string name = dt.Rows[0]["name"].ToString();
            return name;
        }

        public string getPosition(string staffID)
        {
            DAL_StaffAccount staffAccount = new DAL_StaffAccount();
            DataSet account = staffAccount.getPosition(staffID);

            DataTable dt = new DataTable();
            dt = account.Tables[0];                             // Connect DT to DS

            string position = dt.Rows[0]["position"].ToString();
            return position;
        }

        public DataSet getAllStaff(string sqlCommand)
        {
            DAL_StaffAccount staffAccount = new DAL_StaffAccount();
            return staffAccount.getAll(sqlCommand);
        }

        public Boolean checkUsername(string username)
        {
            Boolean taken = false;

            DAL_StaffAccount account = new DAL_StaffAccount();
            DataSet accounts = account.getAllWhere("username", username);

            DataTable dt = new DataTable();
            dt = accounts.Tables[0];                             // Connect DT to DS
            
            foreach (DataRow dr in dt.Rows)
            {
                if (username.Equals(dr["username"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public Boolean checkName(string name)
        {
            Boolean taken = false;

            DAL_StaffAccount account = new DAL_StaffAccount();
            DataSet accounts = account.getAllWhere("name", name);

            DataTable dt = new DataTable();
            dt = accounts.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (name.Equals(dr["name"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public void insertAccount(string username, string password, string name, string position)
        {
            DAL_StaffAccount account = new DAL_StaffAccount();
            account.insertAccount(username, password, name, position);
        }
    }
}