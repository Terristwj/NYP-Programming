﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_WsProduct
    {
        public DataSet GetProducts()
        {
            DAL_WsProduct productList = new DAL_WsProduct();
            return productList.GetAll();
        }

        public DataSet getAllProduct(string sqlCommand)
        {
            DAL_WsProduct productList = new DAL_WsProduct();
            return productList.getAll(sqlCommand);
        }

        public DataSet getImageUrl(string productID)
        {
            DAL_WsProduct product = new DAL_WsProduct();
            return product.getImageUrl(productID);
        }

        public DataSet getName(string productID)
        {
            DAL_WsProduct product = new DAL_WsProduct();
            return product.getName(productID);
        }

        public DataSet getUnitPrice(string productID)
        {
            DAL_WsProduct product = new DAL_WsProduct();
            return product.getUnitPrice(productID);
        }

        public DataSet getDescription(string productID)
        {
            DAL_WsProduct product = new DAL_WsProduct();
            return product.getDescription(productID);
        }

        public DataSet getCategory(string productID)
        {
            DAL_WsProduct product = new DAL_WsProduct();
            return product.getCategory(productID);
        }

        public DataSet getDateCreated(string productID)
        {
            DAL_WsProduct product = new DAL_WsProduct();
            return product.getDateCreated(productID);
        }
    }
}