﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_Product
    {
        public DataSet getAllProduct(string sqlCommand)
        {
            DAL_Product product = new DAL_Product();
            return product.getAll(sqlCommand);
        }

        public string getImageUrl(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getImageUrl(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string imageUrl = dt.Rows[0]["ImageUrl"].ToString();
            return imageUrl;
        }

        public string getName(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getName(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string name = dt.Rows[0]["Name"].ToString();
            return name;
        }

        public double getUnitPrice(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getUnitPrice(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string price = dt.Rows[0]["Unit_Price"].ToString();
            double Unit_Price = Convert.ToDouble(price);

            return Unit_Price;
        }

        public string getDescription(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getDescription(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string description = dt.Rows[0]["Description"].ToString();
            return description;
        }

        public string getCategory(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getCategory(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string category = dt.Rows[0]["Category"].ToString();
            return category;
        }

        public string getCreatorName(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getCreatorName(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string creatorName = dt.Rows[0]["CreatorName"].ToString();
            return creatorName;
        }

        public string getDateCreated(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getDateCreated(product_ID);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string dateCreated = dt.Rows[0]["DateCreated"].ToString();
            return dateCreated;
        }

        public string getProductID(string name)
        {
            DAL_Product product = new DAL_Product();
            DataSet myProduct = product.getProductID(name);

            DataTable dt = new DataTable();
            dt = myProduct.Tables[0];                             // Connect DT to DS

            string Product_ID = dt.Rows[0]["Product_ID"].ToString();
            return Product_ID;
        }

        public void deleteProduct(string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.deleteProduct(product_ID);
        }

        public void insertProduct(string Category, string Name, string Description, string Unit_Price, string ImageUrl, string CreatorName, string DateCreated)
        {
            DAL_Product product = new DAL_Product();
            product.insertProduct(Category, Name, Description, Unit_Price, ImageUrl, CreatorName, DateCreated);
        }

        public Boolean checkName(string name)
        {
            Boolean taken = false;

            DAL_Product product = new DAL_Product();
            DataSet products = product.getName(name);

            DataTable dt = new DataTable();
            dt = products.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (name.Equals(dr["Name"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public Boolean checkName2(string name, string productID)
        {
            Boolean taken = false;

            DAL_Product product = new DAL_Product();
            DataSet products = product.checkName(name, productID);

            DataTable dt = new DataTable();
            dt = products.Tables[0];                             // Connect DT to DS

            foreach (DataRow dr in dt.Rows)
            {
                if (name.Equals(dr["Name"].ToString()))
                {
                    taken = true;
                }
            }

            return taken;
        }

        public void updateCategory(string category, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateCategory(category, product_ID);
        }

        public void updateName(string Name, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateName(Name, product_ID);
        }

        public void updateUnitPrice(string unitPrice, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateUnitPrice(unitPrice, product_ID);
        }

        public void updateDescription(string desciption, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateUnitPrice(desciption, product_ID);
        }

        public void updateImageUrl(string imageUrl, string product_ID)
        {
            DAL_Product product = new DAL_Product();
            product.updateImageUrl(imageUrl, product_ID);
        }
    }
}