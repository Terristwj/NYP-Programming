﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class A_BLL_WsQnA
    {
        public DataSet getAllProduct(string sqlCommand)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            return QnA.getAll(sqlCommand);
        }

        public string getCurrentSize(string id)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            string command = "SELECT currentSize, roomSize from ChatRoom WHERE chatRoomID = '" + id + "' ";
            DataSet myQnA = QnA.getAll(command);

            DataTable dt = new DataTable();
            dt = myQnA.Tables[0];                             // Connect DT to DS

            string data = dt.Rows[0]["currentSize"].ToString();
            return data;
        }

        public string getRoomSize(string id)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            string command = "SELECT currentSize, roomSize from ChatRoom WHERE chatRoomID = '" + id + "' ";
            DataSet myQnA = QnA.getAll(command);

            DataTable dt = new DataTable();
            dt = myQnA.Tables[0];                             // Connect DT to DS

            string data = dt.Rows[0]["roomSize"].ToString();
            return data;
        }
        public void updateChatRoom(string currentSize, string chatRoomID)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            QnA.updateChatRoom(currentSize, chatRoomID);
        }

        public void insertQnARoom(string roomSize, string roomTitle)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            QnA.insertQnARoom(roomSize, roomTitle);
        }

        public void insertQnAUser(string chatRoomID, string userType, string name)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            QnA.insertQnAUser(chatRoomID, userType, name);
        }

        public void insertQnAMessage(string chatRoomID, string userName, string message)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            QnA.insertQnAMessage(chatRoomID, userName, message);
        }

        public void deleteQnARoom(string chatRoomID)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            QnA.deleteQnARoom(chatRoomID);
        }

        public void deleteQnAUser(string userType, string name)
        {
            A_DAL_WsQnA QnA = new A_DAL_WsQnA();
            QnA.deleteQnAUser(userType, name);
        }
    }
}