﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_CustomerOrder
    {
        public DataSet UpdateCustomerOrderStatus(int OrderNO)
        {
            DAL_CustomerOrder dataLayerStatus = new DAL_CustomerOrder();
            return dataLayerStatus.UpdateCustomerOrderStatus(OrderNO);
        }
        public DataSet getAllCustomerOrder(string sqlCommand)
        {
            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            return custOrder.getAll(sqlCommand);
        }

        //public DataSet getAllCOspecified(string sqlcommand)
        //{
        //    DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
        //    return custOrder.getCOspecifed(sqlcommand);
        //}

        public void insertPOtoCO(string Name, string Email, string Address, string Contact, string  Date, string CompanyName, string CompanyEmail, string CompanyAddress, string CompanyContact, string Product_ID, string Product_Name, string PDesc, string UnitPrice, string Quantity, string SubTotal) {

            DAL_CustomerOrder insert = new DAL_CustomerOrder();
            insert.insertPOtoCO(Name, Email, Address, Contact, Date, CompanyName, CompanyEmail, CompanyAddress, CompanyContact, Product_ID, Product_Name, PDesc, UnitPrice, Quantity, SubTotal);
            

        }
        public string getCOrderID(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getCOrderID(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["OrderNO"].ToString();
            return purchaseID;


        }
     
        public string getSupName(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getSupName(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Name"].ToString();
            return purchaseID;


        }

        public string getSupEmail(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getSupEmail(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Email"].ToString();
            return purchaseID;


        }

        public string getSupAddress(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getSupAddress(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Address"].ToString();
            return purchaseID;


        }
      
        public string getSupContact(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getSupContact(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Contact"].ToString();
            return purchaseID;


        }

        public string getCoyName(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getCoyName(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["CompanyName"].ToString();
            return purchaseID;


        }


        public string getCoyEmail(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getCoyEmail(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["CompanyEmail"].ToString();
            return purchaseID;


        }
       
        public string getCoyAddress(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getCoyAddress(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["CompanyAddress"].ToString();
            return purchaseID;


        }
      
        public string getCoyContact(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getCoyContact(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["CompanyContact"].ToString();
            return purchaseID;


        }
       
        public string getDate(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getDate(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Date"].ToString();
            return purchaseID;


        }
    
        public string getStatus(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getStatus(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Status"].ToString();
            return purchaseID;


        }
       
        public string getQty(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getQty(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Quantity"].ToString();
            return purchaseID;


        }
       
        public string getProductId(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getProductId(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Product_ID"].ToString();
            return purchaseID;


        }
        
        public string getProductName(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getProductName(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["Product_Name"].ToString();
            return purchaseID;


        }
 
        public string getProductDesc(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getProductDesc(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["PDesc"].ToString();
            return purchaseID;


        }

        
        public string getProductunitPrice(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getProductunitPrice(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["UnitPrice"].ToString();
            return purchaseID;


        }

        public string getProductTotal(int CustomerOrderID)
        {

            DAL_CustomerOrder custOrder = new DAL_CustomerOrder();
            DataSet customer = custOrder.getProductTotal(CustomerOrderID);

            DataTable dt = new DataTable();
            dt = customer.Tables[0];                             // Connect DT to DS

            string purchaseID = dt.Rows[0]["SubTotal"].ToString();
            return purchaseID;


        }
        
    }
}