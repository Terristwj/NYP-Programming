﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WeLoveChairs.DAL;

namespace WeLoveChairs.BLL
{
    public class BLL_Invoice
    {
        public void UpdateStatus(string invoiceStatus, int invoiceId)
        {
            DAL_Invoice updateInvoice = new DAL_Invoice();
            updateInvoice.UpdateStatus(invoiceStatus, invoiceId);
        }
        public DataSet getAllInvoice(string sqlCommand)
        {
            DAL_Invoice InvoiceOrder = new DAL_Invoice();
            return InvoiceOrder.getAll(sqlCommand);
        }

        public void insertDOtoInvoice(string Name, string Email, string Address, int Contact, string Date, string CompanyName, string CompanyEmail, string CompanyAddress, int CompanyContact, string Product_ID, string Product_Name, string PDesc, string UnitPrice, decimal SubTotal, int Quantity)
        {

            DAL_Invoice insert = new DAL_Invoice();
            insert.insertDOtoInvoice(Name, Email, Address, Contact, Date, CompanyName, CompanyEmail, CompanyAddress, CompanyContact, Product_ID, Product_Name, PDesc, UnitPrice, SubTotal, Quantity);


        }

        public string getInvoiceID(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getInvoiceID(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Id"].ToString();
            return date;
        }

        public string getSupplierName(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getSupplierName(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Name"].ToString();
            return date;
        }

        public string getInvoiceStatus(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getInvoiceStatus(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["InvoiceStatus"].ToString();
            return date;
        }

        public string getInvoiceDate(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getInvoiceDate(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Date"].ToString();
            return date;
        }

        public string getSupplierAddress(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getSupplierAddress(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Address"].ToString();
            return date;
        }

        public string getSupplierEmail(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getSupplierEmail(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Email"].ToString();
            return date;
        }

        public string getSupplierContact(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getSupplierContact(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Contact"].ToString();
            return date;
        }
        public string getCompanyName(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getCompanyName(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyName"].ToString();
            return date;
        }
        public string getCompanyEmail(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getCompanyEmail(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyEmail"].ToString();
            return date;
        }

        public string getCompanyContact(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getCompanyContact(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyContact"].ToString();
            return date;
        }
        public string getCompanyAddress(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getCompanyAddress(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["CompanyAddress"].ToString();
            return date;
        }
        public string getProductId(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getProductId(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["ProductId"].ToString();
            return date;
        }
        public string getProductName(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getProductName(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["ProductName"].ToString();
            return date;
        }
        public string getQuantity(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getQuantity(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["qty"].ToString();
            return date;
        }

        public string getUnitPriceInvoice(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getUnitPriceInvoice(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["unit_price"].ToString();
            return date;
        }
        public string getTotalPrice(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getTotalPrice(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["SubTotal"].ToString();
            return date;
        }
        public string getInvoiceDesc(int invoiceID)
        {
            DAL_Invoice invoiceDetail = new DAL_Invoice();
            DataSet myInvoice = invoiceDetail.getInvoiceDesc(invoiceID);

            DataTable dt = new DataTable();
            dt = myInvoice.Tables[0];                             // Connect DT to DS

            string date = dt.Rows[0]["Description"].ToString();
            return date;
        }
    }
}