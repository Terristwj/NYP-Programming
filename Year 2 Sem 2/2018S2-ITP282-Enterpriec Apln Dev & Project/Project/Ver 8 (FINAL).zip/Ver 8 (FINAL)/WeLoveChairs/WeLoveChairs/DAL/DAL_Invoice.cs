﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
namespace WeLoveChairs.DAL
{
    public class DAL_Invoice
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet InvoiceData;

            SqlConnection conn = dbConn.GetConnection();
            InvoiceData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(InvoiceData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return InvoiceData;
        }

        public DataSet getInvoiceDetail(string selectVariable, int invoiceID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet invoiceData;

            SqlConnection conn = dbConn.GetConnection();
            invoiceData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM Invoice WHERE Id=@invoiceID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@invoiceID", invoiceID);
                da.Fill(invoiceData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return invoiceData;
        }

        public void insertDOtoInvoice(string Name, string Email, string Address, int Contact, string Date, string CompanyName, string CompanyEmail, string CompanyAddress, int CompanyContact, string Product_ID, string Product_Name, string PDesc, string UnitPrice, decimal SubTotal, int Quantity)
        {
            StringBuilder sql;

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO Invoice (Name, Email, Address, Contact, Date, CompanyName, CompanyEmail, CompanyAddress, CompanyContact, ProductId, ProductName, Description, unit_price, SubTotal, qty) ");
            sql.AppendLine(" ");
            sql.AppendLine("VALUES(@Name, @Email, @Address, @Contact, @Date, @CompanyName, @CompanyEmail, @CompanyAddress, @CompanyContact, @ProductId, @ProductName, @Description, @unit_price, @SubTotal, @Quantity)");
            //sql.AppendLine("SET Status == 'pending'");
            SqlConnection conn = dbConn.GetConnection();

            try
            {

                conn.Open();
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                // com.Parameters.AddWithValue("@OrderNO", OrderNo);
                com.Parameters.AddWithValue("@Name", Name);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@Address", Address);
                com.Parameters.AddWithValue("@Contact", Contact);
                com.Parameters.AddWithValue("@Date", Date);
                // com.Parameters.AddWithValue("@Status", Status);
                com.Parameters.AddWithValue("@CompanyName", CompanyName);
                com.Parameters.AddWithValue("@CompanyEmail", CompanyEmail);
                com.Parameters.AddWithValue("@CompanyAddress", CompanyAddress);
                com.Parameters.AddWithValue("@CompanyContact", CompanyContact);
                com.Parameters.AddWithValue("@ProductId", Product_ID);
                com.Parameters.AddWithValue("@ProductName", Product_Name);
                com.Parameters.AddWithValue("@Description", PDesc);
                com.Parameters.AddWithValue("@unit_price", UnitPrice);
                com.Parameters.AddWithValue("@SubTotal", SubTotal);
                com.Parameters.AddWithValue("@Quantity", Quantity);
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
        public DataSet getInvoiceID(int invoiceID)
        {
            return getInvoiceDetail("Id", invoiceID);
        }
        public DataSet getSupplierName(int invoiceID)
        {
            return getInvoiceDetail("Name", invoiceID);
        }
        public DataSet getInvoiceStatus(int invoiceID)
        {
            return getInvoiceDetail("InvoiceStatus", invoiceID);
        }
        public DataSet getInvoiceAll(int invoiceID)
        {
            return getInvoiceDetail("*", invoiceID);
        }

        public DataSet getInvoiceDate(int invoiceID)
        {
            return getInvoiceDetail("Date", invoiceID);
        }

        public DataSet getSupplierAddress(int invoiceID)
        {
            return getInvoiceDetail("Address", invoiceID);
        }

        public DataSet getSupplierEmail(int invoiceID)
        {
            return getInvoiceDetail("Email", invoiceID);
        }

        public DataSet getSupplierContact(int invoiceID)
        {
            return getInvoiceDetail("Contact", invoiceID);
        }

        public DataSet getCompanyName(int invoiceID)
        {
            return getInvoiceDetail("CompanyName", invoiceID);
        }

        public DataSet getCompanyEmail(int invoiceID)
        {
            return getInvoiceDetail("CompanyEmail", invoiceID);
        }

        public DataSet getCompanyContact(int invoiceID)
        {
            return getInvoiceDetail("CompanyContact", invoiceID);
        }
        public DataSet getCompanyAddress(int invoiceID)
        {
            return getInvoiceDetail("CompanyAddress", invoiceID);
        }
        //product
        public DataSet getProductId(int invoiceID)
        {
            return getInvoiceDetail("ProductId", invoiceID);
        }
        public DataSet getProductName(int invoiceID)
        {
            return getInvoiceDetail("ProductName", invoiceID);
        }
        public DataSet getQuantity(int invoiceID)
        {
            return getInvoiceDetail("qty", invoiceID);
        }
        public DataSet getUnitPriceInvoice(int invoiceID)
        {
            return getInvoiceDetail("unit_price", invoiceID);
        }
        public DataSet getTotalPrice(int invoiceID)
        {
            return getInvoiceDetail("SubTotal", invoiceID);
        }
        public DataSet getInvoiceDesc(int invoiceID)
        {
            return getInvoiceDetail("Description", invoiceID);
        }

        public void UpdateStatus(string invoiceStatus, int invoiceId)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("UPDATE Invoice SET InvoiceStatus=@invoiceStatus WHERE Id=@invoiceId");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@invoiceStatus", invoiceStatus);
                com.Parameters.AddWithValue("@invoiceId", invoiceId);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}