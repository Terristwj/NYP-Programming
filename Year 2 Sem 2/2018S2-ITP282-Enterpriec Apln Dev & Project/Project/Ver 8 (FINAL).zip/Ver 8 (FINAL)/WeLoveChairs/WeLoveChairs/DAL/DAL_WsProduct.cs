﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace WeLoveChairs.DAL
{
    public class DAL_WsProduct
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();
        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet GetAll()
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet OSEPsData;

            SqlConnection conn = dbConn.GetConnection();
            OSEPsData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM Products");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(OSEPsData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return OSEPsData;
        }

        public DataSet commonGet(string selectVariable, string product_ID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM Products WHERE product_ID=@product_ID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@product_ID", product_ID);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }

        public DataSet getImageUrl(string product_ID)
        {
            return commonGet("ImageUrl", product_ID);
        }

        public DataSet getName(string product_ID)
        {
            return commonGet("Name", product_ID);
        }

        public DataSet getUnitPrice(string product_ID)
        {
            return commonGet("Unit_Price", product_ID);
        }

        public DataSet getDescription(string product_ID)
        {
            return commonGet("Description", product_ID);
        }

        public DataSet getCategory(string product_ID)
        {
            return commonGet("Category", product_ID);
        }

        public DataSet getDateCreated(string product_ID)
        {
            return commonGet("DateCreated", product_ID);
        }
    }
}