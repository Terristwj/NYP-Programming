﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace WeLoveChairs.DAL
{
    public class DAL_CustomerOrder
    {

        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        //update customer status 
        public DataSet UpdateCustomerOrderStatus(int OrderNO)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet result;


            SqlConnection conn = dbConn.GetConnection();
            result = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("UPDATE CustomerOrder");
            sql.AppendLine("SET Status='Confirmed'");
            sql.AppendLine("WHERE OrderNO=@OrderNO");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@OrderNO", OrderNO);
                da.Fill(result);
            }

            catch (Exception ex)
            {
                errMsg = ex.Message;
            }

            finally
            {
                conn.Close();
            }

            return result;
        }
        public DataSet getAll(string sqlcommand)
        {

            StringBuilder sql;
            SqlDataAdapter da;
            DataSet custOrderData;

            SqlConnection conn = dbConn.GetConnection();
            custOrderData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlcommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(custOrderData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return custOrderData;
        }

        public void insertPOtoCO(string Name, string Email, string Address, string Contact, string Date, string CompanyName, string CompanyEmail, string CompanyAddress, string CompanyContact, string Product_ID, string Product_Name, string PDesc, string UnitPrice, string Quantity, string SubTotal)
        {
            StringBuilder sql;
           
            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO CustomerOrder (Name, Email, Address, Contact, Date, CompanyName, CompanyEmail, CompanyAddress, CompanyContact, Product_ID, Product_Name, PDesc, UnitPrice, SubTotal) ");
            sql.AppendLine(" ");
            sql.AppendLine("VALUES(@Name, @Email, @Address, @Contact, @Date, @CompanyName, @CompanyEmail, @CompanyAddress, @CompanyContact, @Product_ID, @Product_Name, @PDesc, @UnitPrce, @SubTotal)");
            //sql.AppendLine("SET Status == 'pending'");
            SqlConnection conn = dbConn.GetConnection();

            try
            {
                
                conn.Open();
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
               // com.Parameters.AddWithValue("@OrderNO", OrderNo);
                com.Parameters.AddWithValue("@Name", Name);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@Address", Address);
                com.Parameters.AddWithValue("@Contact", Contact);
                com.Parameters.AddWithValue("@Date", Date);
               // com.Parameters.AddWithValue("@Status", Status);
                com.Parameters.AddWithValue("@CompanyName", CompanyName);
                com.Parameters.AddWithValue("@CompanyEmail", CompanyEmail);
                com.Parameters.AddWithValue("@CompanyAddress", CompanyAddress);
                com.Parameters.AddWithValue("@CompanyContact", CompanyContact);
                com.Parameters.AddWithValue("@Product_ID", Product_ID);
                com.Parameters.AddWithValue("@Product_Name", Product_Name);
                com.Parameters.AddWithValue("@PDesc", PDesc);
                com.Parameters.AddWithValue("@UnitPrce", UnitPrice);
                com.Parameters.AddWithValue("@SubTotal", SubTotal);
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }

        //    public DataSet getCOspecifed(string sqlcommand)
        //    {
        //        StringBuilder sql;
        //        SqlDataAdapter da;
        //        DataSet custOrderData;

        //        SqlConnection conn = dbConn.GetConnection();
        //        custOrderData = new DataSet();
        //        sql = new StringBuilder();
        //       // sqlcommand = "SELECT * FROM CustomerOrder WHERE CompanyName == 'JustSofas'";
        //        sql.AppendLine(sqlcommand + "SELECT * FROM CustomerOrder WHERE CompanyName == 'JustSofas'");

        //        try
        //        {
        //            da = new SqlDataAdapter(sql.ToString(), conn);
        //            da.Fill(custOrderData);
        //        }
        //        catch (Exception ex)
        //        {
        //            errMsg = ex.Message;
        //        }
        //        finally
        //        {
        //            conn.Close();
        //        }

        //        return custOrderData;
        //    }
        //}

        public DataSet commonGet(string selectVariable, int Id)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet productData;

            SqlConnection conn = dbConn.GetConnection();
            productData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM CustomerOrder WHERE OrderNO=@Id");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@Id", Id);
                da.Fill(productData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return productData;
        }



        //supplier

        public DataSet getCOrderID(int CustomerOrderID)
        {

            return commonGet("OrderNO", CustomerOrderID);

        }
        public DataSet getSupName(int CustomerOrderID)
        {

            return commonGet("Name", CustomerOrderID);

        }

        public DataSet getSupEmail(int CustomerOrderID)
        {

            return commonGet("Email", CustomerOrderID);

        }

        public DataSet getSupAddress(int CustomerOrderID)
        {

            return commonGet("Address", CustomerOrderID);

        }

        public DataSet getSupContact(int CustomerOrderID)
        {

            return commonGet("Contact", CustomerOrderID);

        }

        //company
        public DataSet getCoyName(int CustomerOrderID)
        {

            return commonGet("CompanyName", CustomerOrderID);

        }

        public DataSet getCoyEmail(int CustomerOrderID)
        {

            return commonGet("CompanyEmail", CustomerOrderID);

        }

        public DataSet getCoyAddress(int CustomerOrderID)
        {

            return commonGet("CompanyAddress", CustomerOrderID);

        }

        public DataSet getCoyContact(int CustomerOrderID)
        {

            return commonGet("CompanyContact", CustomerOrderID);

        }
        //purchase
        public DataSet getDate(int CustomerOrderID)
        {

            return commonGet("Date", CustomerOrderID);

        }

        public DataSet getStatus(int CustomerOrderID)
        {

            return commonGet("Status", CustomerOrderID);

        }

        public DataSet getQty(int CustomerOrderID)
        {

            return commonGet("Quantity", CustomerOrderID);

        }

        public DataSet getProductId(int CustomerOrderID)
        {

            return commonGet("Product_ID", CustomerOrderID);

        }

        public DataSet getProductName(int CustomerOrderID)
        {

            return commonGet("Product_Name", CustomerOrderID);

        }
        public DataSet getProductDesc(int CustomerOrderID)
        {

            return commonGet("PDesc", CustomerOrderID);

        }

        public DataSet getProductunitPrice(int CustomerOrderID)
        {

            return commonGet("UnitPrice", CustomerOrderID);

        }
        public DataSet getProductTotal(int CustomerOrderID)
        {

            return commonGet("SubTotal", CustomerOrderID);

        }
    }
}