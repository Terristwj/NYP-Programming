﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using WeLoveChairs.SvcRefJustSofas;

namespace WeLoveChairs.DAL
{
    public class DAL_PurchaseOrder
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        //public DataSet getAll(string sqlCommand)
        //{
        //    StringBuilder sql;
        //    SqlDataAdapter da;
        //    DataSet POrderData;

        //    SqlConnection conn = dbConn.GetConnection();
        //    POrderData = new DataSet();
        //    sql = new StringBuilder();
        //    sql.AppendLine(sqlCommand);

        //    try
        //    {
        //        da = new SqlDataAdapter(sql.ToString(), conn);
        //        da.Fill(POrderData);
        //    }
        //    catch (Exception ex)
        //    {
        //        errMsg = ex.Message;
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }

        //    return POrderData;
        //}

        public DataSet GetPurchaseOrder(string sqlcommand) {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.GetPurchaseOrder(sqlcommand);

        }

        public DataSet GetPurchaseOrderDetails(int POId)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.GetPurchaseOrderDetails(POId);

        }


        public string getPOrderID(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getPOrderID(PurchaseID);

        }

        public string getSupName(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getSupNmame(PurchaseID);

        }

        public string getSupEmail(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getSupEmail(PurchaseID);

        }

        public string getSupAddress(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getSupAddress(PurchaseID);

        }


        public string getSupContact(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getSupContact(PurchaseID);

        }

        ////////company

        public string getCoyName(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getCoyName(PurchaseID);

        }

        public string getCoyEmail(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getCoyEmail(PurchaseID);

        }
      
        public string getCoyAddress(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getCoyAddress(PurchaseID);

        }
       
        public string getCoyContact(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getCoyContact(PurchaseID);

        }
        ////////purchase


        public string getDate(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getDate(PurchaseID);

        }

       
        public string getStatus(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getStatus(PurchaseID);

        }

        public string getQty(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getQty(PurchaseID);

        }
       
        public string getProductId(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getProductId(PurchaseID);

        }
       
        public string getProductName(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getProductName(PurchaseID);

        }

      
        public string getProductDesc(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getProductDesc(PurchaseID);

        }

     
        public string getProductunitPrice(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getProductunitPrice(PurchaseID);

        }

        public string getProductTotal(int PurchaseID)
        {

            WsJustSofasClient JustSofasClient;
            JustSofasClient = new WsJustSofasClient();

            return JustSofasClient.getProductTotal(PurchaseID);

        }
    }
}