﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WeLoveChairs.DAL
{
    public class DAL_DbConnection
    {
        public SqlConnection GetConnection()
        {
            SqlConnection dbConn;
            String connString = ConfigurationManager.ConnectionStrings["WeLoveChairsDB"].ConnectionString;
            dbConn = new SqlConnection(connString);

            return dbConn;
        }
    }
}