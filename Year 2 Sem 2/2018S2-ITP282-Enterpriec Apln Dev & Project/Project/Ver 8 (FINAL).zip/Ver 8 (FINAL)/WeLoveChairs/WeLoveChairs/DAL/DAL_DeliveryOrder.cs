﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace WeLoveChairs.DAL
{
    public class DAL_DeliveryOrder
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();

        //update delivery status 
        public DataSet UpdateDeliveryStatus(int doNo)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet result;


            SqlConnection conn = dbConn.GetConnection();
            result = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("UPDATE DeliveryOrder");
            sql.AppendLine("SET Status='Delivered'");
            sql.AppendLine("WHERE DeliveryId=@DeliveryId");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@DeliveryId", doNo);
                da.Fill(result);
            }

            catch (Exception ex)
            {
                errMsg = ex.Message;
            }

            finally
            {
                conn.Close();
            }

            return result;
        }
        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet deliveryOrderData;

            SqlConnection conn = dbConn.GetConnection();
            deliveryOrderData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(deliveryOrderData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return deliveryOrderData;
        }

        public DataSet getDeliveryOrderDetail(string selectVariable, int Id)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet DeliveryOrderData;

            SqlConnection conn = dbConn.GetConnection();
            DeliveryOrderData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM DeliveryOrder WHERE DeliveryId=@Id");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@Id", Id);
                da.Fill(DeliveryOrderData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return DeliveryOrderData;
        }

        public void insertCOtoDO(string Name, string Email, string Address, int Contact, string Date, string CompanyName, string CompanyEmail, string CompanyAddress, int CompanyContact, string Product_ID, string Product_Name, string PDesc, string UnitPrice, int Quantity, decimal SubTotal)
        {
            StringBuilder sql;

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO DeliveryOrder (Name, Email, Address, Contact, Date, CompanyName, CompanyEmail, CompanyAddress, CompanyContact, ProductId, ProductName, PDesc, Unit_Price, SubTotal) ");
            sql.AppendLine(" ");
            sql.AppendLine("VALUES(@Name, @Email, @Address, @Contact, @Date, @CompanyName, @CompanyEmail, @CompanyAddress, @CompanyContact, @ProductId, @ProductName, @PDesc, @UnitPrice, @SubTotal)");
            //sql.AppendLine("SET Status == 'pending'");
            SqlConnection conn = dbConn.GetConnection();

            try
            {

                conn.Open();
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                // com.Parameters.AddWithValue("@OrderNO", OrderNo);
                com.Parameters.AddWithValue("@Name", Name);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@Address", Address);
                com.Parameters.AddWithValue("@Contact", Contact);
                com.Parameters.AddWithValue("@Date", Date);
                // com.Parameters.AddWithValue("@Status", Status);
                com.Parameters.AddWithValue("@CompanyName", CompanyName);
                com.Parameters.AddWithValue("@CompanyEmail", CompanyEmail);
                com.Parameters.AddWithValue("@CompanyAddress", CompanyAddress);
                com.Parameters.AddWithValue("@CompanyContact", CompanyContact);
                com.Parameters.AddWithValue("@ProductId", Product_ID);
                com.Parameters.AddWithValue("@ProductName", Product_Name);
                com.Parameters.AddWithValue("@PDesc", PDesc);
                com.Parameters.AddWithValue("@UnitPrice", UnitPrice);
                com.Parameters.AddWithValue("@SubTotal", SubTotal);
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
        public DataSet getDeliveryOrderAll(int Id)
        {
            return getDeliveryOrderDetail("*", Id);
        }
        public DataSet getDeliveryOrderID(int Id)
        {
            return getDeliveryOrderDetail("DeliveryId", Id);
        }
        public DataSet getDeliveryOrderDate(int Id)
        {
            return getDeliveryOrderDetail("Date", Id);
        }
        public DataSet getDeliveryOrderTime(int Id)
        {
            return getDeliveryOrderDetail("Time", Id);
        }
        public DataSet getDeliveryOrderStatus(int Id)
        {
            return getDeliveryOrderDetail("Status", Id);
        }
        public DataSet getDeliveryOrderCoy(int Id)
        {
            return getDeliveryOrderDetail("DeliveryCoy", Id);
        }

        public DataSet getProductIdDO(int Id)
        {
            return getDeliveryOrderDetail("ProductId", Id);
        }
        public DataSet getQuantityDO(int Id)
        {
            return getDeliveryOrderDetail("Qty", Id);
        }
        public DataSet getUnitPriceDO(int Id)
        {
            return getDeliveryOrderDetail("Unit_price", Id);
        }
        public DataSet getProductNameDO(int Id)
        {
            return getDeliveryOrderDetail("ProductName", Id);
        }
        public DataSet getDispatchDate(int Id)
        {
            return getDeliveryOrderDetail("DispatchDate", Id);
        }
        public DataSet getCompanyNameDO(int Id)
        {
            return getDeliveryOrderDetail("CompanyName", Id);
        }

        public DataSet getCompanyEmailDO(int Id)
        {
            return getDeliveryOrderDetail("CompanyEmail", Id);
        }

        public DataSet getCompanyContactDO(int Id)
        {
            return getDeliveryOrderDetail("CompanyContact", Id);
        }
        public DataSet getCompanyAddressDO(int Id)
        {
            return getDeliveryOrderDetail("CompanyAddress", Id);
        }
        public DataSet getSupplierNameDO(int Id)
        {
            return getDeliveryOrderDetail("Name", Id);
        }
        public DataSet getInvoiceStatusDO(int Id)
        {
            return getDeliveryOrderDetail("InvoiceStatus", Id);
        }
        public DataSet getTotalPriceDO(int Id)
        {
            return getDeliveryOrderDetail("SubTotal", Id);
        }
        public DataSet getSupplierAddressDO(int Id)
        {
            return getDeliveryOrderDetail("Address", Id);
        }

        public DataSet getSupplierEmailDO(int Id)
        {
            return getDeliveryOrderDetail("Email", Id);
        }
        public DataSet getSupplierContactDO(int Id)
        {
            return getDeliveryOrderDetail("Contact", Id);
        }
        public DataSet getInvoiceDescDO(int Id)
        {
            return getDeliveryOrderDetail("PDesc", Id);
        }
    }
}