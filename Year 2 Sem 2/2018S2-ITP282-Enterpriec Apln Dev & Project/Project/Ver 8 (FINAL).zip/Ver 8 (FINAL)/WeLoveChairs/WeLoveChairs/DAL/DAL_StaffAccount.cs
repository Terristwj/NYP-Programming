﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace WeLoveChairs.DAL
{
    public class DAL_StaffAccount
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();
        
        public DataSet getAll()
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet staffAccountsData;

            SqlConnection conn = dbConn.GetConnection();
            staffAccountsData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM staffAccount");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(staffAccountsData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return staffAccountsData;
        }

        public DataSet getAll(string sqlCommand)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet staffAccountsData;

            SqlConnection conn = dbConn.GetConnection();
            staffAccountsData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine(sqlCommand);

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(staffAccountsData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return staffAccountsData;
        }

        public DataSet getAllWhere(string whereCondition, string whereValue)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet staffAccountData;

            SqlConnection conn = dbConn.GetConnection();
            staffAccountData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM staffAccount WHERE " + whereCondition + "=@whereValue");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@whereValue", whereValue);
                da.Fill(staffAccountData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return staffAccountData;
        }

        public DataSet getStaffID(string username)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet staffAccountData;

            SqlConnection conn = dbConn.GetConnection();
            staffAccountData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT staffID FROM staffAccount WHERE username=@username");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@username", username);
                da.Fill(staffAccountData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return staffAccountData;
        }

        public DataSet commonGet(string selectVariable, string staffID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet staffAccountData;

            SqlConnection conn = dbConn.GetConnection();
            staffAccountData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT " + selectVariable + " FROM staffAccount WHERE staffID=@staffID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@staffID", staffID);
                da.Fill(staffAccountData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return staffAccountData;
        }

        public DataSet getName(string staffID)
        {
            return commonGet("name", staffID);
        }

        public DataSet getPosition(string staffID)
        {
            return commonGet("position", staffID);
        }


        public void insertAccount(string username, string password, string name, string position)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO [staffAccount](username, password, name, position) VALUES(@username, @password, @name, @position)");

            try
            {
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@username", username);
                com.Parameters.AddWithValue("@password", password);
                com.Parameters.AddWithValue("@name", name);
                com.Parameters.AddWithValue("@position", position);

                conn.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}