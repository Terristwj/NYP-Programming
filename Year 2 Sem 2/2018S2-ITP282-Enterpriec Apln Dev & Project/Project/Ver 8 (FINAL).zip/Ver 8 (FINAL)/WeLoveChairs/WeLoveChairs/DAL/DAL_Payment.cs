﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using WeLoveChairs.SvcRefJustSofas;

namespace WeLoveChairs.DAL
{
    public class DAL_Payment
    {
        private string errMsg;
        DAL_DbConnection dbConn = new DAL_DbConnection();
        public void insertPayment(string supplierName, double amountPayable, int bankAccNum, string bankAccType, int invoiceId, string Date)
        {
            StringBuilder sql;
            SqlConnection conn = dbConn.GetConnection();

            sql = new StringBuilder();
            sql.AppendLine("INSERT INTO Payment(supplierName, amountPayable, bankAccNum, bankAccType, invoiceId, Date)");
            sql.AppendLine("VALUES(@supplierName, @amountPayable, @bankAccNum, @bankAccType, @invoiceId, @Date)");

            try
            {
                conn.Open();
                SqlCommand com = new SqlCommand(sql.ToString(), conn);
                com.Parameters.AddWithValue("@supplierName", supplierName);
                com.Parameters.AddWithValue("@amountPayable", amountPayable);
                com.Parameters.AddWithValue("@bankAccNum", bankAccNum);
                com.Parameters.AddWithValue("@bankAccType", bankAccType);
                com.Parameters.AddWithValue("@invoiceId", invoiceId);
                com.Parameters.AddWithValue("@Date", Date);
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }
        }
        public DataSet getAllPayment(string sqlCommand)
        {
            //WsJustSofasClient weLoveChairsClient;
            //weLoveChairsClient = new WsJustSofasClient();
            //return weLoveChairsClient.getAllPayment(sqlCommand);
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet invoiceData;

            SqlConnection conn = dbConn.GetConnection();
            invoiceData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM Payment");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.Fill(invoiceData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return invoiceData;

        }
        public DataSet getPaymentAll(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getPaymentAll(Id);
        }
        public DataSet getpaymentID(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getpaymentID(Id);
        }
        public DataSet getsupplierName(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getsupplierName(Id);
        }
        public DataSet getamountPayable(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getamountPayable(Id);
        }
        public DataSet getbankAccNum(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getbankAccNum(Id);
        }
        public DataSet getbankAccType(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getbankAccType(Id);
        }
        public DataSet getinvoiceId(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getinvoiceId(Id);
        }
        public DataSet getPaymentDate(int Id)
        {
            WsJustSofasClient weLoveChairsClient;
            weLoveChairsClient = new WsJustSofasClient();
            return weLoveChairsClient.getpaymentDate(Id);
        }

        public DataSet getPaymentDetail(int paymentID)
        {
            StringBuilder sql;
            SqlDataAdapter da;
            DataSet invoiceData;

            SqlConnection conn = dbConn.GetConnection();
            invoiceData = new DataSet();
            sql = new StringBuilder();
            sql.AppendLine("SELECT * FROM Invoice WHERE Id=@invoiceID");

            try
            {
                da = new SqlDataAdapter(sql.ToString(), conn);
                da.SelectCommand.Parameters.AddWithValue("@invoiceID", paymentID);
                da.Fill(invoiceData);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return invoiceData;
        }
    }
}