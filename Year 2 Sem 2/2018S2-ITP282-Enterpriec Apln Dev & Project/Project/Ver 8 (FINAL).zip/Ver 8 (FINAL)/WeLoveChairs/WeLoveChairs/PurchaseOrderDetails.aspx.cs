﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class PurchaseOrderDetails1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLL_PurchaseOrder purchaseOrder = new BLL_PurchaseOrder();
            string orderID = Request.QueryString["staffID"];
            int purchaseId = int.Parse(Request.QueryString["PurchaseId"]);

            string orderid = purchaseOrder.getPOrderID(purchaseId);
            string supname = purchaseOrder.getSupName(purchaseId);
            string supemail = purchaseOrder.getSupEmail(purchaseId);
            string supaddress = purchaseOrder.getSupAddress(purchaseId);
            string supcontact = purchaseOrder.getSupContact(purchaseId);

            string coyname = purchaseOrder.getCoyName(purchaseId);
            string coyemail = purchaseOrder.getCoyEmail(purchaseId);
            string coyaddress = purchaseOrder.getCoyAddress(purchaseId);
            string coycontact = purchaseOrder.getCoyContact(purchaseId);

            string date = purchaseOrder.getDate(purchaseId);
            string status = purchaseOrder.getStatus(purchaseId);
            string qty = purchaseOrder.getQty(purchaseId);
            string prodId = purchaseOrder.getProductId(purchaseId);
            string prodName = purchaseOrder.getProductName(purchaseId);
            string desc = purchaseOrder.getProductDesc(purchaseId);
            string unitp = purchaseOrder.getProductunitPrice(purchaseId);
            string amt = purchaseOrder.getProductTotal(purchaseId);

            OrderNo.Text = orderid;
            SupplierName.Text = supname;
            SupplierEmail.Text = supemail;
            SupplierAdd.Text = supaddress;
            SupplierContact.Text = supcontact;

            CompanyName.Text = coyname;
            CompanyEmail.Text = coyemail;
            CompanyAdd.Text = coyaddress;
            CompanyConatact.Text = coycontact;

            //dont have order Id 
      
            Date.Text = date;
            PID.Text = prodId;
            PQty.Text = qty;
            PUnitPrice.Text = unitp;
            PName.Text = prodName;
            PDesc.Text = desc;
            PTotalPrice.Text = amt;
            

        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
         
            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/PurchaseOrder.aspx" + queryString);
        }

        protected void btnConvert_Click(object sender, EventArgs e)
        {
           // DateTime date = Convert.ToDateTime(Date.Text).Date;
            BLL_CustomerOrder convertPO = new BLL_CustomerOrder();
            convertPO.insertPOtoCO(SupplierName.Text, SupplierEmail.Text, SupplierAdd.Text, SupplierContact.Text, Date.Text, CompanyName.Text, CompanyEmail.Text, CompanyAdd.Text, CompanyConatact.Text, PID.Text, PName.Text, PDesc.Text, PUnitPrice.Text, PQty.Text, PTotalPrice.Text);

            string queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
            Response.Redirect("~/CustomerOrder.aspx" + queryString);
        }
    }
}