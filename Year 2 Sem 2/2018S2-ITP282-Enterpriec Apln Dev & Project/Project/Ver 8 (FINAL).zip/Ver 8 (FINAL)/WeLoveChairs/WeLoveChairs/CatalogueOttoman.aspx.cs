﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WeLoveChairs.BLL;

namespace WeLoveChairs
{
    public partial class CatalogueOttoman : System.Web.UI.Page
    {
        static string command = "SELECT * FROM Products WHERE Category = 'Ottoman'";
        static string rewriteCommand = "SELECT * FROM Products WHERE Category = 'Ottoman'";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewDataList("None", "None");
            }
        }

        protected void ViewDataList(string condition, string condition_requirement)
        {
            BLL_Product product = new BLL_Product();
            DataSet ds;

            if (condition.Equals("Search")) // Search Bar
            {
                rewriteCommand = command + " " + condition_requirement;

                ds = product.getAllProduct(rewriteCommand);
                dl_Products.DataSource = ds;
                dl_Products.DataBind();

                ddl_Sort.SelectedIndex = 0;
            }
            else // Drop Down List
            {
                if (condition.Equals("None"))
                {
                    rewriteCommand = command;

                    ds = product.getAllProduct(command);
                    dl_Products.DataSource = ds;
                    dl_Products.DataBind();

                    ddl_Sort.SelectedIndex = 0;
                    tb_Search.Text = "";
                }
                else if (condition.Equals("ORDERBY"))
                {
                    string finalCommand = rewriteCommand + " " + condition_requirement;
                    
                    ds = product.getAllProduct(finalCommand);
                    dl_Products.DataSource = ds;
                    dl_Products.DataBind();
                }
            }
        }

        protected void btn_Search_Click(object sender, EventArgs e)
        {
            string value = tb_Search.Text;
            string condition_Requirement = "AND Name LIKE '%" + value + "%'";
            ViewDataList("Search", condition_Requirement);
        }
        protected void btn_DDL_Click(object sender, EventArgs e)
        {
            string value = ddl_Sort.SelectedValue;
            if (value.Equals("Product ID"))
            {
                ViewDataList("ORDERBY", "ORDER BY Product_ID ASC");
            }
            else if (value.Equals("Category"))
            {
                ViewDataList("ORDERBY", "ORDER BY Category ASC");
            }
            else if (value.Equals("Name"))
            {
                ViewDataList("ORDERBY", "ORDER BY Name ASC");
            }
            else if (value.Equals("High Price"))
            {
                ViewDataList("ORDERBY", "ORDER BY Unit_Price DESC");
            }
            else if (value.Equals("Low Price"))
            {
                ViewDataList("ORDERBY", "ORDER BY Unit_Price ASC");
            }
        }

        protected void dl_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                string queryString = "";
                if (Request.QueryString["login"] == "false")
                {
                    queryString = "?login=false";
                }
                else if (Request.QueryString["staffID"] != null)
                {
                    queryString = "?login=true" + "&staffID=" + Request.QueryString["staffID"];
                }


                BLL_Product product = new BLL_Product();
                string productName = ((Label)dl_Products.Items[e.Item.ItemIndex].FindControl("lb_Name")).Text;
                string productID = product.getProductID(productName);

                queryString += "&product=" + productID;
                Response.Redirect("~/ProductPage.aspx" + queryString);
            }
        }
    }
}