﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Week3_Lab3c__Part_2_.Startup))]
namespace Week3_Lab3c__Part_2_
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
