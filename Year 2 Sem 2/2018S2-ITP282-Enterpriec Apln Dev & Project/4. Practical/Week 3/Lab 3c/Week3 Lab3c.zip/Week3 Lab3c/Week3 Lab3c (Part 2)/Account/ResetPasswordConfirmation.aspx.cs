﻿using System.Web.UI;

namespace Week3_Lab3c__Part_2_.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}