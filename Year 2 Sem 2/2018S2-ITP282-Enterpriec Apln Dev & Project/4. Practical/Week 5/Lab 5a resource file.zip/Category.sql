INSERT INTO Category(Name) VALUES('Adventure/Action');
INSERT INTO Category(Name) VALUES('Animation');
INSERT INTO Category(Name) VALUES('Drama');
INSERT INTO Category(Name) VALUES('Horror');
INSERT INTO Category(Name) VALUES('Romance');
INSERT INTO Category(Name) VALUES('Comedy');
