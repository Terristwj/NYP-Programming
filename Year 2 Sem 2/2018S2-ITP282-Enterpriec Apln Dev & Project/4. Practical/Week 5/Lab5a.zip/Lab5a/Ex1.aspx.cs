﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Ex1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRetrieve_Click(object sender, EventArgs e)
    {
        string strConnectionString = ConfigurationManager.ConnectionStrings["DVDShopConnectionString"].ConnectionString;

        SqlConnection myConnect = new SqlConnection(strConnectionString);

        string strCommandText = "SELECT CategoryID, Name from Category";
        SqlCommand cmd = new SqlCommand(strCommandText, myConnect);

        myConnect.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        
        lblResult.Text = "";
        while (reader.Read())
        {
            lblResult.Text += reader["CategoryID"].ToString() + ",";
            lblResult.Text += reader["Name"].ToString() + "<br/>";
        }

        reader.Close();
        myConnect.Close();

    }

    protected void btnRetrieve_Click2(object sender, EventArgs e)
    {
        string strConnectionString = ConfigurationManager.ConnectionStrings["DVDShopConnectionString"].ConnectionString;

        SqlConnection myConnect = new SqlConnection(strConnectionString);

        string strCommandText = "SELECT ProductID, Title, Price from Product";
        SqlCommand cmd = new SqlCommand(strCommandText, myConnect);

        myConnect.Open();
        SqlDataReader reader = cmd.ExecuteReader();

        lblResult2.Text = "";
        while (reader.Read())
        {
            lblResult2.Text += reader["ProductID"].ToString() + ". ";
            lblResult2.Text += reader["Title"].ToString() + ",";
            lblResult2.Text += reader["Price"].ToString() + "<br/>";
        }

        reader.Close();
        myConnect.Close();

    }
}