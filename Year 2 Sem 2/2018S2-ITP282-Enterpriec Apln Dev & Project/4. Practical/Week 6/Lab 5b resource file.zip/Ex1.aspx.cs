using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Ex1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRetrieve_Click(object sender, EventArgs e)
    {
       
     
      
        // retrieve connection info from web.config
        string strConnectionString =
        ConfigurationManager.ConnectionStrings["DVDShopConnectionString"].ConnectionString;
        
        //create connection
        SqlConnection myConnect = new SqlConnection(strConnectionString);

        //create command
        string strCommandText = "SELECT CategoryID, Name from Category";
        SqlCommand cmd = new SqlCommand(strCommandText, myConnect);

        //open connection and retrieve data by calling ExecuteReader
        myConnect.Open();
        SqlDataReader reader = cmd.ExecuteReader();

        // Access data
        lblResult.Text = "";
        while (reader.Read())
        {
            lblResult.Text += reader["CategoryID"].ToString() + ",";
            lblResult.Text += reader["Name"].ToString() + "<br/>";
        }

        //close reader  & connection
        reader.Close();
        myConnect.Close();
    }
}
