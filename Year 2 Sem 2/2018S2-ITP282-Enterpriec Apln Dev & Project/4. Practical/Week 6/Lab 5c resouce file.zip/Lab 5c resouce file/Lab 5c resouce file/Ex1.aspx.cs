﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Ex2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // page is loaded for very 1st time
        // bind all 3 controls
        if (Page.IsPostBack == false)
        {

            bindListBox();
            bindRadioButtonList();
            bindCheckBoxList();
          
        }
    }

    private void bindListBox()
    {

        ddlCategory.DataSource = getReader();
        // Name will be displayed in the dropdownlist control
        ddlCategory.DataTextField = "Name";
        // when an item is selected in dropdownlist
        // CategoryID will be returned in ddlCategory.SelectedValue
        ddlCategory.DataValueField = "CategoryID";
        ddlCategory.DataBind();

    }
    private SqlDataReader getReader()
    {
        //get connection string from web.config
        string strConnectionString =
            ConfigurationManager.ConnectionStrings["DVDShopConnectionString"].ConnectionString;
        SqlConnection myConnect = new SqlConnection(strConnectionString);

        string strCommandText = "SELECT CategoryID, Name  from Category";

        SqlCommand cmd = new SqlCommand(strCommandText, myConnect);
        myConnect.Open();
        // CommandBehavior.CloseConnection will automatically close connection
        SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        return reader;
    }

   
    


    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblResult.Text= "Category ID:" + ddlCategory.SelectedValue.ToString()  +"<br/>" ;
        lblResult.Text += "Name:" + ddlCategory.SelectedItem.Text;
    }


    private void bindCheckBoxList()
    {
        // TO DO: Complete codes to bind check box list to data reader


    }
    private void bindRadioButtonList()
    {

        // TO DO: Complete codes to bind radio button list to data reader

    }


 
 
    protected void rdoCategory_SelectedIndexChanged(object sender, EventArgs e)
    {

        // TO DO: Complete codes to display SelectedValue and SelectedItem of item selected
        // for radio button list
        
    }

    protected void chkCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblResult.Text = "";
        // TO DO: Complete codes to display SelectedValues and SelectedItems of items selected
        // for check box list
        // note: more than one item may be selected at any one time
        
      
    }
}