/* JS Document */

$(document).ready(function() {
	"use strict";

	if ($('.blog-slider').length) {
        $('.blog-slider').owlCarousel({
            loop: false,
            margin: 10,
            items: 1,
            nav: true,
            autoplay: 0,
            smartSpeed: 1000,
            dots: false,
            responsiveClass: true,
            navText : ["<div class='blog-slider__leftArrow'><img src='images/blog/left-arrow.png'></div>","<div class='blog-slider__rightArrow'><img src='images/blog/right-arrow.png'></div>"],
            responsive:{
              0:{
                  items:1
              },
              600:{
                  items:2
              },
              1000:{
                  items:3
              }
            }
        })
    }

    $(document).on("click", ".pullFoldCarousel_Arrow", function() {
        var x = document.getElementsByClassName("products_container");
        if (x[0].classList.contains("pullCarousel")){
            x[0].classList.remove("pullCarousel");
            x[0].classList.add("foldCarousel");
        }
        else {
            x[0].classList.remove("foldCarousel");
            x[0].classList.add("pullCarousel");
        }
    });

    $(document).on("click", ".pullFoldCarousel_Text", function() {
        var x = document.getElementsByClassName("products_container");
        if (x[0].classList.contains("pullCarousel")){
            x[0].classList.remove("pullCarousel");
            x[0].classList.add("foldCarousel");
        }
        else {
            x[0].classList.remove("foldCarousel");
            x[0].classList.add("pullCarousel");
        }
    });

//  These fade in and out functions will be re-done into one function in the future
    var ft_container = document.getElementsByClassName("gtwb-features-container");
    ft_container[0].classList.toggle("gtwb-features-container-hide");
    var btn1 = $("div.gtwb-ft1-btn");
    var popup1 = $("div.gtwb-ft1-popup");
    var btn2 = $("div.gtwb-ft2-btn");
    var popup2 = $("div.gtwb-ft2-popup");
    var btn3 = $("div.gtwb-ft3-btn");
    var popup3 = $("div.gtwb-ft3-popup");
    var btn4 = $("div.gtwb-ft4-btn");
    var popup4 = $("div.gtwb-ft4-popup");
    var btn5 = $("div.gtwb-ft5-btn");
    var popup5 = $("div.gtwb-ft5-popup");
    var btn6 = $("div.gtwb-ft6-btn");
    var popup6 = $("div.gtwb-ft6-popup");

    btn1.mouseover( function() {
        popup1.fadeIn(350);
    });
    btn1.mouseout( function() {
        popup1.fadeOut(350);
    });

    btn2.mouseover( function() {
        popup2.fadeIn(350);
    });
    btn2.mouseout( function() {
        popup2.fadeOut(350);
    });

    btn3.mouseover( function() {
        popup3.fadeIn(350);
    });
    btn3.mouseout( function() {
        popup3.fadeOut(350);
    });

    btn4.mouseover( function() {
        popup4.fadeIn(350);
    });
    btn4.mouseout( function() {
        popup4.fadeOut(350);
    });

    btn5.mouseover( function() {
        popup5.fadeIn(350);
    });
    btn5.mouseout( function() {
        popup5.fadeOut(350);
    });

    btn6.mouseover( function() {
        popup6.fadeIn(350);
    });
    btn6.mouseout( function() {
        popup6.fadeOut(350);
    });
});

