# GTRobotWeb

###17 May 2019 Progress:

#### Frontend API used:
- Maps JavaScript API (Requires API key)
    - Used inside "register.html" and "account_details.html"
    - Planned to be used in "checkout.html"

####Completed Webpage UI:
- homepage.html
- artificial_intelligence.html
- news.html
- about.html
- Account Pages
    - login.html
    - register.html
    - account_details.html
    
####WIP Webpage UI:
- robots.html
    - GT WonderBoy
    
####Uncompleted Webpage UI:
- Robots
    - GT GoBot
    - GT Assistar
- News
    - Individual news articles
- Cart
    - cart.html
    - checkout.html
- Account Pages
    - orders.html
    - Product Manuals
        - Navigation Template
        - GT WonderBoy
        - GT Gobot
        - GT Assiststar
        
####To-do List:
- Convert into Flask Framework
- Replace images with provided by marketing
- Finish WIP
- Finish Uncompleted