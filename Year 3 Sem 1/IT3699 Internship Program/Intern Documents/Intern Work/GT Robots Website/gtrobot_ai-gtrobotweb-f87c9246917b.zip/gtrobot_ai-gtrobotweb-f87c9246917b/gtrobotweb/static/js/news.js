/* JS Document */

/******************************

[Table of Contents]

1. Vars and Inits
2. Set Header And Footer
3. Init Menu
4. Init Isotope
5. News Paging


******************************/

$(document).ready(function()
{
	"use strict";

	/* 

	1. Vars and Inits

	*/

	var header = $('.header');
	var footer_overlay = $('.footer_overlay');
	var footer = $('.footer');
	var hambActive = false;
	var menuActive = false;

	setHeader();
	setFooter();

	$(window).on('resize', function()
	{
		setHeader();
		setFooter();
	});

	$(document).on('scroll', function()
	{
		setHeader();
		setFooter();
	});

	initMenu();
	initIsotope();

	/* 

	2. Set Header And Footer

	*/

	function setHeader()
	{
		if($(window).scrollTop() > 100)
		{
			header.addClass('scrolled');
		}
		else
		{
			header.removeClass('scrolled');
		}
	}
	function setFooter()
	{
		if($(window).scrollTop() > 100)
		{
			footer_overlay.addClass('footer_overlayClass2');
			footer_overlay.removeClass('footer_overlayClass1');

			footer.addClass('footerClass2');
			footer.removeClass('footerClass1');
		}
		else
		{
			footer_overlay.addClass('footer_overlayClass1');
			footer_overlay.removeClass('footer_overlayClass2');

			footer.addClass('footerClass1');
			footer.removeClass('footerClass2');
		}
	}

	/*

	3. Init Menu

	*/

	function initMenu()
	{
		if($('.hamburger').length)
		{
			var hamb = $('.hamburger');

			hamb.on('click', function(event)
			{
				event.stopPropagation();

				if(!menuActive)
				{
					openMenu();
					
					$(document).one('click', function cls(e)
					{
						if($(e.target).hasClass('menu_mm'))
						{
							$(document).one('click', cls);
						}
						else
						{
							closeMenu();
						}
					});
				}
				else
				{
					$('.menu').removeClass('active');
					menuActive = false;
				}
			});

			//Handle page menu
			if($('.page_menu_item').length)
			{
				var items = $('.page_menu_item');
				items.each(function()
				{
					var item = $(this);

					item.on('click', function(evt)
					{
						if(item.hasClass('has-children'))
						{
							evt.preventDefault();
							evt.stopPropagation();
							var subItem = item.find('> ul');
                            var titleItem = item.find('> a');
						    if(subItem.hasClass('active'))
						    {
						    	subItem.toggleClass('active');
								TweenMax.to(subItem, 0.3, {height:0});

							    item.toggleClass('active');
                                titleItem.toggleClass('active');
						    }
						    else
						    {
						    	subItem.toggleClass('active');
						    	TweenMax.set(subItem, {height:"auto"});
								TweenMax.from(subItem, 0.3, {height:0});

							    item.toggleClass('active');
                                titleItem.toggleClass('active');
						    }
						}
						else
						{
							evt.stopPropagation();
						}
					});
				});
			}
		}
	}

	function openMenu()
	{
		var fs = $('.menu');
		fs.addClass('active');
		hambActive = true;
		menuActive = true;
	}

	function closeMenu()
	{
		var fs = $('.menu');
		fs.removeClass('active');
		hambActive = false;
		menuActive = false;
	}

	/*

	4. Init Isotope

	*/

	function initIsotope()
	{
		if($('.news_grid').length)
		{
			var grid = $('.news_grid').isotope({
				itemSelector: '.news',
				layoutMode: 'fitRows',
				fitRows:
				{
					gutter: 30
				}
	        });
		}
	}

})

	/*

	5. News Paging

	*/

    var current_page = 1;
    var records_per_page = 12;

    var records_in_row = {
        width_of_thisWindow: {
            max: 6,
            w1600: 5,
            w1280: 4,
            w991: 2,
            w575: 1
        }
    };

    var row_height = {
        width_of_thisWindow: {
            max: 491 + 59,
            w2500: 486 + 59,    w2400: 477 + 59,    w2300: 468 + 59,    w2200: 459 + 59,
            w2100: 450 + 59,    w2000: 441 + 59,

            w1900: 433 + 59,    w1800: 424 + 59,    w1700: 415 + 59,    w1600: 434 + 59,
            w1500: 424 + 59,    w1400: 414 + 59,    w1300: 403 + 59,    w1280: 436 + 59,
            w1200: 425 + 59,    w1100: 412 + 59,    w1000: 399 + 59,

            w991: 535 + 59,     w990: 534 + 59,     w980: 531 + 59,     w970: 529 + 59,
            w960: 526 + 59,     w950: 523 + 59,     w940: 520 + 59,     w930: 518 + 59,
            w920: 515 + 59,     w910: 513 + 59,     w900: 510 + 59,

            w890: 507 + 59,     w880: 505 + 59,     w870: 502 + 59,     w860: 499 + 59,
            w850: 497 + 59,     w840: 494 + 59,     w830: 491 + 59,     w820: 489 + 59,
            w810: 486 + 59,     w800: 483 + 59,

            w790: 481 + 59,     w780: 478 + 59,     w770: 475 + 59,     w760: 473 + 59,
            w750: 470 + 59,     w740: 467 + 59,     w730: 465 + 59,     w720: 462 + 59,
            w710: 459 + 59,     w700: 457 + 59,

            w690: 454 + 59,     w680: 451 + 59,     w670: 449 + 59,     w660: 446 + 59,
            w650: 443 + 59,     w640: 441 + 59,     w630: 438 + 59,     w620: 435 + 59,
            w610: 433 + 59,     w600: 430 + 59,

            w575: 586 + 59,     w570: 583 + 58,     w560: 578 + 58,     w550: 573 + 58,
            w540: 567 + 58,     w530: 562 + 58,     w520: 557 + 58,     w510: 551 + 58,
            w500: 546 + 59,

            w490: 541 + 59,     w480: 535 + 59,     w470: 530 + 59,     w460: 525 + 59,
            w450: 519 + 59,     w440: 514 + 59,     w430: 509 + 59,     w420: 503 + 59,
            w410: 498 + 59,     w400: 493 + 59,

            w390: 487 + 59,     w380: 482 + 59,     w370: 477 + 59,     w360: 471 + 59,
            w350: 466 + 59,     w340: 461 + 59,     w330: 455 + 59,     w320: 450 + 59,
            w310: 445 + 59,     w300: 439 + 59,

            w290: 434 + 59,     w280: 429 + 59,     w270: 423 + 59,     w260: 418 + 59,
            w250: 413 + 59
        }
    };

    var objJson = get_dataSource();

    function bottom_topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }

    function prevPage()
    {
        if (current_page > 1) {
            current_page--;
            changePage(current_page);
        }
    }

    function nextPage()
    {
        if (current_page < numPages()) {
            current_page++;
            changePage(current_page);
        }
    }

    function changePage(page)
    {
        var records_in_page = 0;
        var rows_in_page = 0;

        var btn_next = document.getElementsByClassName("btn_next");
        var btn_prev = document.getElementsByClassName("btn_prev");
        var page_span = document.getElementsByClassName("page");

        var news_grid = document.getElementsByClassName("news_grid")[0];
        var news = document.getElementsByClassName("news");

        var month = document.getElementsByClassName("month");
        var day = document.getElementsByClassName("day");
        var year = document.getElementsByClassName("year");

        var news_image_insertHere = document.getElementsByClassName("news_image_insertHere");
        var news_title_insertHere = document.getElementsByClassName("news_title_insertHere");
        var news_description_insertHere = document.getElementsByClassName("news_description_insertHere");
        var description;

        // Validate page
        if (page < 1) page = 1;
        if (page > numPages()) page = numPages();

        var i, c, n, x;
        for (c = 0; c < 12; c++)
            news[c].style.display = "none";

        // Displays the correct number of news articles
        for (i = (page-1) * records_per_page, c = 0; i < (page * records_per_page) && i < objJson.length; i++, c++) {
            records_in_page++;
            news[c].style.display = "block";
            
            month[c].innerHTML = objJson[i].date.month;
            day[c].innerHTML = objJson[i].date.day;
            year[c].innerHTML = objJson[i].date.year;

            news_image_insertHere[c].src = objJson[i].imageUrl;
            news_title_insertHere[c].innerHTML = objJson[i].title;

            description = objJson[i].description.line[0];
            for (n = 1; n <100; n++){
                addDescription = objJson[i].description.line[n];
                if (addDescription)
                    description += addDescription;
                else
                    break;
            }
            news_description_insertHere[c].innerHTML = description;
        }

        // Set-up to refresh height of .news_grid
        records_in_row.records = get_numRecords(records_in_row);
        row_height.height = get_rowHeight_height(row_height);
        rows_in_page = Math.ceil(records_in_page / records_in_row.records);   // Divide Round Up

        // Refreshes the height of the .news_grid based on window width.
        news_grid.style.height = row_height.height * rows_in_page + "px";

        page_span[0].innerHTML = page + "/" + numPages();
        page_span[1].innerHTML = page + "/" + numPages();

        if (page == 1) {
            btn_prev[0].style.visibility = "hidden";
            btn_prev[1].style.visibility = "hidden";
        } else {
            btn_prev[0].style.visibility = "visible";
            btn_prev[1].style.visibility = "visible";
        }

        if (page == numPages()) {
            btn_next[0].style.visibility = "hidden";
            btn_next[1].style.visibility = "hidden";
        } else {
            btn_next[0].style.visibility = "visible";
            btn_next[1].style.visibility = "visible";
        }
    }

    function numPages()
    {
        return Math.ceil(objJson.length / records_per_page);
    }

    window.onload = function() {
        changePage(1);
    }

    function get_numRecords(records_in_row)
    {
        var x = window.innerWidth;
        if (x <= 2560)
            records_in_row.records = records_in_row.width_of_thisWindow.max;
        if (x <= 1600)
            records_in_row.records = records_in_row.width_of_thisWindow.w1600;
        if (x <= 1280)
            records_in_row.records = records_in_row.width_of_thisWindow.w1280;
        if (x <= 991)
            records_in_row.records = records_in_row.width_of_thisWindow.w991;
        if (x <= 575)
            records_in_row.records = records_in_row.width_of_thisWindow.w575;
        return records_in_row.records;
    }

     function get_rowHeight_height(row_height)
    {
        var x = window.innerWidth;
        if (x <= 2560)
            row_height.height = row_height.width_of_thisWindow.max;
        if (x <= 2500)
            row_height.height = row_height.width_of_thisWindow.w2500;
        if (x <= 2400)
            row_height.height = row_height.width_of_thisWindow.w2400;
        if (x <= 2300)
            row_height.height = row_height.width_of_thisWindow.w2300;
        if (x <= 2200)
            row_height.height = row_height.width_of_thisWindow.w2200;
        if (x <= 2100)
            row_height.height = row_height.width_of_thisWindow.w2100;
        if (x <= 2000)
            row_height.height = row_height.width_of_thisWindow.w2000;


        if (x <= 1900)
            row_height.height = row_height.width_of_thisWindow.w1900;
        if (x <= 1800)
            row_height.height = row_height.width_of_thisWindow.w1800;
        if (x <= 1700)
            row_height.height = row_height.width_of_thisWindow.w1700;
        if (x <= 1600)
            row_height.height = row_height.width_of_thisWindow.w1600;
        if (x <= 1500)
            row_height.height = row_height.width_of_thisWindow.w1500;
        if (x <= 1400)
            row_height.height = row_height.width_of_thisWindow.w1400;
        if (x <= 1300)
            row_height.height = row_height.width_of_thisWindow.w1300;
        if (x <= 1280)
            row_height.height = row_height.width_of_thisWindow.w1280;
        if (x <= 1200)
            row_height.height = row_height.width_of_thisWindow.w1200;
        if (x <= 1100)
            row_height.height = row_height.width_of_thisWindow.w1100;
        if (x <= 1000)
            row_height.height = row_height.width_of_thisWindow.w1000;


        if (x <= 991)
            row_height.height = row_height.width_of_thisWindow.w991;
        if (x <= 990)
            row_height.height = row_height.width_of_thisWindow.w990;
        if (x <= 980)
            row_height.height = row_height.width_of_thisWindow.w980;
        if (x <= 970)
            row_height.height = row_height.width_of_thisWindow.w970;
        if (x <= 960)
            row_height.height = row_height.width_of_thisWindow.w960;
        if (x <= 950)
            row_height.height = row_height.width_of_thisWindow.w950;
        if (x <= 940)
            row_height.height = row_height.width_of_thisWindow.w940;
        if (x <= 930)
            row_height.height = row_height.width_of_thisWindow.w930;
        if (x <= 920)
            row_height.height = row_height.width_of_thisWindow.w920;
        if (x <= 910)
            row_height.height = row_height.width_of_thisWindow.w910;
        if (x <= 900)
            row_height.height = row_height.width_of_thisWindow.w900;

        if (x <= 890)
            row_height.height = row_height.width_of_thisWindow.w890;
        if (x <= 880)
            row_height.height = row_height.width_of_thisWindow.w880;
        if (x <= 870)
            row_height.height = row_height.width_of_thisWindow.w870;
        if (x <= 860)
            row_height.height = row_height.width_of_thisWindow.w860;
        if (x <= 850)
            row_height.height = row_height.width_of_thisWindow.w850;
        if (x <= 840)
            row_height.height = row_height.width_of_thisWindow.w840;
        if (x <= 830)
            row_height.height = row_height.width_of_thisWindow.w830;
        if (x <= 820)
            row_height.height = row_height.width_of_thisWindow.w820;
        if (x <= 810)
            row_height.height = row_height.width_of_thisWindow.w810;
        if (x <= 800)
            row_height.height = row_height.width_of_thisWindow.w800;

        if (x <= 790)
            row_height.height = row_height.width_of_thisWindow.w790;
        if (x <= 780)
            row_height.height = row_height.width_of_thisWindow.w780;
        if (x <= 770)
            row_height.height = row_height.width_of_thisWindow.w770;
        if (x <= 760)
            row_height.height = row_height.width_of_thisWindow.w760;
        if (x <= 750)
            row_height.height = row_height.width_of_thisWindow.w750;
        if (x <= 740)
            row_height.height = row_height.width_of_thisWindow.w740;
        if (x <= 730)
            row_height.height = row_height.width_of_thisWindow.w730;
        if (x <= 720)
            row_height.height = row_height.width_of_thisWindow.w720;
        if (x <= 710)
            row_height.height = row_height.width_of_thisWindow.w710;
        if (x <= 700)
            row_height.height = row_height.width_of_thisWindow.w700;

        if (x <= 690)
            row_height.height = row_height.width_of_thisWindow.w690;
        if (x <= 680)
            row_height.height = row_height.width_of_thisWindow.w680;
        if (x <= 670)
            row_height.height = row_height.width_of_thisWindow.w670;
        if (x <= 660)
            row_height.height = row_height.width_of_thisWindow.w660;
        if (x <= 650)
            row_height.height = row_height.width_of_thisWindow.w650;
        if (x <= 640)
            row_height.height = row_height.width_of_thisWindow.w640;
        if (x <= 630)
            row_height.height = row_height.width_of_thisWindow.w630;
        if (x <= 620)
            row_height.height = row_height.width_of_thisWindow.w620;
        if (x <= 610)
            row_height.height = row_height.width_of_thisWindow.w610;
        if (x <= 600)
            row_height.height = row_height.width_of_thisWindow.w600;

        if (x <= 575)
            row_height.height = row_height.width_of_thisWindow.w575;
        if (x <= 570)
            row_height.height = row_height.width_of_thisWindow.w570;
        if (x <= 560)
            row_height.height = row_height.width_of_thisWindow.w560;
        if (x <= 550)
            row_height.height = row_height.width_of_thisWindow.w550;
        if (x <= 540)
            row_height.height = row_height.width_of_thisWindow.w540;
        if (x <= 530)
            row_height.height = row_height.width_of_thisWindow.w530;
        if (x <= 520)
            row_height.height = row_height.width_of_thisWindow.w520;
        if (x <= 510)
            row_height.height = row_height.width_of_thisWindow.w510;
        if (x <= 500)
            row_height.height = row_height.width_of_thisWindow.w500;

        if (x <= 490)
            row_height.height = row_height.width_of_thisWindow.w490;
        if (x <= 480)
            row_height.height = row_height.width_of_thisWindow.w480;
        if (x <= 470)
            row_height.height = row_height.width_of_thisWindow.w470;
        if (x <= 460)
            row_height.height = row_height.width_of_thisWindow.w460;
        if (x <= 450)
            row_height.height = row_height.width_of_thisWindow.w450;
        if (x <= 440)
            row_height.height = row_height.width_of_thisWindow.w440;
        if (x <= 430)
            row_height.height = row_height.width_of_thisWindow.w430;
        if (x <= 420)
            row_height.height = row_height.width_of_thisWindow.w420;
        if (x <= 410)
            row_height.height = row_height.width_of_thisWindow.w410;
        if (x <= 400)
            row_height.height = row_height.width_of_thisWindow.w400;

        if (x <= 390)
            row_height.height = row_height.width_of_thisWindow.w390;
        if (x <= 380)
            row_height.height = row_height.width_of_thisWindow.w380;
        if (x <= 370)
            row_height.height = row_height.width_of_thisWindow.w370;
        if (x <= 360)
            row_height.height = row_height.width_of_thisWindow.w360;
        if (x <= 350)
            row_height.height = row_height.width_of_thisWindow.w350;
        if (x <= 340)
            row_height.height = row_height.width_of_thisWindow.w340;
        if (x <= 330)
            row_height.height = row_height.width_of_thisWindow.w330;
        if (x <= 320)
            row_height.height = row_height.width_of_thisWindow.w320;
        if (x <= 310)
            row_height.height = row_height.width_of_thisWindow.w310;
        if (x <= 300)
            row_height.height = row_height.width_of_thisWindow.w310;

        if (x <= 290)
            row_height.height = row_height.width_of_thisWindow.w290;
        if (x <= 280)
            row_height.height = row_height.width_of_thisWindow.w280;
        if (x <= 270)
            row_height.height = row_height.width_of_thisWindow.w270;
        if (x <= 260)
            row_height.height = row_height.width_of_thisWindow.w260;
        if (x <= 250)
            row_height.height = row_height.width_of_thisWindow.w250;

        return row_height.height;
    }

    function get_dataSource()
    {
        url = "../static/images/news/";
        var dataSource = [
            {
                date: {
                    month: "APR",
                    day: "01",
                    year: "2019"
                },
                imageUrl: url + "GTNews1.jpg",
                title: "GT Assiststar met with Senior Parliamentary Secretary",
                description: {
                    line: [
                        "Singapore, 29th March 2019 – Singapore’s first start assistant robot, GT Assiststar will be showcased at",
                        "Workforce Champion Series 10, managing a diverse workforce at Mediapolis today.",
                        "<br><br>",
                        "GT Assiststar is a star assistant that’s equipped with human-like functionalities and has the ability to",
                        "have great conversations. Paired with emotional and artificial intelligence, it is a multifunctional bot",
                        "that suits a wide array of services to facilitate SMART living. With inbuilt functionalities such as",
                        "automated tracking and voice navigation, it has the ability to move around designated area alleviating",
                        "one’s work life in today’s diverse workforce."
                    ]
                }
            },
            {
                date: {
                    month: "JUN",
                    day: "20",
                    year: "2018"
                },
                imageUrl: url + "GTNews2.jpg",
                title: "GT Wonder Boy at CES Asia Shanghai, China 2018",
                description: {
                    line: [
                        "SINGAPORE [JUNE 19, 2018] – GT Robot Technology was invited to exhibit the world’s most compact",
                        "social bot companion, the GT Wonder Boy at CES Asia, Shanghai, China. CES Asia is a premiere event",
                        "for tech innovation in Asia. Asia’s largest display of new cutting-edge technology over the course",
                        "of a three-day duration from 13-15th June. A showcase of next stage technological advancements was",
                        "showcased across robotics, artificial intelligence (AI), virtual and augmented reality, digital health",
                        "and more. CES Asia, is the place to be to fully experience the accelerating pace of technology globally.",
                        "GT Wonder Boy, the world’s most compact social bot companion was proud to represent Singapore robotics",
                        "in the area of artificial intelligence (AI) for the first time at CES Asia."
                    ]
                }
            },
            {
                date: {
                    month: "MAR",
                    day: "25",
                    year: "2018"
                },
                imageUrl: url + "GTNews3.jpg",
                title: "Singapore PM Lee Hsien Loong meets GT Wonder Boy at Kibies",
                description: {
                    line: [
                        "It was an honour for GT Wonder Boy to meet Prime Minister, Mr Lee Hsien Loong at Kibies Carnival again,",
                        "24th March 2018, a joint collaboration with People’s Association (PA) as part of Singapore’s initiative",
                        "a Smart Nation, especially after the recent meet at Chingay last month!"
                    ]
                }
            },
            {
                date: {
                    month: "FEB",
                    day: "07",
                    year: "2018"
                },
                imageUrl: url + "GTNews4.jpg",
                title: "GT Wonder Boy performs at the Press Conference of Chingay 2018",
                description: {
                    line: [
                        "GT Wonder Boy, Singapore’s first SMART social bot companion received an overwhelming response during the",
                        "press conference of Chingay Parade 2018 themed Cultural Funtasy held at the People’s Association Headquarters.",
                        "<br><br>",
                        "Representing the Smart Nation contingent, our homegrown, multilingual and compact bot performed alongside ballerinas,",
                        "longboarders, youth and senior tech enthusiasts in a sneak preview of what’s to come for Chingay 2018!",
                        "<br><br>",
                        "GT Wonder Boy was featured by countless media in Singapore such as The Straits Times, Lian He Wan Bao, Shin Ming,",
                        "TODAY, Channel 8, Channel NewsAsia, Vasantham & Capital 95.8FM."
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "07",
                    year: "2017"
                },
                imageUrl: url + "GTNews5.jpg",
                title: "GT Robot @ Alibaba Cloud Computing Conference 2017",
                description: {
                    line: [
                        "SINGAPORE [October 23, 2017] – GT Robot Technology was invited to present the world’s most compact and an",
                        "intelligent Singapore’s first social bot companion, The GT Wonder Boy at The Computing Conference hosted",
                        "by Alibaba Group, held in Hangzhou, China."
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "07",
                    year: "2017"
                },
                imageUrl: url + "GTNews6.jpg",
                title: "Would you ever accept a Robot be a Part of Your Family?",
                description: {
                    line: [
                        "Do Robots and human have the capability to bond and co-exist together?",
                        "<br><br>",
                        "Would you ever accept a robot into your family? Do robots and human have the capability to bond and co-exist together?",
                        "<br><br>",
                        "GT Robot Technology Pte. Ltd., a reputable international leader and pioneer in the robotics industry",
                        "invented GT Wonder Boy, the answer to these questions.",
                        "<br><br>",
                        "Being an amalgamation of cognitive and artificial intelligence (A.I.), the GT Wonder Boy is a SMART",
                        "companion for people of all ages from all different walks of lives.",
                        "<br><br>",
                        "GT Wonder Boy made a grand entrance at the 2017 World Robot Conference(WRC), held in Beijing.",
                        "The 2017 World Robot Conference is a prestigious international conference in China’s robotics industry.",
                        "Revolving around the world’s major areas of robotic research and application, the WRC 2017 offers a",
                        "space where academic thoughts can be exchanged at high levels and the latest display of achievements",
                        "demonstrated, promoting international collaboration and innovation."
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "06",
                    year: "2017"
                },
                imageUrl: url + "GTNews7.jpg",
                title: "GT Wonder boy 360 During World Robot Conference 2017",
                description: {
                    line: [
                        "SINGAPORE [4 September 2017] –GT Wonder Boy, an amalgamation of cognitive and Artificial Intelligence (A.I.),",
                        "is a SMART companion for people of all ages from all different walks of lives. A compact entertainer who can",
                        "sing, dance, photograph and shoot videos paired with various other built in components to alleviate one’s daily",
                        "life. With functionalities such as personal assistant, translator of up to 13 different languages, butler service,",
                        "photographer, and an interactive educator who can hold seamless two-way conversations.",
                        "<br<br>",
                        "Featured on 360° Panoramic Virtual Reality (VR), a platform that showcases stereoscopic panoramic capture rig to",
                        "transport audience on an incredible journey of virtual reality.",
                        "<br><br>",
                        "Click on the following url or scan the QR code below to immerse yourself in the virtual experience that happened",
                        "during World Robot Conference 2017, held in Beijing."
                    ]
                }
            },
            {
                date: {
                    month: "SEP",
                    day: "15",
                    year: "2017"
                },
                imageUrl: url + "GTNews8.jpg",
                title: "GT Wonder Boy @ Beijing World Robot Conference 2017",
                description: {
                    line: [
                        "SINGAPORE [September 15, 2017] – GT Robot Technology, an Innovative Robotics Company from Singapore proudly",
                        "presented its first ever compact SMART Singaporean Social Bot companion, GT Wonder Boy as an indication of",
                        "heightened technological growth and breakthrough at the prestigious international 2017 World Robot Conference",
                        "(WRC) held in Beijing.",
                        "<br><br>",
                        "GT Wonder Boy travelled 4457km across different continents to represent its nation, Singapore as an",
                        "extinguished exhibitor for the second time in the 2017 World Robot Conference, Beijing from 23rd – 27th Aug 2017.",
                        "<br><br>",
                        "GT Wonder Boy has been extremely well received at the exhibition, with thousands of international and local",
                        "guests pushing their way through the crowd to catch a glimpse of this compact SMART companion. Children were",
                        "extremely entertained with its ability to sing, dance, and take photos through voice command. They were also",
                        "taken aback at how quick it could solve mathematics questions within split seconds."
                    ]
                }
            },
            {
                date: {
                    month: "JUL",
                    day: "28",
                    year: "2017"
                },
                imageUrl: url + "GTNews9.jpg",
                title: "GT Wonder Boy open for Pre-order now, visit our website for details",
                description: {
                    line: [
                        "GT Wonder Boy the smart companion robot will be launched this year",
                        "<br><br>",
                        "GT Wonder Boy, Singapore’s first social companion robot is a multi-faceted personal",
                        "assistant and a SMART interactive educator that holds seamless, precise two-way conversations.",
                        "A humanoid multi-linguistic robot that speaks 13 different languages and translates precisely.",
                        "A hands-free photographer and a sing and dance companion that is based on voice command.",
                        "It will grow and evolve with you for life.  If you are looking for a talking and walking robot,",
                        "GT Wonder Boy is the smart solution to alleviate your daily life.",
                        "<br><br>",
                        "This smart companion will be launched this year. Due to countless international exposures,",
                        "we have received an overwhelming response for our pre-orders. We now open for pre-orders while",
                        "stocks last."
                    ]
                }
            },
            {
                date: {
                    month: "JUL",
                    day: "07",
                    year: "2017"
                },
                imageUrl: url + "GTNews10.jpg",
                title: "GT Wonder Boy and Dr. Paul Interviewed by Straits Time",
                description: {
                    line: [
                        "GT Wonder Boy Interviewed by Straits Times",
                        "<br><br>",
                        "GT Wonder Boy interviewed by The Straits Times, It’s Singapore’s very",
                        "own SMART robotic companion. Samantha Boh, Environment and Science reporter",
                        "interviewed both Dr Paul Zhang, Creator and Founder of GT Wonder Boy and GT",
                        "Ambassador, Emiliano Cyrus on the birth and inspiration behind this SMART",
                        "companion, GT Wonder Boy.taken aback at how quick it could solve mathematics",
                        "questions within split seconds."
                    ]
                }
            },
            {
                date: {
                    month: "JUL",
                    day: "06",
                    year: "2017"
                },
                imageUrl: url + "GTNews11.jpg",
                title: "GT Wonder Boy & GT Gobot meet Minister for Trade @ ICRA 2017",
                description: {
                    line: [
                        "GT Wonder Boy & GT Gobot at International Conference Robotics and",
                        "Automation (ICRA) 2017 Singapore",
                        "<br><br>",
                        "GT Wonder Boy, Singapore’s very own SMART robotic companion and GT Gobot,",
                        "an Intelligent Service Robot made their first appearance in Singapore at",
                        "the 2017 IEEE International Conference.",
                        "<br><br>",
                        "on Robotics and Automation (ICRA) today held at Sands Expo and Convention",
                        "Centre, Marina Bay Sands.",
                        "<br><br>",
                        "taken aback at how quick it could solve mathematics questions within split",
                        "seconds."
                    ]
                }
            },
            {
                date: {
                    month: "JUN",
                    day: "19",
                    year: "2017"
                },
                imageUrl: url + "GTNews12.jpg",
                title: "GT Wonder Boy performance at CCTV Spring Festival Gala 2017",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "JUN",
                    day: "06",
                    year: "2017"
                },
                imageUrl: url + "GTNews13.jpg",
                title: "GT Wonder Boy, Singapore's First Social Companion Robot",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "JUN",
                    day: "06",
                    year: "2017"
                },
                imageUrl: url + "GTNews14.jpg",
                title: "GT Gobot, Your Intelligent Service Robot and Smart Assistant",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "24",
                    year: "2016"
                },
                imageUrl: url + "GTNews15.jpg",
                title: "GT Wonder Boy Interviewed by Etown News @ Beijing",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "24",
                    year: "2016"
                },
                imageUrl: url + "GTNews16.jpg",
                title: "GT Robot come to World Robot Conference @ Beijing 2016",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "24",
                    year: "2016"
                },
                imageUrl: url + "GTNews17.jpg",
                title: "GT Wonder Boy on Dou Yu hi Bo for Live Broadcasting @2016 WRC",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "NOV",
                    day: "24",
                    year: "2016"
                },
                imageUrl: url + "GTNews18.jpg",
                title: "GT Wonder Boy on BBC was interviewed by Rico Hizon",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "OCT",
                    day: "17",
                    year: "2016"
                },
                imageUrl: url + "GTNews19.jpg",
                title: "Future of robotic, International Robotics Expers - | GT Robots",
                description: {
                    line: [
                        ""
                    ]
                }
            },
            {
                date: {
                    month: "OCT",
                    day: "17",
                    year: "2016"
                },
                imageUrl: url + "GTNews20.jpg",
                title: "GT Robot Invited to Participate Computing Conference 2016 1",
                description: {
                    line: [
                        ""
                    ]
                }
            }
        ]; // Can be obtained from another source, such as your objJson variable
        return dataSource;
    }