/* JS Document */

/******************************

[Table of Contents]

1. Vars and Inits
2. Set Header And Footer
3. Init Menu
4. Init Isotope


******************************/

$(document).ready(function()
{
	"use strict";

	/* 

	1. Vars and Inits

	*/

	var header = $('.header');
	var footer_overlay = $('.footer_overlay');
	var footer = $('.footer');
	var hambActive = false;
	var menuActive = false;

	setHeader();
	setFooter();

	$(window).on('resize', function()
	{
		setHeader();
		setFooter();
	});

	$(document).on('scroll', function()
	{
		setHeader();
		setFooter();
	});

	initMenu();
	initIsotope();

	/* 

	2. Set Header And Footer

	*/

	function setHeader()
	{
		if($(window).scrollTop() > 100)
		{
			header.addClass('scrolled');
		}
		else
		{
			header.removeClass('scrolled');
		}
	}
	function setFooter()
	{
		if($(window).scrollTop() > 100)
		{
			footer_overlay.addClass('footer_overlayClass2');
			footer_overlay.removeClass('footer_overlayClass1');

			footer.addClass('footerClass2');
			footer.removeClass('footerClass1');
		}
		else
		{
			footer_overlay.addClass('footer_overlayClass1');
			footer_overlay.removeClass('footer_overlayClass2');

			footer.addClass('footerClass1');
			footer.removeClass('footerClass2');
		}
	}

	/*

	3. Init Menu

	*/

	function initMenu()
	{
		if($('.hamburger').length)
		{
			var hamb = $('.hamburger');

			hamb.on('click', function(event)
			{
				event.stopPropagation();

				if(!menuActive)
				{
					openMenu();
					
					$(document).one('click', function cls(e)
					{
						if($(e.target).hasClass('menu_mm'))
						{
							$(document).one('click', cls);
						}
						else
						{
							closeMenu();
						}
					});
				}
				else
				{
					$('.menu').removeClass('active');
					menuActive = false;
				}
			});

			//Handle page menu
			if($('.page_menu_item').length)
			{
				var items = $('.page_menu_item');
				items.each(function()
				{
					var item = $(this);

					item.on('click', function(evt)
					{
						if(item.hasClass('has-children'))
						{
							evt.preventDefault();
							evt.stopPropagation();
							var subItem = item.find('> ul');
                            var titleItem = item.find('> a');
						    if(subItem.hasClass('active'))
						    {
						    	subItem.toggleClass('active');
								TweenMax.to(subItem, 0.3, {height:0});

							    item.toggleClass('active');
                                titleItem.toggleClass('active');
						    }
						    else
						    {
						    	subItem.toggleClass('active');
						    	TweenMax.set(subItem, {height:"auto"});
								TweenMax.from(subItem, 0.3, {height:0});

							    item.toggleClass('active');
                                titleItem.toggleClass('active');
						    }
						}
						else
						{
							evt.stopPropagation();
						}
					});
				});
			}
		}
	}

	function openMenu()
	{
		var fs = $('.menu');
		fs.addClass('active');
		hambActive = true;
		menuActive = true;
	}

	function closeMenu()
	{
		var fs = $('.menu');
		fs.removeClass('active');
		hambActive = false;
		menuActive = false;
	}

	/*

	4. Init Isotope

	*/

	function initIsotope()
	{
		if($('.descriptions_grid').length)
		{
			var grid = $('.descriptions_grid').isotope({
				itemSelector: '.description',
				layoutMode: 'fitRows',
				fitRows:
				{
					gutter: 30
				}
	        });
		}
	}

})
