# GT_ROBOT_CMS

##This repo will be used to maintain the code of all files related to the GT_ROBOT_CMS Project

#### References
https://realpython.com/python-web-applications/
https://cloud.google.com/appengine/docs/standard/python3/building-app/
http://flask.pocoo.org/docs/1.0/tutorial/

#### Installing dependencies
- Create lib folder under gt-robot-cms (mkdir lib)
- run pip install -r requirements.txt -t ./lib
- run pip install bson
- NOTE: BSON needs to be installed after pymongo to avoid conflicts with pymongo installation

#### Running the app Locally
Go to the gt-robot-cms folder in the terminal and enter python main.py

#### Hosting on cloud
Run command gcloud app deploy -v main 