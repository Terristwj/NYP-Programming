from flask import Flask, request, jsonify
import os,sys
sys.path.append('lib')
from instance.config import app_config
import auth, process

def create_app(configname):
    appA = Flask(__name__)
    appA.config.from_object(app_config[configname])
    appA.register_blueprint(auth.bp)
    appA.register_blueprint(process.bp)
    appA.add_url_rule('/', endpoint='index')
    return appA

config_name = "development"
app = create_app(config_name)

## connect to mongoDB
#mongo = MongoClient(app_config[config_name].MONGODB_URL)


if __name__ == '__main__':
    portF = os.getenv('FLASK_PORT')
    if portF is None:
        portF = 5005
    else:
        portF = int(portF)
    app.run(host='0.0.0.0', port=portF)