from datetime import timedelta

class Config(object):
    """
    Common configurations
    """

    # Put any configurations here that are common across all environments


class DevelopmentConfig(Config):
    """
    Development configurations
    """
    DEBUG = True
    MONGODB_URL = 'mongodb://gtdollar:GTD0llar2016@52.74.80.196:27017/gtdollarStage'
    ES_HOST = ['http://47.88.171.191:9200']
    SECRET_KEY = "development"
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)
    #MONGODB_COLLECTION = 'gtdollarStage'

class ProductionConfig(Config):
    """
    Production configurations
    """
    DEBUG = False
    ELASTICSEARCH_HOST = 'localhost:9200'
    ES_TARGET_HOST = 'http://47.88.154.51:9200'
    MONGODB_URL = 'mongodb://gtdollar:GTD0llar2016@52.74.80.196:27017/gtdollarStage'
    #MONGO_COLLECTION = 'gtdollarStage'


app_config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
}