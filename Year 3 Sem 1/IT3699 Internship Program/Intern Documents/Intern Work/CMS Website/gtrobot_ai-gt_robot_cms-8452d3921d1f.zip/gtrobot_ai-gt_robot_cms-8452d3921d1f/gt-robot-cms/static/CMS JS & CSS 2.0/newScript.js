
    function pullFoldSect(name, index) {
        var x = document.getElementsByClassName(name)[index];

        if (x.classList.contains("foldContent"))
        {
          x.classList.remove("foldContent");
          x.classList.add("pullContent");
        }
        else {
          x.classList.remove("pullContent");
          x.classList.add("foldContent");
        }
    }

    function checkbox(n) {
        var x = document.getElementsByClassName("myCB");
        var y = document.getElementById("checkAllBtn").checked;

        if (y == true)
          for (var i = 0; i < x.length; i++) {
            x[i].checked = true;
        }
        else
          for (var i = 0; i < x.length; i++) {
            x[i].checked = false;
        }
    }

    function accDropMouseOver() {
        document.getElementById("accDropButton").click();
    }

    function accDropPull() {
        var accMenu = document.getElementById("accDropMenu");

        if (accMenu.classList.contains("accDropFold")) {
            accMenu.classList.remove("accDropFold");
            accMenu.classList.add("accDropPull");
        }
        else {
            accMenu.classList.remove("accDropPull");
            accMenu.classList.add("accDropFold");
        }
    }

    function displayAccFields(type){
        var extraFieldsContainer = document.getElementById("extraTxtFields");
        var extraFieldsInput = document.getElementsByClassName("extraField");

        if (type == "General")
        {
            extraFieldsContainer.style.display = "block";

            var x;
            for (x = 0; x < extraFieldsInput.length; x++) {
                extraFieldsInput[x].disabled = false;
            }
        }
        else if (type == "Admin")
        {
            extraFieldsContainer.style.display = "none";

            var x;
            for (x = 0; x < extraFieldsInput.length; x++) {
                var attr = document.createAttribute("disabled");
                attr.value = "disabled"
                extraFieldsInput[x].setAttributeNode(attr);
            }
        }
    }

    function sessionData(type) {
        //Get Q&A
        var x = document.getElementsByClassName("formInput");
        var questions = [];

        for (var i = 1; i < x.length-1; i++) {
            var text = x[i].value;
            questions.push(text);
        }

        var intent = document.getElementById("intent").value;
        var answer = document.getElementById("answer").value;
        var videoid = document.getElementById("video_id").value;

        //Store session
        localStorage.setItem("intent", intent);
        localStorage.setItem("questions", JSON.stringify(questions));
        localStorage.setItem("answer", answer);
        localStorage.setItem("type", type);
    }

    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
      if (document.body.scrollTop > 828 || document.documentElement.scrollTop > 828) {
        document.getElementById("myBtn").style.bottom = "30px";
      } else {
        document.getElementById("myBtn").style.bottom = "-300px";
      }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }

    function retrieveQnA() {
        var questions = JSON.parse(localStorage.getItem("questions"));

        for (var i = 0; i < questions.length; i++) {
            if ( i == 0 )
                document.getElementById("question").innerHTML += " - " + questions[i];
            else {
                document.getElementById("question").innerHTML += "<br>" + " - " + questions[i];
            }
        }

        document.getElementById("intent").innerHTML = localStorage.getItem("intent");
        document.getElementById("answer").innerHTML = localStorage.getItem("answer");

        var vid_id = localStorage.getItem("videoid");
        if (vid_id != "None") {
          var vid_sect = [
            '<br><br>',
            '<label class="preview-Video" for="video">Video ID:</label>',
            '<br>',
            '<div class="preview-VideoInput" id="video">',
            vid_id,
            '</div>'
          ].join("\n");
          document.getElementById("preview-Video-Container").innerHTML = vid_sect;
        }

        var x = document.getElementById("preview-ResponseTitle");

        if (localStorage.getItem('type') == "create")
            document.getElementById("preview-ResponseTitle").innerHTML = "created";
        else if (localStorage.getItem('type') == "update")
            document.getElementById("preview-ResponseTitle").innerHTML = "updated";

        localStorage.removeItem('intent');
        localStorage.removeItem('questions');
        localStorage.removeItem('answer');
        localStorage.removeItem('type');
        localStorage.removeItem("videoid");
    }

    function adminPage_ClosePopUp() {
        var x = document.getElementsByClassName("adminPage-popup-background")[0];
        x.style.display = "none";
    }

    //-- Mobile --//
    function mobileInstructions(container_index, item_index) {
        var x = document.getElementsByClassName('rulesGTR-Description-Device-Containers')[container_index];
        var y = document.getElementsByClassName('rulesGTR-Description-Device-Containers')[container_index+1];
        var z = document.getElementsByClassName('rulesGTR-Description-Device-Containers')[container_index-1];

        var a = mobileInstructions_getRow(container_index, item_index);
        var b = document.getElementsByClassName('rulesGTR-Description-Device')[0];

        //--Back button--//
        if (item_index == 0 && container_index != 0)
        {
            x.style.cssText = "z-index:9;transform:translateX(200px);visibility:hidden;opacity:0;";
            z.style.cssText = "z-index:10;transform:translateX(0px);visibility:visible;opacity:1;";

            if (container_index == 1)
            {
                b.style.height = 48.25 * 12 + "px";
            }
            else if (container_index == 2)
            {
                count = document.getElementById("rulesGTR-backToSubTopic").getAttribute('data-subValue-count');
                b.style.height = 48.25 * ++count + "px";
            }
        }
        else
        {
            x.style.cssText = "z-index:9;transform:translateX(-200px);visibility:hidden;opacity:0;";
            y.style.cssText = "z-index:10;transform:translateX(0px);visibility:visible;opacity:1;";

            topic = a.getAttribute('data-value');
            if (container_index == 0)
            {
                mobileInstructions_resetSubTopic();
                count = a.getAttribute('data-subValue-count');
                mobileInstructions_getSubTopic(topic, count);
                b.style.height = 48.25 * ++count + "px";
            }
            else if (container_index == 1)
            {
                mobileInstructions_getDescription(topic);
                b.style.height = 48.25 * 12 + "px";
            }
        }
    }

    function mobileInstructions_getRow(container_index, item_index) {
        var row;

        if (container_index == 0)
        {
            row = document.getElementsByClassName('rulesGTR-Description-Title')[item_index];
        }
        else if (container_index == 1)
        {
            row = document.getElementsByClassName('rulesGTR-Description-SubTitle')[item_index-1];
        }
        return row;
    }

    function mobileInstructions_resetSubTopic() {
        var subTopic_Rows = document.getElementsByClassName('rulesGTR-Description-SubTitle');
        var row;

        for(i = 0; i<7; i++)
        {
            row = subTopic_Rows[i];
            row.setAttribute("data-value", "#");
            row.style.display = "none";
            document.getElementsByClassName("rulesGTR-Description-SubTitle-Title")[i].innerHTML = "";
        }
    }

    function mobileInstructions_getSubTopic(topic, count) {
        document.getElementById("rulesGTR-backToSubTopic").setAttribute("data-subValue-count", count);
        var subTopic_Rows = document.getElementsByClassName('rulesGTR-Description-SubTitle');
        var subTopics;
        var dataValues;

        if (topic === "Time")
        {
            subTopics = ["Set Alarm", "Countdown Timer", "Current Date", "Current Time", "Stopwatch", "Make Reminder", "Check Schedule"];
            dataValues = ["alarm", "timer", "date", "time", "stopwatch", "remind", "schedule"];
        }
        else if (topic === "Actions I")
        {
            subTopics = ["Wake GT Wonder Boy", "Beam", "Propose", "Play Sport", "Rock Paper Scissors", "Dance"];
            dataValues = ["wake", "beam", "propose", "sport", "RPS", "dance"];
        }
        else if (topic === "Actions II")
        {
            subTopics = ["Flip", "Push Up", "Stand Up", "Forward", "Hands Up", "Shake/Nod Head"];
            dataValues = ["flip", "pushup", "standup", "forward", "hands", "head"];
        }
        else if (topic === "Geography")
        {
            subTopics = ["Current Location", "Navigation", "Weather"];
            dataValues = ["location", "navigation", "weather"];
        }
        else if (topic === "Applications")
        {
            subTopics = ["Google Search", "Word Dictionary", "Today's News", "Correction"];
            dataValues = ["google", "dictionary", "news", "correction"];
        }
        else if (topic === "Phone")
        {
            subTopics = ["Send SMS", "Phone Call"];
            dataValues = ["sms", "call"];
        }
        else if (topic === "Conversations")
        {
            subTopics = ["GT WonderBoy Name", "Joke", "Poetry", "Rhymes", "Story", "Translate", "Silence"];
            dataValues = ["getName", "joke", "poetry", "rhymes", "story", "translate", "silence"];
        }
        else if (topic === "Small Talk")
        {
            subTopics = ["Introduction", "Owner", "Gender", "Age", "Origin", "Capability", "Converse"];
            dataValues = ["introduction", "owner", "gender", "age", "origin", "capability", "converse"];
        }
        else if (topic === "Math")
        {
            subTopics = ["Calculator", "Square Root"];
            dataValues = ["calculate", "sqRt"];
        }
        else if (topic === "Audio")
        {
            subTopics = ["Volume", "Music", "Voice Record"];
            dataValues = ["volume", "music", "voiceRcd"];
        }
        else if (topic === "Camera")
        {
            subTopics = ["Photo", "Video", "Video Play Demo", "Image Scan", "Face Scan"];
            dataValues = ["photo", "video", "videoPlay_Demo", "imgScan", "faceScan"];
        }
        else if (topic === "Settings")
        {
            subTopics = ["Set Language", "Voice Change", "Save GT WonderBoy Name", "Battery Check", "System Settings"];
            dataValues = ["language", "voice", "saveName", "battery", "settings"];
        }

        mobileInstructions_getSubTopic_Change(subTopic_Rows, subTopics, dataValues);
    }

    function mobileInstructions_getSubTopic_Change(subTopic_Rows, subTopics, dataValues) {
        for(i = 0; i<count; i++)
        {
            row = subTopic_Rows[i];
            row.setAttribute("data-value", dataValues[i]);
            row.style.display = "block";
            document.getElementsByClassName("rulesGTR-Description-SubTitle-Title")[i].innerHTML = subTopics[i];
        }
    }

    function mobileInstructions_getDescription(topic) {
        var y = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder")[0];
        y.style.display = "block";
        y.style.overflowY = "visible";

        var title1 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Title-Text-1")[0];
        var title2 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Title-Text-2")[0];
        var title3 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Title-Text-3")[0];
        var description1 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Description-1")[0];
        var description2 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Description-2")[0];
        var description3 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Description-3")[0];

        arrayInfo_TitleDescription = get_TitleDescription(topic);

        title1.innerHTML = arrayInfo_TitleDescription[0][0];
        description1.innerHTML = arrayInfo_TitleDescription[0][1];

        title2.innerHTML = arrayInfo_TitleDescription[1][0];
        description2.innerHTML = arrayInfo_TitleDescription[1][1];

        title3.innerHTML = arrayInfo_TitleDescription[2][0];
        description3.innerHTML = arrayInfo_TitleDescription[2][1];
    }


    //-- PC --//
    function PCInstructions(from_rulesGTRSideContent) {

        var x = document.getElementsByClassName("rulesGTR-SideContentDefault")[0];
        var y = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder")[1];
        var z = document.getElementsByClassName("rulesGTR-TopicsAvoid-TitleText-Right")[0];

        if (from_rulesGTRSideContent == 1)
        {
            z.style.cursor = "pointer";
            z.style.background = "black";
            z.style.color = "#eecf9a";
            z.style.border = "2px solid #eecf9a";
        }
        else
        {
            x.style.display = "block";
            y.style.display = "none";
            z.style.cursor = "default";
            z.style.background = "#eecf9a";
            z.style.color = "black";
            z.style.border = "2px solid #eecf9a";
        }
    }

    function rulesGTRMenuList(index) {
        var time = document.getElementById('rulesGTR-SideMenuContent-Time');
        var action1 = document.getElementById('rulesGTR-SideMenuContent-Actions1');
        var action2 = document.getElementById('rulesGTR-SideMenuContent-Actions2');
        var geography = document.getElementById('rulesGTR-SideMenuContent-Geography');
        var application = document.getElementById('rulesGTR-SideMenuContent-Applications');
        var phone = document.getElementById('rulesGTR-SideMenuContent-Phone');
        var conversation = document.getElementById('rulesGTR-SideMenuContent-Conversation');
        var smallTalk = document.getElementById('rulesGTR-SideMenuContent-SmallTalk');
        var math = document.getElementById('rulesGTR-SideMenuContent-Math');
        var audio = document.getElementById('rulesGTR-SideMenuContent-Audio');
        var camera = document.getElementById('rulesGTR-SideMenuContent-Camera');
        var settings = document.getElementById('rulesGTR-SideMenuContent-Settings');

        var functions = [time, action1, action2, geography, application, phone, conversation, smallTalk, math, audio, camera, settings];

        if (index == "time")
            rulesGTRMenuList_ChangeHeight(time, "rulesTime", functions);
        else if (index == "action1")
            rulesGTRMenuList_ChangeHeight(action1, "rulesActions1", functions);
        else if (index == "action2")
            rulesGTRMenuList_ChangeHeight(action2, "rulesActions2", functions);
        else if (index == "geography")
            rulesGTRMenuList_ChangeHeight(geography, "rulesGeography", functions);
        else if (index == "application")
            rulesGTRMenuList_ChangeHeight(application, "rulesApplications", functions);
        else if (index == "phone")
            rulesGTRMenuList_ChangeHeight(phone, "rulesPhone", functions);
        else if (index == "conversation")
            rulesGTRMenuList_ChangeHeight(conversation, "rulesConversation", functions);
        else if (index == "smallTalk")
            rulesGTRMenuList_ChangeHeight(smallTalk, "rulesSmallTalk", functions);
        else if (index == "math")
            rulesGTRMenuList_ChangeHeight(math, "rulesMath", functions);
        else if (index == "audio")
            rulesGTRMenuList_ChangeHeight(audio, "rulesAudio", functions);
        else if (index == "camera")
            rulesGTRMenuList_ChangeHeight(camera, "rulesCamera", functions);
        else if (index == "settings")
            rulesGTRMenuList_ChangeHeight(settings, "rulesSettings", functions);
    }

    function rulesGTRMenuList_ChangeHeight(topic, className, functions) {
        if (topic.style.height != "0px")
        {
            topic.style.height = "0px";
        }
        else {
            var y = document.getElementsByClassName(className);
            rulesGTRMenuListClose(functions);
            topic.style.height = 35 * y.length + "px";
        }
    }

    function rulesGTRMenuListClose(functions){
        for (i = 0; i < functions.length; i++) {
            functions[i].style.height = "0px";
        }
    }

    function rulesGTRSideContent(topic) {
        var x = document.getElementsByClassName("rulesGTR-SideContentDefault")[0];
        if (x.style.display != "none"){
            x.style.display="none";
            PCInstructions(1);
        }

        var y = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder")[1];
        y.style.display = "block";
        y.style.overflowY = "visible";

        var title1 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Title-Text-1")[1];
        var title2 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Title-Text-2")[1];
        var title3 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Title-Text-3")[1];
        var description1 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Description-1")[1];
        var description2 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Description-2")[1];
        var description3 = document.getElementsByClassName("rulesGTR-SideContentPlaceHolder-Description-3")[1];

        arrayInfo_TitleDescription = get_TitleDescription(topic);

        title1.innerHTML = arrayInfo_TitleDescription[0][0];
        description1.innerHTML = arrayInfo_TitleDescription[0][1];

        title2.innerHTML = arrayInfo_TitleDescription[1][0];
        description2.innerHTML = arrayInfo_TitleDescription[1][1];

        title3.innerHTML = arrayInfo_TitleDescription[2][0];
        description3.innerHTML = arrayInfo_TitleDescription[2][1];
    }

    //--General Control--//
    function rulesGTR_MasterControl() {
        mobileInstructions(container_index, item_index)
    }

    function get_TitleDescription(topic) {
        document.getElementsByClassName("rulesGTR-SideContentPlaceHolder")[0].style.height = "522px";
        document.getElementsByClassName("rulesGTR-SideContentPlaceHolder")[0].style.overflowY = "scroll";
        document.getElementsByClassName("rulesGTR-SideContentPlaceHolder")[1].style.overflowY = "scroll";

        var arrayInfo = []

        var title1;
        var description1;

        var title2;
        var description2;

        var title3;
        var description3;

        if (topic == "alarm")
        {
            title1 = "Set Alarm";
            description1 = "The &#34;Set Alarm&#34; operates like a alarm clock. By speaking to the GT Wonder Boy, you can set an alarm by saying &#34;Set alarm for @time @date&#34;. The time must be of a 12 hour clock.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;set alarm&#34;";

            title3 = "Examples";
            description3 = "&#34;Set alarm for 8pm today&#34;<br>&#34;Set alarm for 8am tomorrow&#34;<br>";
        }
        else if (topic == "timer")
        {
            title1 = "Countdown Timer";
            description1 = "The &#34;Countdown Timer&#34; operates by counting down a given time. By speaking to the GT Wonder Boy, you can set a timer by saying &#34;Set timer for @time&#34;. The time must be in hours/minutes/seconds.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;set timer&#34;";

            title3 = "Examples";
            description3 = "&#34;Set a timer for 1 minute&#34;<br>&#34;Set timer for 1 hour and 10 seconds&#34;<br>";
        }
        else if (topic == "date")
        {
            title1 = "Current Date";
            description1 = "The &#34;Current Date&#34; responds back with the date of today. By speaking to the GT Wonder Boy, you can get today's date by saying &#34;what's the date&#34;. Similar phrases are captured too.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;what's the date&#34;";

            title3 = "Examples";
            description3 = "&#34;What day is it&#34;<br>&#34;What is today's date&#34;<br>&#34;What's the date today&#34;<br>&#34;Do you know the date&#34;<br>&#34;Can I have the date today&#34;<br>";
        }
        else if (topic == "time")
        {
            title1 = "Current Time";
            description1 = "The &#34;Current Time&#34; responds back with the time now. By speaking to the GT Wonder Boy, you can get the time now by saying &#34;What's the time&#34;. Similar phrases are captured too.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;what's the time&#34;, &#34;Current time&#34;, &#34;Time now&#34;";

            title3 = "Examples";
            description3 = "&#34;What is the time&#34;<br>&#34;Can I have the time now&#34;<br>&#34;Do you know the time now&#34;<br>";
        }
        else if (topic == "stopwatch")
        {
            title1 = "Stopwatch";
            description1 = "The &#34;Stopwatch&#34; operates by setting a stopwatch feature. By speaking to the GT Wonder Boy, you can set a stopwatch by saying &#34;Set stopwatch&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;set stopwatch&#34;";

            title3 = "Examples";
            description3 = "&#34;Help me set a stopwatch&#34;<br>&#34;Set a stopwatch&#34;<br>";
        }
        else if (topic == "wake")
        {
            title1 = "Wake GT Wonder Boy";
            description1 = "The &#34;Wake GT Wonder Boy&#34; is an action command to wake the GT Wonder Boy verbally. By speaking to the GT Wonder Boy, you can wake it by saying &#34;GT Baby&#34;. The command only works if the GT Wonder Boy is asleep.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;GT Baby&#34;";

            title3 = "";
            description3 = "";
        }
        else if (topic == "beam")
        {
            title1 = "Beam";
            description1 = "The &#34;Beam&#34; is an action command to make GT Wonder Boy shoot a laser. By speaking to the GT Wonder Boy, you can say &#34;beam&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;beam&#34;, &#34;megabeam&#34;";

            title3 = "Examples";
            description3 = "&#34;Robot mega beam&#34;<br>&#34;Use mega beam&#34;<br>";
        }
        else if (topic == "propose")
        {
            title1 = "Propose";
            description1 = "The &#34;Propose&#34; is an action command to make GT Wonder Boy propose. By speaking to the GT Wonder Boy, you can say &#34;propose&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;propose&#34;";

            title3 = "Examples";
            description3 = "&#34;Can you propose&#34;<br>&#34;Wedding proposal&#34;<br>";
        }
        else if (topic == "sport")
        {
            title1 = "Play Sport";
            description1 = "The &#34;Play Sport&#34; is an action command to make GT Wonder Boy play a sport. By speaking to the GT Wonder Boy, you can say &#34;sport&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;sport&#34;";

            title3 = "Examples";
            description3 = "&#34;Can you do sports&#34;<br>&#34;Do you know any sports&#34;<br>&#34;Play football&#34;<br>";
        }
        else if (topic == "RPS")
        {
            title1 = "Rock Paper Scissors";
            description1 = "The &#34;Rock Paper Scissors&#34; allows GT Wonder Boy to play the game. By speaking to the GT Wonder Boy, you can start by saying &#34;Rock Paper Scissors&#34;. You can say it in any order.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;Rock Paper Scissors&#34; (In any order)";

            title3 = "";
            description3 = "";
        }
        else if (topic == "dance")
        {
            title1 = "Dance";
            description1 = "The &#34;Dance&#34; is an action command to make GT Wonder Boy perform a dance. By speaking to the GT Wonder Boy, you can get it to dance by saying &#34;@title dance&#34;. There is currently 5 available dances.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;dance&#34;";

            title3 = "Dances";
            description3 = "<b>Little Apple</b>: &#34;Little apple dance&#34;<br><b>Random Dance</b>: &#34;Random dance&#34;<br><b>Up Down</b>: &#34;Up And Down dance&#34;<br><b>Waltz</b>: &#34;Waltz dance&#34;, &#34;Wow dance&#34;<br><b>Wonder Boy Dance</b>: &#34;Show some moves&#34;, &#34;can you dance&#34;, &#34;dance&#34;";
        }
        else if (topic == "flip")
        {
            title1 = "Flip";
            description1 = "The &#34;Flip&#34; command allows GT Wonder Boy to perform a flip! By speaking to the GT Wonder Boy, say &#34;Flip!&#34;. Other sentencing variants exists too.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;flip&#34;";

            title3 = "Examples";
            description3 = "&#34;Go flip&#34;<br>&#34;Do a flip&#34;<br>&#34;Perform a flip&#34;<br>&#34;Can you do a flip&#34;<br>";
        }
        else if (topic == "pushup")
        {
            title1 = "Push Up";
            description1 = "The &#34;Push Up&#34; command makes GT Wonder Boy do push-ups. By speaking to the GT Wonder Boy, say &#34;push up&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;push up&#34;";

            title3 = "Examples";
            description3 = "&#34;Do a push up&#34;<br>&#34;Perform a push up&#34;<br>&#34;Push it up&#34;<br>";
        }
        else if (topic == "standup")
        {
            title1 = "Stand up";
            description1 = "The &#34;Stand Up&#34; command will instruct GT Wonder Boy to stand back up into its original position. By speaking to the GT Wonder Boy, you can say &#34;stand up&#34; to call this action. Note: It is advised to lay the GT Wonder Boy <b>FACE UP</b> before performing this action.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;stand up&#34;, &#34;stand&#34;";

            title3 = "Examples";
            description3 = "&#34;Please stand up&#34;<br>&#34;Stand up now&#34;<br>&#34;Perform Stand&#34;<br>";
        }
        else if (topic == "forward")
        {
            title1 = "Forward";
            description1 = "The &#34;Forward&#34; command will instruct GT WonderBoy to walk forward. By speaking to the GT Wonder Boy, you say &#34;walk&#34; for it to move forward. Note: Please ensure that there are no obstructions ahead of GT Wonder Boy before performing this action.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;forward&#34;, &#34;walk&#34;";

            title3 = "Examples";
            description3 = "&#34;Go forward&#34;<br>&#34;Walk forward&#34;<br>";
        }
        else if (topic == "hands")
        {
            title1 = "Hands Up";
            description1 = "The &#34;Hands Up&#34; allows GT Wonder Boy to lift its hands. By speaking to the GT Wonder Boy, you can say &#34;both hands up&#34; to lift both hands. You can also specify which hand by adding &#34;left&#34; or &#34;right&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;both hands up&#34;, &#34;left hand up&#34;, &#34;right hand up&#34;";

            title3 = "Examples";
            description3 = "&#34;Raise your left hand&#34;<br>&#34;Right hand up&#34;<br>&#34;Lift your both hands&#34;<br>";
        }
        else if (topic == "head")
        {
            title1 = "Shake/Nod Head";
            description1 = "The &#34;Shake/Nod Head&#34; is an action command that instructs GT Wonder Boy to either shake or nod its head. By speaking to the GT Wonder Boy, you can say &#34;shake&#34; or &#34;nod&#34; to perform either of these actions.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;nod&#34;, &#34;shake&#34;";

            title3 = "Examples";
            description3 = "&#34;Nod if you agree&#34;<br>&#34;Nod to disagree&#34;<br>&#34;Shake your head&#34;<br>&#34;Shake it&#34;<br>";
        }
        else if (topic == "location")
        {
            title1 = "Current Location";
            description1 = "Upon calling for the &#34;Current Location&#34;, the GT Wonder Boy will respond back with the name of the location. To call this dialogue, you can say &#34;current location&#34;. Similar phrases are captured too.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;current location&#34;, &#34;my location&#34;, &#34;where am I&#34;";

            title3 = "Examples";
            description3 = "&#34;What is my current location&#34;<br>&#34;Do you know where are we&#34;<br>&#34;Tell me my current location&#34;<br>&#34;What is my location&#34;<br>&#34;Where am I now&#34;";
        }
        else if (topic == "navigation")
        {
            title1 = "Navigation";
            description1 = "Upon calling for &#34;Navigation&#34;, the GT Wonder Boy will respond back with the directions to the destination. To call this dialogue, you can say &#34;navigate to @place&#34;. Note: The GT Wonder Boy only knows of certain places.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;how to go&#34;, &#34;navigate to&#34;, &#34;go to&#34;";

            title3 = "Examples";
            description3 = "&#34;How to go to the airport&#34;<br>&#34;Navigate me to GT Dollar&#34;<br>&#34;Please navigate to Jurong Bird Park&#34;<br>&#34;I want to go to Aperia Mall&#34;<br>";
        }
        else if (topic == "weather")
        {
            title1 = "Weather";
            description1 = "The &#34;Weather&#34; dialogue can be separated into 4 parts. They include the <b>weather</b>, <b>temperature</b>, <b>forecast</b>, and <b>activity suggestions</b>.";
            description1 +="<br><br>";
            description1 +="The <b>weather</b> dialogue will reply back with the weather of a given location. It can be called by saying &#34;weather @location&#34;.";
            description1 +="<br><br>";
            description1 +="The <b>temperature</b> dialogue will reply back the temperature of a given location. It can be called by saying &#34;temperature in @location&#34;. The result can be replied back in Kelvin, Celsius, Fahrenheit, and Rankine. The dialogue also accepts descriptions such as &#34cold&#34, &#34warm&#34, and &#34hot&#34.";
            description1 +="<br><br>";
            description1 +="The <b>forecast</b> dialogue will reply back the forecast of a given location and date. It can be called by saying &#34;weather in @location for @date&#34;. This dialogue also accepts forecast of temperatures.";
            description1 +="<br><br>";
            description1 +="The <b>activity suggestions</b> dialogue will reply back suggestions on an activity at that moment. It can be called by saying &#34;should I go @activity&#34;. This dialogue can also be forecast and accepts @location.";
            description1 +="<br><br>";
            description1 +="Note: The <b>weather</b> dialogue also accepts <b>weather conditions</b> such as &#34;rain&#34;, &#34;snow&#34;, &#34;foggy&#34;, &#34;storm&#34;, etc.";

            title2 = "Key Words/Phrases";
            description2 = "<b>Weather</b>:<br>";
            description2 +="&#34;weather&#34;, &#34;weather @location&#34;, &#34;weather report @location&#34;, &#34;weather today&#34;, &#34;Is it @condition&#34;, &#34;Is it going to @condition&#34;";
            description2 +="<br><br>";
            description2 +="<b>Temperature</b>:<br>";
            description2 +="&#34;temperature in @location&#34;, &#34;is today a hot/cold day&#34;, &#34;how chilly in @location&#34;";
            description2 +="<br><br>";
            description2 +="<b>Forecast</b>:<br>";
            description2 +="&#34;weather/temperature @date&#34;, &#34;weather/temperature @day&#34;";
            description2 +="<br><br>";
            description2 +="<b>Activity Suggestions</b>:<br>";
            description2 +="&#34;Can I go @activity&#34;, &#34;Should I go @activity @location @date&#34;";

            title3 = "Examples";
            description3 = "<b>Weather</b>:<br>";
            description3 +="&#34;Weather in Singapore&#34;<br>&#34;Weather report in Malaysia&#34;<br>&#34;Is it going to rain&#34;";
            description3 +="<br><br>";
            description3 +="<b>Temperature</b>:<br>";
            description3 +="&#34;Today's temperature&#34;<br>&#34;Temperature in Bangkok&#34;<br>&#34;Is today a hot day&#34;";
            description3 +="<br><br>";
            description3 +="<b>Forecast</b>:<br>";
            description3 +="&#34;Weather of 30 March&#34;<br>&#34;Weather of this Friday&#34;<br>&#34;Weather in Singapore in 5 days&#34;<br>&#34;Temperature in Singapore next Monday&#34;<br>&#34;Is it going to be cold on July 22 in japan&#34;";
            description3 +="<br><br>";
            description3 +="<b>Activity Suggestions</b>:<br>";
            description3 +="&#34;Can I go kayaking in Singapore tomorrow&#34;<br>&#34;Should I go jogging this evening&#34;<br>&#34;Is hiking a good idea right now&#34;<br>";
            description3 +="<br>";
        }
        else if (topic == "google")
        {
            title1 = "Google Search";
            description1 = "By using &#34;Google Search&#34;, GT Wonder Boy will use its inbuilt API feature to recite from Google. By speaking to the GT Wonder Boy, it will trigger when saying keywords like &#34;search&#34;.";
            description1 += "<br><br>Note: Even without this keywords, GT Wonder Boy may still call Google as it is a fallback intent when it does not recognise your question.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;search&#34;, &#34;where is&#34;, &#34;who is&#34;, &#34;what is&#34;";

            title3 = "Examples";
            description3 = "&#34;Search robots&#34;<br>&#34;Where is GT Robots&#34;<br>&#34;Who is Lee Kuan Yew&#34;<br>&#34;What is artificial intelligence&#34;<br>";
        }
        else if (topic == "dictionary")
        {
            title1 = "Word Dictionary";
            description1 = "The &#34;Word Dictionary&#34; application will enable GT Wonder Boy respond back with the definition of the word.";

            title2 = "Key Words/Phrases";
            description2 = "";

            title3 = "Examples";
            description3 = "";
        }
        else if (topic == "news")
        {
            title1 = "Today's News";
            description1 = "The &#34;Today's News&#34; application gets the latest news. Just say a sentence with  &#34;news&#34; to use it.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;latest news&#34;, &#34;news today&#34;";

            title3 = "Examples";
            description3 = "&#34;Any news today&#34;<br>&#34;Read some news for me&#34;<br>&#34;The latest news&#34;<br>";
        }
        else if (topic == "remind")
        {
            title1 = "Make Reminder";
            description1 = "The &#34;Make Reminder&#34; application will make sure of GT Wonder Boy reminding you of your plans. By speaking to the GT Wonder Boy, say &#34;remind me&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;remind me @event @date @time&#34;";

            title3 = "Examples";
            description3 = "&#34;Remind me meeting tomorrow 8am&#34;<br>&#34;Remind me to watch movie tomorrow morning at 8pm&#34;<br>";
        }
        else if (topic == "schedule")
        {
            title1 = "Check Schedule";
            description1 = "&#34;Check Schedule&#34; checks for any plans made for that day. Speak to the GT Wonder Boy and say &#34;schedule @date&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;schedule @date&#34;";

            title3 = "Examples";
            description3 = "&#34;Check the schedule tomorrow&#34;<br>&#34;Help me check the schedule today&#34;<br>";
        }
        else if (topic == "help")
        {
            title1 = "Help";
            description1 = "The &#34;Help&#34; signals GT Wonder Boy for trouble. Saying &#34;help&#34; will trigger this intent. Other alternatives can be captured as well.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;need a hand&#34;, &#34;help&#34;, &#34;assistance&#34;, &#34;SOS&#34;";

            title3 = "Examples";
            description3 = "&#34;I need you to help me&#34;<br>&#34;Help me with a problem&#34;<br>&#34;I need some help&#34;<br>&#34;Assist me&#34;<br>&#34;Can you help me with that&#34;<br>&#34;I need you right now&#34;";
        }
        else if (topic == "correction")
        {
            title1 = "Correction";
            description1 = "The &#34;Correction&#34; enables users to <b>modify</b> their last answer or <b>cancel</b> the modification. By speaking to the GT Wonder Boy, you can <b>modify</b> by saying &#34;modify&#34; and <b>cancel</b> by saying &#34;cancel&#34.";

            title2 = "Key Words/Phrases";
            description2 = "<b>Modify</b>: ";
            description2 += "&#34;modify answer&#34;, &#34;correct answer&#34;";
            description2 += "<br>";
            description2 += "<b>Cancel</b>: ";
            description2 += "&#34;cancel corrections&#34;, &#34;undo correction&#34;";

            title3 = "Examples";
            description3 = "<b>Modify</b>:<br> ";
            description3 += "&#34;Modify the last answer&#34;<br>&#34;Correct the answer&#34;<br>";
            description3 += "<br> ";
            description3 += "<b>Cancel</b>:<br> ";
            description3 += "&#34;Cancel all corrections&#34;";
        }
        else if (topic == "sms")
        {
            title1 = "Send SMS";
            description1 = "The &#34;Send SMS&#34; instructs GT Wonder Boy to send a SMS to a phone number. To use this phone function, say &#34;text @number @message&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;text @number, @message&#34;, &#34;message @number, @message&#34;";

            title3 = "Examples";
            description3 = "&#34;Text Mary saying that I am on the way&#34;<br>&#34;Send a message to 98766334 thanks for accepting&#34;<br>";
        }
        else if (topic == "call")
        {
            title1 = "Phone Call";
            description1 = "The &#34;Phone Call&#34; instructs GT Wonder Boy to call a phone number. To use this phone function, say &#34;call @contact&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;call @contact&#34;";

            title3 = "Examples";
            description3 = "&#34;Call Lilith&#34;<br>&#34;Call 91357433&#34;<br>";
        }
        else if (topic == "getName")
        {
            title1 = "GT WonderBoy Name";
            description1 = "&#34;GT WonderBoy Name&#34; will return the name of the robot. Just say &#34;who are you&#34;. There are other variants as well.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;who are you&#34;, &#34;your name&#34;";

            title3 = "Examples";
            description3 = "&#34;What is your name&#34;<br>&#34;Tell me your name&#34;<br>&#34;I forgot your name&#34;<br>&#34;Do you have a name&#34;<br>";
        }
        else if (topic == "joke")
        {
            title1 = "Joke";
            description1 = "&#34;Joke&#34; will make GT Wonder Boy tell a joke. Just say &#34;joke&#34;. There are other variants as well.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;joke&#34;";

            title3 = "Examples";
            description3 = "&#34;Tell me a joke&#34;<br>&#34;Tell another joke&#34;<br>";
        }
        else if (topic == "poetry")
        {
            title1 = "Poetry";
            description1 = "&#34;Poetry&#34; will make GT Wonder Boy tell a poem. Just say &#34;poem&#34;. There are other variants as well.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;poem&#34;, &#34;poetry&#34;, &#34;recite a poem&#34;";

            title3 = "Examples";
            description3 = "&#34;Read a poem/poetry&#34;<br>&#34;Recite a poem/poetry&#34;<br>";
        }
        else if (topic == "rhymes")
        {
            title1 = "Rhymes";
            description1 = "&#34;Rhymes&#34; will make GT Wonder Boy tell a rhyme. Just say &#34;rhymes&#34;. There are other variants as well.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;rhymes&#34;, &#34;nursery rhymes&#34;";

            title3 = "Examples";
            description3 = "&#34;Tell me some rhymes&#34;<br>&#34;Do you know any rhymes&#34;<br>";
        }
        else if (topic == "story")
        {
            title1 = "Story";
            description1 = "&#34;Story&#34; will make GT Wonder Boy tell a story. just say &#34;story&#34;. There are other variants as well.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;story&#34;, &#34;fable&#34;";

            title3 = "Examples";
            description3 = "&#34;Tell a story&#34;<br>&#34;Can you tell a story&#34;<br>&#34;Tell a fable&#34;<br>";
        }
        else if (topic == "translate")
        {
            title1 = "Translate";
            description1 = "The &#34;Translate&#34; function in the GT Wonder Boy will translate your sentences into another language. By speaking to the GT Wonder Boy, say &#34;translation mode&#34; to access this feature. For the commands to translate, read the next sections of this page.";

            title2 = "Key Words/Phrases";
            description2 = "<b>Entry Modes</b>:<br>";
            description2 += "&#34;translation mode&#34;";
            description2 += "<br><br>";
            description2 += "<b>Translate Commands</b>:<br>";
            description2 += "&#34;translate @text to @foreign_language&#34;, <br>&#34;translate from @native_language to @foreign_language&#34;,<br>&#34;say it again&#34;, &#34;repeat it&#34;, &#34;come again&#34;";

            title3 = "Examples";
            description3 = "<b>Entry Modes</b>:<br>";
            description3 += "&#34;Enter translation mode&#34;<br>&#34;Start translation mode&#34;";
            description3 += "<br><br>";
            description3 += "<b>Translate Commands</b>:<br>";
            description3 += "&#34;Translate hello to French&#34;<br>&#34;Translate from rice from Word to Chinese&#34;<br>&#34;Say it again&#34;<br>&#34;Repeat it&#34;<br>&#34;Come again&#34;<br><br>";
        }
        else if (topic == "silence")
        {
            title1 = "Silence";
            description1 = "The &#34;Silence&#34; dialogue will force GT Wonder Boy to be silent. You can say &#34;silent&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;silent&#34;, &#34;quiet&#34;, &#34;go to rest&#34;";

            title3 = "Examples";
            description3 = "&#34;Keep silent&#34;<br>&#34;Silent mode please&#34;<br>&#34;Go to rest&#34;<br>&#34;Be quiet&#34;<br>&#34;Shut up&#34;<br>";
        }
        else if (topic == "introduction")
        {
            title1 = "Introduction";
            description1 = "&#34;Introduction&#34; will make GT Wonder Boy introduce itself. By speaking to the GT Wonder Boy, say &#34;self introduction&#34; for it to start.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;self introduction&#34;, &#34;introduce yourself&#34;";

            title3 = "Examples";
            description3 = "&#34;Please do a self introduction&#34;<br>&#34;Can you introduce yourself&#34;<br>&#34;Please introduce yourself&#34;<br>";
        }
        else if (topic == "owner")
        {
            title1 = "Owner";
            description1 = "The &#34;Owner&#34; dialogue will tell you the owner of GT Wonder Boy. Just say &#34;who is the boss&#34;. There are other variants as well";

            title2 = "Key Words/Phrases";
            description2 = "&#34;who is the boss&#34;, &#34;who is your owner/master/father/mother&#34;";

            title3 = "Examples";
            description3 = "&#34;Who is the boss&#34;<br>&#34;Who is your owner/master/father/mother&#34;<br>&#34;I should be your boss&#34;<br>&#34;Who do you work for&#34;<br>";
        }
        else if (topic == "gender")
        {
            title1 = "Gender";
            description1 = "The &#34;Gender&#34; dialogue will tell you the gender of GT Wonder Boy. By speaking to the GT Wonder Boy, say &#34;what's your gender&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;what's your gender&#34;, &#34;a boy or a girl&#34;";

            title3 = "Examples";
            description3 = "&#34;What is your gender&#34;<br>&#34;Are you a boy or a girl&#34;<br>";
        }
        else if (topic == "age")
        {
            title1 = "Age";
            description1 = "The &#34;Age&#34; dialogue will tell you the age of GT Wonder Boy. By speaking to the GT Wonder Boy, say &#34;your age&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;your age&#34;, &#34;how old are you&#34;";

            title3 = "Examples";
            description3 = "&#34;Tell me your age&#34;<br>&#34;What's your age&#34;<br>&#34;How old are you&#34;<br>&#34;How old is your platform&#34;<br>";
        }
        else if (topic == "origin")
        {
            title1 = "Origin";
            description1 = "The &#34;Origin&#34; dialogue will tell you the origin of GT Wonder Boy. To know its origin, say &#34;where are you from&#34;. There are other variants of this question structure.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;where are you from&#34;, &#34;your country&#34, &#34;your homeland&#34";

            title3 = "Examples";
            description3 = "&#34;Were you born here&#34;<br>&#34;Where are you from&#34;<br>&#34;Are you from far aways&#34;<br>&#34;What is your country&#34;<br>&#34;What's your homeland&#34;<br>";
        }
        else if (topic == "capability")
        {
            title1 = "Capability";
            description1 = "The &#34;Capability&#34; dialogue will tell you what the GT Wonder Boy offers. By speaking to the GT Wonder Boy, say &#34;what can you do&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;what can you do&#34;, &#34;capable of&#34;, &#34;your capability&#34;";

            title3 = "Examples";
            description3 = "&#34;What can you do&#34;<br>&#34;What is your capability&#34;<br>&#34;Show me your capability&#34;<br>&#34;What are you capable of&#34;<br>";
        }
        else if (topic == "converse")
        {
            title1 = "Converse";
            description1 = "The &#34;Converse&#34; dialogue is made up of many interactive responses provided by the GT Wonder Boy. This enables GT Wonder Boy to converse with a wider acceptance of speech. Dialogues include <b>greetings</b>, <b>feelings</b>, <b>praises</b>, <b>thank you</b>, and more. By speaking to the GT Wonder Boy, you can trigger these dialogues by speaking naturally to it. Read below for more details on the keywords. Other speech variants are available as well.";

            title2 = "Key Words/Phrases";
            description2 = "<b>Greetings</b>:<br>";
            description2 += "&#34;hello&#34;, &#34;hey&#34;, &#34;greetings&#34;, &#34;good day&#34;";
            description2 += "<br><br>";
            description2 += "<b>Feelings</b>:<br>";
            description2 += "&#34;how is it&#34;, &#34;how are you&#34;, &#34;how is your life&#34;";
            description2 += "<br><br>";
            description2 += "<b>Praises</b>:<br>";
            description2 += "&#34;amazing&#34;, &#34;splendid&#34;, &#34;great&#34;, &#34;cool&#34;, &#34;good for you&#34;, &#34;nice&#34;";
            description2 += "<br><br>";
            description2 += "<b>Thank you</b>:<br>";
            description2 += "&#34;you are wonderful&#34;, &#34;you rock&#34;, &#34;you're just super&#34;, &#34;thank you&#34;, &#34;cheers&#34;";
            description2 += "<br><br>";

            title3 = "Examples";
            description3 = "<b>Greetings</b>:<br>";
            description3 += "&#34;Hello again&#34;<br>&#34;Hey there&#34;<br>&#34;Long time no see&#34;<br>&#34;Good morning&#34;<br>&#34;Lovely day isn't it&#34;";
            description3 += "<br><br>";
            description3 += "<b>Feelings</b>:<br>";
            description3 += "&#34;Is everything okay&#34;<br>&#34;How was your day&#34;<br>&#34;How are you going&#34;<br>&#34;How have you been&#34;<br>&#34;How do you feel&#34;<br>&#34;What was your day like&#34;";
            description3 += "<br><br>";
            description3 += "<b>Praises</b>:<br>";
            description3 += "&#34;That's very nice of you&#34;<br>&#34;That's pretty good&#34;<br>&#34;This is fantastic&#34;<br>&#34;So sweet of you&#34;<br>&#34;Good for you&#34;<br>&#34;That's awesome thank you&#34;";
            description3 += "<br><br>";
            description3 += "<b>Thank you</b>:<br>";
            description3 += "&#34;You are really amazing&#34;<br>&#34;You are the best ever&#34;<br>&#34;You make my day&#34;<br>&#34;You are a pro&#34;<br>&#34;Very good thank you&#34;<br>&#34;Thank you my friend&#34;<br>&#34;Appreciate your help&#34;";
            description3 += "<br><br>";
        }
        else if (topic == "calculate")
        {
            title1 = "Calculator";
            description1 = "The &#34;Calculator&#34; function allows GT Wonder Boy to be used as a calculator. Just say a simple math equation to use this functionality. Example: &#34;@num plus @num&#34;. It currently has only plus, minus, multiply and divide.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;plus&#34;, &#34;minus&#34;, &#34;multiply&#34;, &#34;divide&#34;";

            title3 = "Examples";
            description3 = "&#34;How much does three multiply ten equals to&#34;<br>&#34;Ten divide two&#34;<br>";
        }
        else if (topic == "sqRt")
        {
            title1 = "Square Root";
            description1 = "The &#34;Square Root&#34; function specializes on giving the square root of a number. Just say &#34;square root of @num&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;Square root of @num&#34;";

            title3 = "Examples";
            description3 = "&#34;Square root of 16&#34;<br>&#34;Square root of twenty five&#34;<br>";
        }
        else if (topic == "volume")
        {
            title1 = "Volume";
            description1 = "&#34;Volume&#34; allows you to tune the responds volume of the GT Wonder Boy. Say &#34;volume up/down&#34;. No other variants.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;volume up/down&#34;";

            title3 = "Examples";
            description3 = "&#34;Volume up&#34;<br>&#34;Volume down&#34;<br>";
        }
        else if (topic == "music")
        {
            title1 = "Music";
            description1 = "The &#34;Music&#34; function will instruct GT Wonder Boy to play a music. By speaking to the GT Wonder Boy, you can instruct by saying &#34;play music&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;play music&#34;, &#34;play a tune&#34;, &#34;listen to music&#34;, &#34;sing&#34;";

            title3 = "Examples";
            description3 = "&#34;Play some music&#34;<br>&#34;I want to listen to music&#34;<br>&#34;Sing a song&#34;<br>&#34;What songs do you know&#34;<br>";
        }
        else if (topic == "voiceRcd")
        {
            title1 = "Voice Record";
            description1 = "The &#34;Voice Record&#34; will record your voice. By speaking to the GT Wonder Boy, say &#34;audio recording&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;audio recording&#34;";

            title3 = "Examples";
            description3 = "&#34;Turn on the recorder&#34;<br>&#34;Begin audio recording&#34;<br>&#34;Start recording&#34;<br>";
        }
        else if (topic == "photo")
        {
            title1 = "Photo";
            description1 = "&#34;Photo&#34; will instruct GT Wonder Boy to take a photo and even a selfie! To use the camera to take a photo, just say &#34;take a photo&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;take a photo&#34;, &#34;take a picture&#34;, &#34;take a selfie&#34;";

            title3 = "Examples";
            description3 = "&#34;Help me take a photo&#34;<br>&#34;Take a picture of me&#34;<br>&#34;Take a selfie&#34;<br>";
        }
        else if (topic == "video")
        {
            title1 = "Video";
            description1 = "&#34;Video&#34; will instruct GT Wonder Boy to <b>play</b> or <b>take</b> a video. To <b>play a video</b> say &#34;play @title&#34;, and to <b>take a video</b> say &#34;take a video &#34;.";
            description1 += "<br><br>Note: When playing a video, GT Wonder Boy will play videos that exist, such as a movie or a trailer. If GT Wonder Boy is unable to play a video, GT Wonder Boy does not have access to it or the video does not exist.";

            title2 = "Key Words/Phrases";
            description2 = "<b>Play Video</b>";
            description2 += "<br>";
            description2 += "&#34;play @title&#34;, &#34;play some video&#34;, &#34;I want to watch @title&#34;, &#34;play a video from @platform&#34;";
            description2 += "<br><br>";
            description2 += "<b>Take Video</b>";
            description2 += "<br>";
            description2 += "&#34;take a video&#34;";

            title3 = "Examples";
            description3 = "<b>Play Video</b>";
            description3 += "<br>";
            description3 += "&#34;Play Transformers&#34;<br>&#34;Can you show me a video&#34;<br>&#34;Play video clip by Madonna on Vimeo&#34;<br>&#34;Play music video for Love the Way you Lie&#34;<br>&#34;I want to watch Wannabe&#34;";
            description3 += "<br><br>";
            description3 += "<b>Take Video</b>";
            description3 += "<br>";
            description3 += "&#34;Take a video now&#34;<br>&#34;Record a video for me&#34;<br>&#34;Help me record a video&#34;<br><br>";
        }
        else if (topic == "videoPlay_Demo")
        {
            title1 = "Video Play Demo";
            description1 = "The &#34;Video Play Demo&#34; will instruct GT Wonder Boy to play a demo video of itself. By speaking to the GT Wonder Boy, say &#34;play video of yourself&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;play video of yourself&#34;";

            title3 = "Examples";
            description3 = "&#34;Play a video of GT Wonder Boy&#34;<br>&#34;Show me a video about GT Robot&#34;<br>&#34;Video of Wonder Boy&#34;<br>";
        }
        else if (topic == "imgScan")
        {
            title1 = "Image Scan";
            description1 = "With &#34;Image Scan&#34;, GT Wonder Boy is able to <b>identify</b> what it sees and able to <b>read</b> out words from scanning. By speaking to the GT Wonder Boy, you can use this by saying &#34;what do you see&#34; to <b>identify</b> an object, and &#34;read this sentence&#34; to <b>read</b> the words.";

            title2 = "Key Words/Phrases";
            description2 = "<b>Identify Object</b>";
            description2 += "<br>";
            description2 += "&#34;what do you see&#34;, &#34;what can you see&#34;";
            description2 += "<br><br>";
            description2 += "<b>Read</b>";
            description2 += "<br>";
            description2 += "&#34;read this sentence/words/texts&#34;, &#34;recognize from this&#34;";

            title3 = "Examples";
            description3 = "<b>Identify Object</b>";
            description3 += "<br>";
            description3 += "&#34;What do you see&#34;<br>&#34;What can you see&#34;<br>&#34;Can you see what is this&#34;";
            description3 += "<br><br>";
            description3 += "<b>Read</b>";
            description3 += "<br>";
            description3 += "&#34;Please read the text in this newspaper&#34;<br>&#34;What can you recognize from the picture&#34;<br>&#34;Please tell me what you can read from the picture&#34;<br><br>";
        }
        else if (topic == "faceScan")
        {
            title1 = "Face Scan";
            description1 = "With &#34;Face Scan&#34;, GT Wonder Boy is able to give a response after scanning your face. To make GT Wonder Boy scan your face, say &#34;who am I&#34;.";
            description1 += "<br><br>"
            description1 += "Besides the normal response, you can also make GT Wonder Boy say unique responses by saying &#34;Who is the coolest person in the world&#34;. Currently, there are limited unique expressions that GT Wonder Boy knows and it has to be specific. More will be added in the future!";

            title2 = "Key Words/Phrases";
            description2 = "&#34;who am I&#34;, &#34;look at me&#34;";

            title3 = "Examples";
            description3 = "<b>Default</b>";
            description3 += "<br>";
            description3 += "&#34;Do you know who I am&#34;<br>&#34;Look at me&#34;<br>&#34;Do you know me&#34;<br>";
            description3 += "<br>";
            description3 += "<b>Unique</b>";
            description3 += "<br>";
            description3 += "&#34;Who is the collest person in the world&#34;<br>&#34;Who is the cutest person in the world&#34;<br>&#34;Who is the best looking person in the world&#34;<br>";
            description3 += "<br>";
        }
        else if (topic == "language")
        {
            title1 = "Set Language";
            description1 = "&#34;Set Language&#34; will set the language of your GT Wonder Boy. By speaking to the GT Wonder Boy, you can set the language by saying &#34;talk in @language&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;talk in @language&#34;, &#34;speak @language&#34;, &#34;switch to @language&#34;, &#34;change language to @language&#34;, &#34;change your dialect&#34;, &#34;switch language&#34;";

            title3 = "Examples";
            description3 = "&#34;Let's talk in English&#34;<br>&#34;Please speak in Russian&#34;<br>&#34;What can I do so you talk Danish&#34;<br>&#34;I would like you to be able to speak Hindi&#34;<br>&#34;Speak Swedish from now on&#34;<br>&#34;Can we change the language&#34;<br>";
        }
        else if (topic == "voice")
        {
            title1 = "Voice Change";
            description1 = "&#34;Voice Change&#34; will change the gender of the voice of GT Wonder Boy. Just say &#34;voice to @gender&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;voice to @gender&#34;, &#34;change to @gender voice&#34;";

            title3 = "Examples";
            description3 = "&#34;Change voice to male&#34;<br>&#34;Can you change to female voice&#34;<br>";
        }
        else if (topic == "saveName")
        {
            title1 = "Save GT WonderBoy Name";
            description1 = "The &#34;Save GT WonderBoy Name&#34; will change the name of your GT Wonder Boy. Whenever GT Wonder Boy mentions its own name, it will use the given name instead. By speaking to the GT Wonder Boy, you can change its name by saying &#34;your name is @name&#34;. There is no other varients in sentencing.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;your name is @name&#34;";

            title3 = "Examples";
            description3 = "&#34;Your name is GT Boy&#34;<br>&#34;Your name is Wonder Woman&#34;<br>";
        }
        else if (topic == "battery")
        {
            title1 = "Battery Check";
            description1 = "The &#34;Battery Check&#34; function will get the current battery level of your GT Wonder Boy. Just say &#34;battery level&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;battery level&#34;, &#34;battery left&#34;, &#34;current battery&#34;";

            title3 = "Examples";
            description3 = "&#34;What is the current battery left&#34;<br>&#34;How much battery left&#34;<br>&#34;What is the battery level now&#34;<br>";
        }
        else if (topic == "settings")
        {
            title1 = "System Settings";
            description1 = "The &#34;System Settings&#34; will instruct GT Wonder Boy to display the system settings on its screen. Just say &#34;system setting&#34;.";

            title2 = "Key Words/Phrases";
            description2 = "&#34;system setting&#34;";

            title3 = "Examples";
            description3 = "&#34;open the system setting&#34;<br>&#34;open system setting&#34;<br>";
        }

        arrayInfo.push([title1, description1]);
        arrayInfo.push([title2, description2]);
        arrayInfo.push([title3, description3]);
        return arrayInfo;
    }

    function FAQType_change(className, otherClassName) {
        x = document.getElementsByClassName(className);
        y = document.getElementsByClassName(otherClassName);

        x[0].style.background = "#4d4d4d";
        y[0].style.background = "transparent";

        x[1].style.cssText = "background:#eecf9a !important;";
        x[1].style.cssText += "color:black !important;";
        y[1].style.cssText = "background:black !important;";
        y[1].style.cssText += "color:white !important;";

        a = document.getElementsByClassName("btnCheckContainerMaster")[0];
        b = document.getElementById("checkAllBtn");
        b1 = document.getElementsByClassName("selectAllContainer")[0];
        b2 = document.getElementsByClassName("selectCheckmark")[0];
        b3 = document.getElementsByClassName("checkbox_text")[0];
        c = document.getElementById("saveToWB2");

        if (a.classList.contains("saveWB_disappear") && className == "filterDraft"){
            a.classList.remove("saveWB_disappear");
            a.classList.add("saveWB_appear");

            b.disabled = false;
            b1.classList.remove("toggle_cursor");
            b2.classList.remove("toggle_cursor");
            b3.classList.remove("toggle_cursor");
            c.disabled = false;
        }
        else if (className == "filterSaved")
        {
            b.disabled = true;
            b1.classList.add("toggle_cursor");
            b2.classList.add("toggle_cursor");
            b3.classList.add("toggle_cursor");
            c.disabled = true;

            if (a.classList.contains("saveWB_appear")){
                b.checked=false;
                a.classList.remove("saveWB_appear");
                a.classList.add("saveWB_disappear");
            }
            else{
                a.classList.add("saveWB_disappear");
            }
        }
    }

    function updateUser_ClosePopUp() {
        var x = document.getElementsByClassName("updateUser-popup-background")[0];
        x.style.display = "none";
    }

    function userType_change(className, otherClassName){
        x = document.getElementsByClassName(className);
        y = document.getElementsByClassName(otherClassName);

        x[0].style.background = "#4d4d4d";
        y[0].style.background = "transparent";

        x[1].style.cssText = "background:#eecf9a !important;";
        x[1].style.cssText += "color:black !important;";
        y[1].style.cssText = "background:black !important;";
        y[1].style.cssText += "color:white !important;";
    }

    function openMobileMenu() {
        document.getElementById("mobile-menu-wrap").style.display="block";
        document.getElementById("mobile-menu-wrap").style.opacity="1";
    }

    function closeMobileMenu() {
        document.getElementById("mobile-menu-wrap").style.display="none";
        document.getElementById("mobile-menu-wrap").style.opacity="0";
        document.getElementById("container").click();
    }

    function expandMobileDDL(){
        var x = document.getElementById("mobile-navigationDDL");
        var num = document.getElementsByClassName("ddl-Item").length;;

        if (x.style.height == 48 * num - 1 + "px")
        {
            x.style.height = "0px";
        }
        else
        {
            x.style.height = 48 * num - 1 + "px";
        }
    }

    function mobileUserGuide(n) {
        var x = document.getElementsByClassName("instructionGTR-DescriptionContainer");
        var y = document.getElementsByClassName("instructionGTR-Description-TitleText-Right");

        if (x[n].style.display == "none")
        {
            x[n].style.display = "block";
            y[n].style.transform = "rotate(180deg)";
        }
        else
        {
            x[n].style.display = "none";
            y[n].style.transform = "rotate(0deg)";
        }
    }

    $(document).ready( function() {
        $(document).on("click", ".qalistBtn", function() {
            var faq_id = $(this).attr("data-value");
            var y = document.getElementById(faq_id);

            if (y.classList.contains("foldqalist")) {
                y.classList.remove("foldqalist");
                y.classList.add("openqalist");
            }
            else {
                y.classList.remove("openqalist");
                y.classList.add("foldqalist");
            }
        });

    });

    function toggle_vid_option(){
        var vid_sect = document.getElementById("videoSection");
        var vid_check = document.getElementById("vid_opt");
        var vid_id = document.getElementById("video_id");
        var vid_preview = document.getElementById("videoPreview");

        if (vid_check.checked == true) {
           vid_id.disabled = false;
           vid_sect.classList.toggle("hideVidOption");
        }
        else {
           vid_id.disabled = true;
           vid_sect.classList.toggle("hideVidOption");
           vid_preview.classList.add("add-Video-Preview-Hide");
        }
    }