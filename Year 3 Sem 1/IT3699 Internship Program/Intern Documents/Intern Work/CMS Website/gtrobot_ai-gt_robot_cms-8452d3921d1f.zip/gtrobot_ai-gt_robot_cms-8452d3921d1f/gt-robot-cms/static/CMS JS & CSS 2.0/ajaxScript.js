
$(document).ready( function() {

    $(document).ajaxStart(function () {
        $(document.body).css({ 'cursor' : 'wait' });
    });

    $(document).ajaxComplete(function () {
        $(document.body).css({ 'cursor' : 'default' });
    });

    $("#popupErrMsg").dialog({
        autoOpen : false,
        modal : true,
        height: 170,
        width: 320,
        buttons : [
            {
                text: "OK",
                "class" : 'dialogButton',
                click : function() {
                    $("#popupErrMsg").dialog("close");
                }
            }
        ],
        draggable : false,
        open: function(event, ui) {
            jQuery('.ui-dialog-titlebar-close').hide();
        },
        classes: {
            "ui-dialog" : "dialogContainer",
            "ui-dialog-content" : "dialogContent",
            "ui-dialog-titlebar" : "dialogTitlebar",
            "ui-dialog-title" : "dialogTitle",
            "ui-dialog-buttonpane" : "dialogButtonPane",
            "ui-dialog-buttonset" : "dialogButtonSet",
            "ui-widget-overlay" : "dialogOverlay"
        }
    });

    var ele;

    $("#popupDelete").dialog({
        autoOpen : false,
        modal : true,
        height: 170,
        width: 320,
        buttons : [
            {
                text: "Delete",
                "class" : 'dialogButton',
                click : function() {
                    var intent = jQuery.data(ele, "faq_intent");

                    req = $.ajax({
                        url : $link_d,
                        type: "POST",
                        data: { intent : intent },
                        beforeSend: function() {
                            $("#popupDelete").dialog("close");
                            $("#loaderScrn").dialog("open");
                        }
                    });

                    req.done( function(data) {
                        jQuery.removeData(ele, "faq_intent");
                        $("#popupErrTxt").text(data);
                    });

                    req.success( function() {
                        var faqType;
                        var currURL = window.location.pathname;

                        if (currURL.includes("Draft")) {
                            faqType = "Draft";
                        }
                        else if (currURL.includes("Saved")) {
                            faqType = "Saved";
                        }

                        req = $.ajax({
                            url : $link_re1,
                            type: "POST",
                            data: { faqType : faqType }
                        });

                        req.done( function(data) {
                            $("#qnaSection").html(data);
                            var newURL = "/" + faqType + "/updateMenu";
                            window.history.pushState(null, "GT WB CMS Portal", newURL);
                        });
                        $("#loaderScrn").dialog("close");
                        $("#popupErrMsg").dialog("open");
                    });
                }
            },
            {
                text: "Cancel",
                "class" : 'dialogButton',
                click : function() {
                    jQuery.removeData(ele, "faq_intent");
                    $("#popupDelete").dialog("close");
                }
            }
        ],
        draggable : false,
        async : false,
        open: function(event, ui) {
            jQuery('.ui-dialog-titlebar-close').hide();
        },
        classes: {
            "ui-dialog" : "dialogContainer",
            "ui-dialog-content" : "dialogContent",
            "ui-dialog-titlebar" : "dialogTitlebar",
            "ui-dialog-title" : "dialogTitle",
            "ui-dialog-buttonpane" : "dialogButtonPane",
            "ui-dialog-buttonset" : "dialogButtonSet",
            "ui-widget-overlay" : "dialogOverlay"
        }
    });

    $("#loaderScrn").dialog({
        autoOpen : false,
        modal : true,
        height: 170,
        width: 360,
        draggable : false,
        open: function(event, ui) {
            jQuery('.ui-dialog-titlebar-close').hide();
        },
        classes: {
            "ui-dialog" : "loadScrnContainer",
            "ui-dialog-content" : "loadScrnContent",
            "ui-widget-overlay" : "dialogOverlay"
        }
    });

    $(document).on("click", "#saveToWB", function () {
        var check = document.getElementsByClassName("qnCB");
        var intents = [];

        for ( var x = 0; x < check.length; x++) {
            if (check[x].checked == true) {
                var id = check[x].value;
                intents.push(id);
            }
        }

        if (intents.length != 0) {
            req = $.ajax({
                url: $link_s,
                type: "POST",
                data: { intents : JSON.stringify(intents) },
                beforeSend: function() {
                    $("#loaderScrn").dialog("open");
                }
            });

            req.done( function(data) {
                $("#popupErrTxt").text(data);
            });

            req.success( function(data) {
                req = $.ajax({
                    url : $link_re2,
                    type: "POST"
                });

                req.done( function(data) {
                    $("#qnaSection").html(data);
                });

                $("#loaderScrn").dialog("close");
                $("#popupErrMsg").dialog("open");
            });
        }
        else{
            $("#popupErrTxt").text("A FAQ has to be selected");
            $("#popupErrMsg").dialog("open");
        }
    });

    $(document).on("click", "#saveToWB2", function () {
        var check = document.getElementsByClassName("qnCB");
        var intents = [];

        for ( var x = 0; x < check.length; x++) {
            if (check[x].checked == true) {
                var id = check[x].value;
                intents.push(id);
            }
        }

        if (intents.length != 0) {
            req = $.ajax({
                url: $link_s,
                type: "POST",
                data: { intents : JSON.stringify(intents) },
                beforeSend: function() {
                    $("#loaderScrn").dialog("open");
                }
            });

            req.done( function(data) {
                $("#popupErrTxt").text(data);
            });

            req.success( function(data) {
                req = $.ajax({
                    url : $link_re1,
                    type: "POST",
                    data: { faqType : "Draft" }
                });

                req.done( function(data) {
                    $("#qnaSection").html(data);
                });

                $("#loaderScrn").dialog("close");
                $("#popupErrMsg").dialog("open");
            });
        }
        else{
            $("#popupErrTxt").text("A FAQ has to be selected");
            $("#popupErrMsg").dialog("open");
        }
    });

    $(document).on("click", "#createQA", function(ev) {
        ev.preventDefault();
        var x = document.getElementsByClassName("formInput");
        var formData = [];
        var video_id = "";

        for( var i = 0; i < x.length; i++) {
            var text = x[i].value;
            formData.push(text);
        }

        var y = document.getElementById("video_id");
        if (y.disabled == true) {
            video_id = "None"

            req = $.ajax({
                url: $link_a,
                type: "POST",
                data: {
                    formData : JSON.stringify(formData),
                    video_id : JSON.stringify(video_id)
                }
            });

            req.done( function(data) {
                if (data == "Added") {
                    localStorage.setItem("videoid", video_id);
                    window.location.href = $link_a_p;
                }
                else{
                    $("#popupErrTxt").text(data);
                    $("#popupErrMsg").dialog("open");
                }
            });
        }
        else {
            video_id = y.value;
//          /\S/.test(vid_id) checks if video id given is a whitespace or a empty string
//          empty string always equals to nul
            if (/\S/.test(video_id)) {
    //          DO NOT REMOVE API KEY! IF KEY DOES NOT WORK, CREATE A NEW KEY THRU A GOOGLE CLOUD PLATFORM PROJECT
                var apiKey = "AIzaSyCZ_SqGUM_1W7CPqynFnGIuysBdAHc55NQ";
                var field = "";
                var url = "https://www.googleapis.com/youtube/v3/videos" + "?key=" + apiKey + "&id=" + video_id + "&"
                + field + "&" + "part=snippet";

                $.get(url, function(response) {
                    var status = response.pageInfo.totalResults;
                    if (status) {
                        req = $.ajax({
                            url: $link_a,
                            type: "POST",
                            data: {
                                formData : JSON.stringify(formData),
                                video_id : JSON.stringify(video_id)
                            }
                        });

                        req.done( function(data) {
                            if (data == "Added") {
                                localStorage.setItem("videoid", video_id);
                                window.location.href = $link_a_p;
                            }
                            else{
                                $("#popupErrTxt").text(data);
                                $("#popupErrMsg").dialog("open");
                            }
                        });
                    }
                    else {
                        $("#popupErrTxt").text("Invalid video ID!");
                        $("#popupErrMsg").dialog("open");
                    }
                });
            }
            else {
                $("#popupErrTxt").text("Please enter a video ID!");
                $("#popupErrMsg").dialog("open");
            }
        }
    });

    $(document).on("click", "#updateQA", function(ev) {
        ev.preventDefault();
        var x;
        var formData = [];
        var original_qns = [];
        var video_id;

        x = document.getElementById("faqID");
        var faq_id = x.value;

        x = document.getElementById("invisibleSample");
        var original_intent = x.value;

        x = document.getElementsByClassName("formInput");
        for( var i = 0; i < x.length; i++) {
            var text = x[i].value;
            formData.push(text);
        }

        x = document.getElementsByClassName("original_qn");
        for( var i = 0; i < x.length; i++) {
            var text = x[i].value;
            original_qns.push(text);
        }

        x = document.getElementById("video_id");
        if (x.disabled == true) {
            video_id = "None";

            req = $.ajax({
                url: $link_u,
                type: "POST",
                data: {
                    formData : JSON.stringify(formData),
                    original_intent : JSON.stringify(original_intent),
                    original_qns : JSON.stringify(original_qns),
                    faq_id :  JSON.stringify(faq_id),
                    video_id : JSON.stringify(video_id)
                }
            });

            req.done( function(data) {
                if (data == "Saved") {
                    localStorage.setItem("videoid", video_id);
                    window.location.href = $link_u_p;
                }
                else{
                    $("#popupErrTxt").text(data);
                    $("#popupErrMsg").dialog("open");
                }
            });
        }
        else {
            video_id = x.value;

            if (/\S/.test(video_id)) {
    //          DO NOT REMOVE API KEY! IF KEY DOES NOT WORK, CREATE A NEW KEY THRU A GOOGLE CLOUD PLATFORM PROJECT
                var apiKey = "AIzaSyCZ_SqGUM_1W7CPqynFnGIuysBdAHc55NQ";
                var field = "";
                var url = "https://www.googleapis.com/youtube/v3/videos" + "?key=" + apiKey + "&id=" + video_id + "&"
                + field + "&" + "part=snippet";

                $.get(url, function(response) {
                    var status = response.pageInfo.totalResults;

                    if (status) {
                        req = $.ajax({
                            url: $link_u,
                            type: "POST",
                            data: {
                                formData : JSON.stringify(formData),
                                original_intent : JSON.stringify(original_intent),
                                original_qns : JSON.stringify(original_qns),
                                faq_id :  JSON.stringify(faq_id),
                                video_id : JSON.stringify(video_id)
                            }
                        });

                        req.done( function(data) {
                            if (data == "Saved") {
                                localStorage.setItem("videoid", video_id);
                                window.location.href = $link_u_p;
                            }
                            else{
                                $("#popupErrTxt").text(data);
                                $("#popupErrMsg").dialog("open");
                            }
                        });
                    }
                    else {
                        $("#popupErrTxt").text("Invalid video ID!");
                        $("#popupErrMsg").dialog("open");
                    }
                });
            }
            else {
                $("#popupErrTxt").text("Please enter a video ID!");
                $("#popupErrMsg").dialog("open");
            }
        }
    });

    $(document).on("click", "#previewBtn", function(ev) {
        var vid_id = document.getElementById("video_id").value;
        var vid_prvw_sect = document.getElementById("videoPreview");

//      /\S/.test(vid_id) checks if video id given is a whitespace or a empty string
//      empty string always equals to nul

        if (/\S/.test(vid_id)) {
            if (vid_id != null || vid_id != "\n") {
//              DO NOT REMOVE API KEY! IF KEY DOES NOT WORK, CREATE A NEW KEY THRU A GOOGLE CLOUD PLATFORM PROJECT
                var apiKey = "AIzaSyCZ_SqGUM_1W7CPqynFnGIuysBdAHc55NQ";
                var field = "";
                var url = "https://www.googleapis.com/youtube/v3/videos" + "?key=" + apiKey + "&id=" + vid_id + "&"
                + field + "&" + "part=snippet";
                $.get(url, function(response) {
                    var status = response.pageInfo.totalResults;
                    if (status) {
                        var url = "https://www.youtube.com/embed/" + vid_id;

                        if (vid_prvw_sect.classList.contains("add-Video-Preview-Hide")) {
                            vid_prvw_sect.classList.remove("add-Video-Preview-Hide");
                        }
                        $("#videoFrame").attr('src', url);
                    }
                    else {
                        if (!vid_prvw_sect.classList.contains("add-Video-Preview-Hide")) {
                            vid_prvw_sect.classList.add("add-Video-Preview-Hide");
                        }
                        $("#popupErrTxt").text("Invalid video ID!");
                        $("#popupErrMsg").dialog("open");
                    }
                });
             }
        }
        else {
            $("#popupErrTxt").text("Please enter a video ID!");
            $("#popupErrMsg").dialog("open");
        }
        ev.preventDefault();
    });

    $(document).on("click", ".delBtn", function() {
        ele = $(this);
        var intent = $(this).attr("value");
        jQuery.data(ele, "faq_intent", intent);
        $("#popupDelete").dialog("open");
    });

    $(document).on("click", ".filterSaved", function() {
        var faqType = $(this).attr("value");
        req = $.ajax({
            url : $link_re1,
            type: "POST",
            data: { faqType : faqType }
        });

        req.done( function(data) {
            $("#qnaSection").html(data);
            window.history.pushState(null, "GT WB CMS Portal", "/Saved/updateMenu");
        });
    });

    $(document).on("click", ".filterDraft", function() {
        var faqType = $(this).attr("value");

        req = $.ajax({
            url : $link_re1,
            type: "POST",
            data: { faqType : faqType }
        });

        req.done( function(data) {
            $("#qnaSection").html(data);
            window.history.pushState(null, "GT WB CMS Portal", "/Draft/updateMenu");
        });
    });

    $(document).on("click", ".filterGeneral", function() {
        var acctType = $(this).attr("value");
        req = $.ajax({
            url : $link_re3,
            type: "POST",
            data: { acctType : acctType }
        });

        req.done( function(data) {
            $("#accSection").html(data);
        });
    });

    $(document).on("click", ".filterAdmin", function() {
        var acctType = $(this).attr("value");
        req = $.ajax({
            url : $link_re3,
            type: "POST",
            data: { acctType : acctType }
        });

        req.done( function(data) {
            $("#accSection").html(data);
        });
    });

    $(document).on("click", ".chgPwdBtn", function() {
        ele = $(this);
        var modUser = $(this).attr("value");

        req = $.ajax({
            url : $link_accPd,
            type: "POST",
            data: { modUser: JSON.stringify(modUser) }
        });

        req.done( function(data) {
            if (data == "True") {
                window.location.href = $link_accPd_p;
            }
            else {
                $("#popupErrTxt").text("Error redirecting. Please contact customer support");
                $("#popupErrMsg").dialog("open");
            }
        });
    });

    $(document).on("click", ".chngPwdCancel", function() {
        jQuery.removeData(ele, "modUser");
    });


});