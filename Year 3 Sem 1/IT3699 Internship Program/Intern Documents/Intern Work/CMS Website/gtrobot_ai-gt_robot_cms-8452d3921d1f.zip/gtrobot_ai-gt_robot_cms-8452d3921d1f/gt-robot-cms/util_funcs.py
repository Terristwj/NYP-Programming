# from funcs import new_user,forget_password,fetch_user,fetch_QA,add_QA,upd_QA,del_QA
import json, time, datetime, string, hashlib, dialogflow_v2
from bson import ObjectId

import os
# file = os.path.abspath("static/GT Robot-5e74c77b5b66.json")
# os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = file
#
# project_id = 'gt-robot-233702'
# project_id = g.user["bot_id"]     This is because in the future, the bot_id for every account is different.
#
#                                   The g.user["user_id"] in mongdoDB will be the
#                                   same as the user collection attribute "_id"

language_code = 'en'

# from lxml import etree
# from lxml.cssselect import CSSSelector
# import lxml.html
# from lxml import etree, cssselect
# from flask import url_for

dtype = "qa-pair"
cur_time = lambda: int(round(time.time() * 1000))

def set_env(botId):
    if botId == 'gtrob-dialogflow1':
        file = os.path.abspath("static/gtrob-dialogflow1-06ede19728c0.json")
    else:
        file = os.path.abspath("static/GT Robot-5e74c77b5b66.json")
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = file


def new_user(role, username, password, client, client_name=None, client_alias=None, user_id=None, bot_id=None, createdAt=time.asctime()):
    ##Insert new username and password to MongoDB and generate keys 'id','password','username'
    doc = {}
    if role == "General":
        doc = {"username": username, "password": password, "Role": role, "createdAt": createdAt,
               "clientName": client_name, "clientAlias": client_alias, "user_id": user_id, "bot_id": bot_id}
    elif role == "Admin":
        doc = {"username": username, "password": password, "Role": role, "createdAt": createdAt}

    result = client.insert_one(doc)

    if result:
        return True
    else:
        return False

def update_user(original_user, client, nrole=None, nclient_name=None, nclient_alias=None, nuser_id=None, nbot_id=None, mdb=None):
    ##Insert new username and password to MongoDB and generate keys 'id','password','username'

    # Entire section is for General Users
    original_userId = original_user["user_id"]

    select_query = {"username": original_user["username"]}
    new_query = {"Role": nrole, "clientName": nclient_name, "clientAlias": nclient_alias, "user_id": nuser_id, "bot_id": nbot_id}
    update_query = {"$set": new_query}

    result = client.update_one(select_query, update_query)

    if result:
        select_query = {"user_id": original_userId}
        new_query = {"user_id": nuser_id}
        update_query = {"$set": new_query}

        result = mdb.update_many(select_query, update_query)

        print (result)

        if result:
            return True
        else:
            return False
    else:
        return False

def clientname_exist(client_name, client):
    ## find client name in MongoClient  (Client name is company)
    ## Return true of client name found, false if not
    query = {"clientName": client_name}
    result = client.find_one(query)

    if result:
        return True
    else:
        return False

def user_id_exist(user_id, client):
    ## find client name in MongoClient  (Client name is company)
    ## Return true of client name found, false if not
    query = {"user_id": user_id}
    result = client.find_one(query)

    if result:
        return True
    else:
        return False

def bot_id_exist(bot_id, client):
    ## find client name in MongoClient  (Client name is company)
    ## Return true of client name found, false if not
    query = {"bot_id": bot_id}
    result = client.find_one(query)

    if result:
        return True
    else:
        return False

def forget_password():
    pass

def change_password(update, value1, key1, value2, key2, client):
    myquery = {key1: value1}
    newvalues = {update: {key2: value2}}
    result = client.update_one(myquery, newvalues)
    if result:
        return True
    else:
        return False

def fetch_user(value,key,client):
    ## Search record in MongoDB then return dictionary of necessary values
    ## result must contain keys 'password', 'id'
    if key == '_id':
        value = ObjectId(value)
    try:
        result = client.find_one({key:value})
        result['_id'] = str(result['_id'])
    except Exception as e:
        result = None
    return result

def fetch_accounts(value,key,client):
    try:
        result = list(client.find({key:value}))
    except Exception:
        result = 'None'

    if not result:
        result.insert(0,{'Acct':'None'})
        return result
    return result

# Test codes to retrieve one FAQ
def fetch_one_qa(value1,key1,value2,key2,qna_db,qnaInt_db):
    result = None

    if key1 == 'intent' and key2 == 'username':
        # Get all questions of intent
        questions = list(qna_db.find({key1: value1, key2: value2}))
        if questions:
            # Get answer of intent from MongoDB intent collection
            intent = qnaInt_db.find({key1: value1, key2: value2})
            print('fetched intent:          ' + intent[0]['intent'])
            answer = intent[0]['answer']
            action = intent[0]['action']
            prevAka = intent[0]['prevAka']
            # Form FAQ with all 3 components (intent, questions, answer)
            if 'videoId' in intent[0].keys():
                result = {'intent': value1, 'questions': questions, 'answer': answer, 'videoId': intent[0]['videoId'],'_id': ObjectId(intent[0]['_id']), 'action': action,
                          'prevAka': prevAka}
            else:
                result = {'intent': value1, 'questions': questions, 'answer': answer, 'videoId': "None", '_id': ObjectId(intent[0]['_id']), 'action': action,
                          'prevAka': prevAka}
        else:
            result = 'None'
    return result

# Test codes (Forms a FAQ and adds it into an list object which will be returned)
def fetch_faqs(value1,key1,value2,key2,qna_db,qnaInt_db):
    try:
        result = []
        if key1 == 'type' and key2 == 'username':
            intents = list(qnaInt_db.find({key1: value1, key2: value2}))
            for item in intents:
                # print(item)
                # Get all questions of intent
                questions = list(qna_db.find({key2: value2, 'intent': item['intent']}))
                # Form FAQ with all 3 components (intent, questions, answer)
                if len(item) == 13:
                    faq = {'intent': item['intent'], 'questions': questions, 'answer': item['answer'],
                            'videoId': item['videoId'], 'action': item['action'], 'username': value2}
                else:
                    faq = {'intent': item['intent'], 'questions': questions, 'answer': item['answer'],
                            'videoId': "None", 'action': item['action'], 'username': value2}
                # Insert FAQ into result
                result.append(faq)
                # print(result)
            # print('result from fetch_faqs:          ' + result)
            if len(result) == 0:
                result = 'None'
    except Exception:
         result = 'None'
    return result

def fetch_qa_type(value1,key1,value2,key2,qnaInt_db):
    try:
        result = None
        if key1 == 'intent' and key2 == 'username':
            intents = list(qnaInt_db.find({key1: value1, key2: value2}))
            # print(intents)
            for i in range(len(intents)):
                if 'type' in intents[i].keys():
                    result = intents[i]['type']
                    # print('FAQ type is' + result)
    except Exception:
        result = 'None'
    return result

def update_qa_action(value1,key1,value2,key2,value3,key3,qnaInt_db):
    # key1 = action key2 = intent key3 = user_id
    try:
        result = None
        if key1 == "action":
                print('Found exisiting action')
                result = qnaInt_db.find_one_and_update({key2: value2, key3: value3}, {"$set": {key1: value1}})
                print(result)
    except Exception:
        result = 'None'
    return result

# def add_qa(user_id,username,intent,questions,answer,qna_db,qnaInt_db,type,videoId=None,action=None,check=True,faq_id=None):
#     ## Need keys 'username','Question','Answer','last_modified'
#     doc_q = []
#
#     if check_intent(username, faq_id, intent, qnaInt_db):
#         success = False
#     else:
#         success = None
#         # print('START!!!')
#         istring = intent.translate(str.maketrans('', '', string.punctuation)).replace(' ', '').lower()
#         doc_int = {"user_id": user_id, "username": username, "answer": answer.strip(), "createdAt": cur_time(),
#                    "last_modified": cur_time(), "updatedBy": username, "intent": intent, "type": type,
#                    "action": action, "istring": istring}
#
#         if videoId: doc_int["videoId"] = videoId
#
#         # print('Start creating questions! 1')
#         for each in questions:
#             qstring = each.translate(str.maketrans('', '', string.punctuation)).replace(' ', '').lower()
#             if check is not None:
#                 # print('pass check')
#                 result = check_qa(username, faq_id, each, qna_db, qnaInt_db)
#                 if not result:
#                     doc_q.append({"user_id": user_id, "username": username, "intent": intent, "question": each.strip(),
#                                   "createdAt": cur_time(), "last_modified": cur_time(),
#                                   "updatedBy": username, "qstring": qstring})
#                 else:
#                     success = False
#             else:
#                 # print('fail check')
#                 doc_q.append({"user_id": user_id, "username": username, "intent": intent, "question": each.strip(),
#                               "createdAt": cur_time(), "last_modified": cur_time(),
#                               "updatedBy": username, "qstring": qstring})
#
#         res_int = qnaInt_db.insert_one(doc_int)
#         if res_int.acknowledged:
#             res_tp = qna_db.insert_many(doc_q)
#             result = res_tp.acknowledged
#             if result:
#                 print('Add:     Update action')
#                 result = update_qa_action(action, 'action', intent, 'intent', user_id, 'user_id', qnaInt_db)
#                 if result:
#                     success = True
#         else:
#             success = False
#     return success

# Test codes (Add FAQ into MongoDB)
def add_qa(user_id,username,intent,questions,answer,qna_db,qnaInt_db,type,prevAka=None,videoId=None,action=None,check=True,faq_id=None):
    ## Need keys 'username','Question','Answer','last_modified'
    doc_q = []

    if check_intent(username, faq_id, intent, qnaInt_db):
        success = False
    else:
        success = None
        if prevAka is None:
            prevAka = "None"
        # print('START!!!')
        istring = intent.translate(str.maketrans('', '', string.punctuation)).replace(' ', '').lower()
        doc_int = {"user_id": user_id, "username": username, "answer": answer.strip(), "createdAt": cur_time(),
                   "last_modified": cur_time(), "updatedBy": username, "intent": intent, "type": type,
                   "action": action, "istring": istring, "prevAka": prevAka}

        if videoId: doc_int["videoId"] = videoId

        print('prevAka:     ' + prevAka)

        # print('Start creating questions! 1')
        for each in questions:
            qstring = each.translate(str.maketrans('', '', string.punctuation)).replace(' ', '').lower()
            if check is not None:
                # print('pass check')
                result = check_qa(username, faq_id, each, qna_db, qnaInt_db)
                if not result:
                    doc_q.append({"user_id": user_id, "username": username, "intent": intent, "question": each.strip(),
                                  "createdAt": cur_time(), "last_modified": cur_time(),
                                  "updatedBy": username, "qstring": qstring})
                else:
                    success = False
            else:
                # print('fail check')
                doc_q.append({"user_id": user_id, "username": username, "intent": intent, "question": each.strip(),
                              "createdAt": cur_time(), "last_modified": cur_time(),
                              "updatedBy": username, "qstring": qstring})

        res_int = qnaInt_db.insert_one(doc_int)
        if res_int.acknowledged:
            res_tp = qna_db.insert_many(doc_q)
            result = res_tp.acknowledged
            if result:
                print('Add:     Update action')
                result = update_qa_action(action, 'action', intent, 'intent', user_id, 'user_id', qnaInt_db)
                if result:
                    success = True
        else:
            success = False
    return success

# If this method's output is false, it means that the question that is checked does not exist
# If this method's output is true, it means that the question that is checked exists
def check_qa(user_id,faq_id,question,qna_db,qnaInt_db):
    # print('question     ' + question)
    query = question.translate(str.maketrans('','',string.punctuation)).replace(' ','').lower()
    # print('question qstring     ' + query)

    # Find and get duplicate in MongoDB
    result = qna_db.find_one({'user_id': user_id, 'qstring': query})

    if result:
        # print('Found duplicate, now checking')
        check = hashlib.md5(query.encode('utf-8')).digest() == hashlib.md5(result['qstring'].encode('utf-8')).digest()
        # If check shows that given question is the same as the duplicate's question, start checking _id of currently selected faq and duplicate
        if check:
            # print('Checking complete, now checking _id of result and question')
            # Check if qa_id has been provided, if provided move onto checking _id of given question and duplicate
            if faq_id is not None:
                dupe_id = qnaInt_db.find_one({'intent': result['intent']})
                # print('dupe id      ' + str(dupe_id['_id']))
                # print('faq id       ' + faq_id)
                if faq_id == str(dupe_id['_id']) and user_id == dupe_id['user_id']:
                    # print('1')
                    return False
                # If FAQ question being updated or added is not the duplicate detected, stop the update and throw error
                else:
                    # print('2')
                    return True
            # When faq_id is not provided, stop process and throw question already exists error since the FAQ question being added is a duplicate
            else:
                # print('3')
                return True
        # If duplicate intent not found, allow process to continue is question does not exist
        else:
            # print('4')
            return False
    # If there is no duplicate question found, allow process that is being run to continue
    else:
        # print('5')
        return False

# If this method's output is false, it means that the intent that is checked does not exist
# If this method's output is true, it means that the intent that is checked exists
def check_intent(user_id,faq_id,intent,qnaInt_db):
    # print('intent   ' + intent)
    query = intent.translate(str.maketrans('','',string.punctuation)).replace(' ','').lower()
    # print('intent istring   ' + query)
    # Find and get duplicate in MongoDB
    result = qnaInt_db.find_one({'user_id': user_id, 'istring': query})

    # If duplicate is found in MongoDB, start checking
    if result:
        # print('Found duplicate, now checking')
        check = hashlib.md5(query.encode('utf-8')).digest() == hashlib.md5(result['istring'].encode('utf-8')).digest()

        # If check shows that given intent is the same as the duplicate's intent, start checking _id of currently selected faq and duplicate
        if check:
            # print('Checking complete, now checking _id of result and currently selected FAQ')

            # Check if faq_id has been provided, if provided move onto checking _id of currently selected faq and duplicate
            if faq_id is not None:
                # print('current selected faq id:     ' + faq_id)
                # print('result id:   ' + str(result['_id']))

                # Before concluding that intent exists, check if FAQ being updated is the duplicate detected
                # If FAQ intent being updated is the duplicate, allow it to be updated
                if faq_id == str(result['_id']) and user_id == result['user_id']:
                    return False
                # If FAQ intent being updated or added is not the duplicate detected, stop the update and throw error
                else:
                    return True
            # When faq_id is not provided, move onto checking if FAQ intent is a duplicate
            # If the intent of the FAQ being added is a duplicate, stop process and throw FAQ already exists error
            else:
                return True
        # If duplicate intent not found, allow process to continue is FAQ does not exist
        else:
            return False
    # If there is no duplicate intent found, allow process that is being run to continue
    else:
        return False

def del_qa(value, user_id, qaType, qna_db, qnaInt_db):
    # Delete FAQ as specified by value, which is intent
    success = qnaInt_db.delete_one({'intent': value, 'user_id': user_id})
    if success:
        success = qna_db.delete_many({'intent': value, 'user_id': user_id})
        if success:
            if qaType == "Saved":
                result = update_qa_action('Delete', 'action', value, 'intent', user_id, 'user_id', qnaInt_db)
                if result:
                    success = True
            else:
                success = True
        else:
            success = False
    else:
        success = False
    return success

# Test codes (save FAQs into Wonder Boy)
def save_qa(intents,username, qna_db, qnaInt_db, uinfo):
    # try:
    success = None
    message = None

    if intents:
        # user_qnas holds all FAQs, with each FAQ as 1 list item
        # Each FAQ contains a intent, a set of questions and a answer
        user_qnas = []
        # user_intents holds all FAQs set of questions, with each question as 1 list item
        user_intents = []
        user_info = fetch_user(username, 'username', uinfo)
        bot_id = user_info['bot_id']
        # for intent in intents:
        #     if qnaInt_db.find_one({'intent':intent}, {'action': 1})['action'] == 'Delete':
        #         res = delete_intent([intent], user_info['clientAlias'], bot_id)
        #         if res:
        #             result = del_qa(intent, user_info['user_id'], 'Draft', qna_db, qnaInt_db)
        #             if result:
        #                 user_qna = fetch_one_qa(intent, 'intent', username, 'username', qna_db, qnaInt_db)
        #                 user_intents.append(user_qna['intent'])
        #                 user_qnas.append(user_qna)
        #                 success = True
        #             else:
        #                 success = False
        #                 message = "Failed to store FAQs into Wonder Boy"
        #         else:
        #             success = False
        #             message = "Failed to store FAQs into Wonder Boy"
        #     else:
        #         # Prep for "add_intents(user_qnas, user_info)"
        #         user_qna = fetch_one_qa(intent, 'intent', username, 'username', qna_db, qnaInt_db)
        #         if user_qna:
        #             user_qnas.append(user_qna)
        #             print('user_qna:         ', user_qna)
        #             user_intents.append(user_qna['intent'])
        #             success = True
        #         else:
        #             success = False
        #             message = "Failed to store FAQs into Wonder Boy"
        for intent in intents:
            # Prep for "add_intents(user_qnas, user_info)"
            user_qna = fetch_one_qa(intent, 'intent', username, 'username', qna_db, qnaInt_db)
            if user_qna:
                if user_qna['action'] == "Delete":
                    res = delete_intent([intent], user_info['clientAlias'], bot_id)
                    if res:
                        result = del_qa(intent, user_info['user_id'], 'Draft', qna_db, qnaInt_db)
                        if result:
                            success = True
                            message = "FAQs successfully saved into Wonder Boy"
                        else:
                            success = False
                            message = "Failed to store FAQs into Wonder Boy"

                elif user_qna['action'] == "Edit":
                    user_qnas.append(user_qna)
                    print('user_qna edit:         ', user_qna)
                    user_intents.append(user_qna['prevAka'])
                    success = True

                else:
                    user_qnas.append(user_qna)
                    print('user_qna Add:         ', user_qna)
                    user_intents.append(user_qna['intent'])
                    success = True
            else:
                success = False
                message = "Failed to store FAQs into Wonder Boy"
    # print('user_intents:     '+  user_intents)
    # if success:
    #     # Add into DialogFlow
    #     user_info = fetch_user(username, 'username', uinfo)
    #     # clean_intents retrieves existing intents(FAQs) in dialogflow
    #     clean_intents = fetch_intents_dialogflow(user_info, qnaInt_db, user_intents)
    #     # Remove the existing intents(FAQs) from dialogflow in case any of the FAQs were
    #     # once before added into dialogflow.
    #     res = delete_intent(clean_intents, user_info['clientAlias'], bot_id)
    #     if res:
    #         create_intents = add_intents(user_qnas, user_info)
    #         if create_intents:
    #             for intent in intents:
    #                 result = qnaInt_db.find_one_and_update({'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Saved'}})
    #             message = "FAQs successfully saved into Wonder Boy"
    #             success = True
    #         else:
    #             # Revert type back to Draft
    #             for intent in intents:
    #                 result = qnaInt_db.find_one_and_update({'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Draft'}})
    #             message = "Failed to store FAQs into Wonder Boy"
    #             success = False
    if success and user_intents:
        # Add into DialogFlow
        user_info = fetch_user(username, 'username', uinfo)
        # clean_intents retrieves existing intents(FAQs) in dialogflow
        print('user_intents-------------------')
        clean_intents = fetch_intents_dialogflow(user_info, qnaInt_db, user_intents)
        print('user_intents-------------------')
        # Remove the existing intents(FAQs) from dialogflow in case any of the FAQs were
        # once before added into dialogflow.
        if clean_intents:
            res = delete_intent(clean_intents, user_info['clientAlias'], bot_id)
            if res:
                # Remove the existing intents from MongoDB
                for intent in clean_intents:
                    res = del_qa(intent, user_info['user_id'], 'Draft', qna_db, qnaInt_db)
                    if not res:
                        success = False
                        message = "Failed to store FAQs into Wonder Boy"
            else:
                success = False
                message = "Failed to store FAQs into Wonder Boy"

        # If removal of existing intents from MongoDB & Dialogflow is successful,
        # begin creating user_qnas list of intents in dialogflow.
        if success:
            create_intents = add_intents(user_qnas, user_info)
            if create_intents:
                for intent in intents:
                    result = qnaInt_db.find_one_and_update(
                        {'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Saved', 'prevAka': intent}})
                message = "FAQs successfully saved into Wonder Boy"
            else:
                # Revert type back to Draft
                for intent in intents:
                    result = qnaInt_db.find_one_and_update(
                        {'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Draft' , 'prevAka': "None"}})
                message = "Failed to store FAQs into Wonder Boy"

    # If error encountered, try to save FAQs into Wonder Boy again
    # except Exception as e:
    #     # # clean_intents retrieves existing intents(FAQs) in dialogflow
    #     # clean_intents = fetch_intents_dialogflow(user_info, qnaInt_db, user_intents)
    #     # if clean_intents:
    #     #     # Remove the existing intents(FAQs) from dialogflow since error has occurred
    #     #     res = delete_intent(clean_intents, user_info['clientAlias'], bot_id)
    #     #     if res:
    #     #         create_intents = add_intents(user_qnas, user_info)
    #     #         if create_intents:
    #     #             for intent in intents:
    #     #                 result = qnaInt_db.find_one_and_update({'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Saved'}})
    #     #             message = "FAQs successfully saved into Wonder Boy"
    #     #             success = True
    #     #         else: # Redo the type
    #     #             # print("Reverting MongoDB Changes")
    #     #             for intent in intents:
    #     #                 result = qnaInt_db.find_one_and_update({'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Draft'}})
    #     #             message = "Failed to store FAQs into Wonder Boy"
    #     #             success = False
    #     # else:
    #     #     create_intents = add_intents(user_qnas, user_info)
    #     #     if create_intents:
    #     #         for intent in intents:
    #     #             result = qnaInt_db.find_one_and_update({'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Saved'}})
    #     #         message = "FAQs successfully saved into Wonder Boy"
    #     #         success = True
    #     #     else:
    #     #         # Redo the type
    #     #         for intent in intents:
    #     #             result = qnaInt_db.find_one_and_update({'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Draft'}})
    #     #         message = "Failed to store FAQs into Wonder Boy"
    #     #         success = False
    #     clean_intents = fetch_intents_dialogflow(user_info, qnaInt_db, user_intents)
    #     # Remove the existing intents(FAQs) from dialogflow in case any of the FAQs were
    #     # once before added into dialogflow.
    #     if clean_intents:
    #         res = delete_intent(clean_intents, user_info['clientAlias'], bot_id)
    #         if res:
    #             # Remove the existing intents from MongoDB
    #             for intent in clean_intents:
    #                 res = del_qa(intent, user_info['user_id'], 'Draft', qna_db, qnaInt_db)
    #                 if not res:
    #                     success = False
    #                     message = "Failed to store FAQs into Wonder Boy"
    #         else:
    #             success = False
    #             message = "Failed to store FAQs into Wonder Boy"
    #
    #     # If removal of existing intents from MongoDB & Dialogflow is successful,
    #     # begin creating user_qnas list of intents in dialogflow.
    #     if success:
    #         create_intents = add_intents(user_qnas, user_info)
    #         if create_intents:
    #             for intent in intents:
    #                 result = qnaInt_db.find_one_and_update(
    #                     {'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Saved'}})
    #             message = "FAQs successfully saved into Wonder Boy"
    #         else:
    #             # Revert type back to Draft
    #             for intent in intents:
    #                 result = qnaInt_db.find_one_and_update(
    #                     {'intent': intent, 'username': user_info['username']}, {"$set": {'type': 'Draft'}})
    #             message = "Failed to store FAQs into Wonder Boy"
    #     print('save_qa error:           ' + str(e))
    # finally:
    return message

def user_exists(username,client):
    # find username in MongoClient
    # Return true if user found, false if not
    try:
        result = client.find_one({'username': username})
    except Exception as e:
        return str(e), 500
    return True if result else False

def add_intents(user_qnas, user_info, count=0):
    # update all intents of a client
    project_id = user_info['bot_id']
    set_env(project_id)
    success = None
    payload = {}

    try:
        intents = []
        # print(user_qnas)
        for qna in user_qnas:
            # if user_info['type'] == 'CMS':
            # Placeholder for better handling of multi-client per single bot
            if project_id != 'gtrob-dialogflow1':
                sentence = user_info['clientAlias'].upper() + '.' + qna['intent']
            else:
                sentence = qna['intent']

            training = grp_questions(qna['questions'])
            payload = crt_payload(qna) if 'videoId' in qna.keys() else {}
            intents.append(
                {
                    "messages": [
                        {
                            "text": {
                                "text": [
                                    qna['answer']
                                ]
                            }
                        },
                        {
                            "payload": payload
                        }
                    ],
                    "webhook_state": "WEBHOOK_STATE_UNSPECIFIED",
                    "priority": 500000,
                    "ml_disabled": True,
                    "is_fallback": False,
                    "reset_contexts": True,
                    "training_phrases": training,
                    "display_name": sentence
                }
            )
        intent_client = dialogflow_v2.IntentsClient()
        # parent = intent_client.project_agent_path(user_info['user_id'])
        parent = intent_client.project_agent_path(project_id)
        print("Check Point:    If long load = Error 503 is loading")
        response = intent_client.batch_update_intents(parent=parent, language_code='en', intent_batch_inline={'intents':intents})
        while response.running():
            continue
        print("Check Point:    Complete")
        # success = True
        agent_client = dialogflow_v2.AgentsClient()
        parent_agent = agent_client.project_path(project_id)
        if response:
            agent_client.train_agent(parent_agent)
            success = True
    except Exception as e:
        s = str(e)
        print("Error Found: " + "'" + s + "'")
        if s == "503 Connect Failed" or s == "503 Name resolution failure":
            if count < 20:  # Set a counter to limit repeat limit
                count += 1
                success = add_intents(user_qnas, user_info, count)
        else:
            print("Error: Unable to add into DialogFlow")
            success = False
    finally:
        return success

def delete_intent(intent_names,clientAlias, bot_id, count=0):
    success = False
    try:
        project_id = bot_id
        set_env(project_id)
        # intents = get_all_intent(project_id, username)
        intent_client = dialogflow_v2.IntentsClient()
        # parent = intent_client.project_agent_path(user_info['botId'])
        parent = intent_client.project_agent_path(project_id)
        intents = []
        for intent_name in intent_names:
            for element in intent_client.list_intents(parent):
                if element.action != 'input.unknown' and element.display_name.startswith(clientAlias) and element.display_name.endswith(intent_name):
                    intents.append(element)

        print('intents: ', intents)
        if len(intents) != 0:
            response = intent_client.batch_delete_intents(parent, intents)
            if response: success = True

            def callback(operation_future):
                # Handle result.
                result = operation_future.result()
            response.add_done_callback(callback)
            # meta = response.metadata()
            while response.running():
                continue
            print("Delete success")
        else:
            success = True
    except Exception as e:
        s = str(e)
        print("Error Found: " + "'" + s + "'")
        if s == "503 Connect Failed" or s == "503 Name resolution failure":
            if count < 20:  # Set a counter to limit repeat limit
                count += 1
                success = delete_intent(intent_names, clientAlias, project_id, count)
        else:
            print("Error: Unable to delete from DialogFlow")
            success = False
    finally:
        return success

def fetch_intents_dialogflow(user,client,intent_names=None):
    if not intent_names:
        result = client.find({'username': user['username']}, {'intent': 1})
    else:
        result = intent_names
    set_env(user['bot_id'])
    intent_client = dialogflow_v2.IntentsClient()
    parent = intent_client.project_agent_path(user['bot_id'])
    # parent = intent_client.project_agent_path(project_id)

    int_list = []
    for each in result:
        print('item being run in each in result--------------------')
        print(each)
        print('item being run in each in result--------------------')
        int_list.append(user['clientAlias'] + '.' + each)

    print('int_list: ',int_list)
    # print('user',user)

    exist_int = []
    # for intent_name in int_list:
    #     print(intent_name)
    for element in intent_client.list_intents(parent):
        if element.action != 'input.unknown' and element.display_name.startswith(user['clientAlias']) and element.display_name in int_list:
            print(element.display_name in int_list)
            exist_int.append(element.display_name)
    print("fetch_intents compare: ", exist_int)
    return exist_int

def grp_questions(questions):
    training_phrases = []
    for each in questions:
        training_phrases.append(
            {
                "parts": [
                    {
                        "text": each['question']
                    }
                ]
            }
        )
    return training_phrases

def crt_payload(qna):
    answer = qna['answer']
    intent = qna['intent']
    videoId = qna['videoId']
    parameters = dialogflow_v2.types.struct_pb2.Struct()
    if videoId != "None":
        parameters['promptTexts'] = [{
                   "text": 'Going to play ' + answer,
                   "interval": 100
                 }]
        parameters['serviceCommand'] = {
                   "serviceType": "video_service",
                   "uniqueCommand": "video_service_play"
                 }
        parameters['recognizedInfo'] = {
                   "videoId": videoId,
                   "type": "youtube",
                   "title": answer,
                   "keywords": intent
                 }

    return parameters