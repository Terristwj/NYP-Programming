from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for, jsonify, Response
)

import json
from instance.config import app_config
from auth import login_required
# from elasticsearch import Elasticsearch
from pymongo import MongoClient
from util_funcs import fetch_one_qa, fetch_qa_type, add_qa, del_qa, check_qa, check_intent, save_qa, delete_intent, add_intents, fetch_faqs

bp = Blueprint('process', __name__)
# mongo = MongoClient(app_config[config_name].MONGODB_URL)
# collection = 'user'
# es = Elasticsearch(app_config["development"].ES_HOST)
# index_name = "gtrobcms"
mongo = MongoClient(app_config["development"].MONGODB_URL)
# Stores FAQ intents
qna_int = mongo.get_database()["gtrobqa"]
# Stores FAQ questions
qna = mongo.get_database()["gtrobquestions"]
uinfo = mongo.get_database()["gtrobtest"]

@bp.route('/', methods=('GET', 'POST'))
@login_required
def index():
    ## gtrobcmsqa index to be created in elasticsearch for Q&A storage
    try:
        username = g.user['username']
        passwordMessage = None
        if session.get("passwordMessage"):
            passwordMessage = session.get("passwordMessage")
            session.pop('passwordMessage', None)

        result = fetch_faqs('Draft', 'type', username, 'username', qna, qna_int)
        # print(result)
    except Exception:
        result = None
        passwordMessage = None
    finally:
        return render_template('process/index.html', result=result, passwordMessage=passwordMessage)

##This method is used to refresh FAQ list in index.html
@bp.route('/refreshIndexList', methods=['POST'])
@login_required
def refreshDraftList():
    try:
        username = g.user['username']
        result = fetch_faqs('Draft', 'type', username, 'username', qna, qna_int)
    except Exception:
        result = None
    finally:
        return render_template('process/indexDraftFAQList.html', result=result)

@bp.route('/saveToWB', methods=['POST'])
@login_required
def saveToWB():
    message = 'Success'
    # try:
    print('enter try')
    username = g.user['username']
    intents = json.loads(request.form['intents'])
    print(intents)
    if not intents:
        message = 'A FAQ has to be selected'
    else:
        # Save into GT Wonder Boy, place pop-up msg codes here
        savetowb = save_qa(intents, username, qna, qna_int, uinfo)
        message = savetowb
    # except Exception:
    #     message = 'Save error!'
    # finally:
    print('enter finally')
    return Response(json.dumps(message), mimetype='application/json')

@bp.route('/add', methods=('GET', 'POST'))
@login_required
def add():
    session.pop('_flashes', None)
    return render_template('process/add.html')

@bp.route('/addFAQ', methods=['POST'])
def addFAQ():
    message = None
    intent = None
    questions = []
    answer = None
    data = json.loads(request.form["formData"])
    video_id = json.loads(request.form["video_id"])

    if request.method == 'POST':
        data_size = len(data)
        # This for loop retrieves all created FAQ data from form data
        for i in range(data_size):
            # This condition gets FAQ intent
            if i == 0:
                intent = data[i]
            elif i == (data_size-1):
                answer = data[i]
            elif i >= 1 and i != (data_size-1) and i != (data_size-1):
                questions.append(data[i])
        if video_id == "None":
            video_id = None

        if not intent:
            message = 'Intent is required.'
        for question in questions:
            if "/n" in question or not question:
                message = 'All questions are required.'
        if not answer:
            message = 'Answer is required.'

        # index_set array is used to store the rows that have a duplicate question
        index_set = []
        # indexes array is used to store the row index of rows that have a duplicate question
        indexes = []

        # If intent does not exist in database, continue adding FAQ
        if check_intent(g.user['user_id'], None, intent, qna_int):
            message = 'Intent already Exists!'
        else:
            # To check Question exists, and get sets of same Question. Example: 1,3,5 and 2,4 is the same
            for question in questions:
                # print(question)
                x = questions
                # x and xs in this lambda expression is the function arguments(parameters) of get_indexes as seen below
                get_indexes = lambda x, xs: [i for (y, i) in zip(xs, range(len(xs))) if x == y]

                # In this if condition, question is lambda expression 'x' and x is lambda expression 'xs'
                # The output of the get_indexes is an array that contains variables as seen in the example below
                # E.g. Output -> [ '<question>', '<index position of qn in questions array>']
                if len(get_indexes(question, x)) > 1 and get_indexes(question, x) not in index_set:
                    # print('Duplicate found!!!!!!!!!!!!!')
                    index_set.append(get_indexes(question, x))
                    # print('Appended to set!!')

                if check_qa(g.user['user_id'], None, question, qna, qna_int):
                    message = 'Question "' + question + '" already Exists!'
                    break

            # To extract the indexes and display as error.
            if index_set:
                for set in index_set:
                    for index in set:
                        indexes.append(index + 1)

                message = "Duplicate Questions! Rows: "
                indexes.sort()
                for index in indexes:
                    if not index == indexes[-1]:
                        message += str(index) + ", "
                    else:
                        message += str(index)

            if message is None:
                session.pop('_flashes', None)
                if video_id is None:
                    add_qa(g.user['user_id'], g.user['username'], intent, questions, answer, qna, qna_int,
                           'Draft', None, None, 'Add')
                else:
                    add_qa(g.user['user_id'], g.user['username'], intent, questions, answer, qna, qna_int,
                           'Draft', None, video_id, 'Add')
                message = "Added"

    return Response(json.dumps(message), mimetype='application/json')

@bp.route('/<type>/updateMenu')
@login_required
def updateMenu(type):
    try:
        username = g.user['username']
        result = fetch_faqs(type, 'type', username, 'username', qna, qna_int)

        if result == 'None':
            result = 'None'
            type = "Draft"
    except Exception:
        result = 'None'
        type = "Draft"
    finally:
        session.pop('_flashes', None)
        return render_template('process/updateMenu.html', result=result, type=type)

# This method is used to refresh FAQ list in updateMenu.html and used by delete() function
@bp.route('/grabQAList', methods=['POST'])
@login_required
def grabQAList():
    try:
        type = request.form["faqType"]
        username = g.user['username']
        result = fetch_faqs(type, 'type', username, 'username', qna, qna_int)
        if result == 'None':
            result = 'None'
    except Exception:
        result = 'None'
    return render_template('process/updMenuListSect.html', result=result, type=type)

@bp.route('/<id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    try:
        faq = fetch_one_qa(id, 'intent', g.user['username'], 'username', qna, qna_int)
        if faq:
            result = faq
        else:
            result = 'None'
    except Exception:
        result = 'None'
    finally:
        return render_template('process/update.html', result=result)

@bp.route('/updateFAQ', methods=['POST'])
@login_required
def updateFAQ():
    original_intent = None
    intent = None
    questions = []
    answer = None
    message = None
    # user_qnas = []

    data = json.loads(request.form["formData"])
    original_intent = json.loads(request.form["original_intent"])
    original_qns = json.loads(request.form["original_qns"])
    faq_id = json.loads(request.form["faq_id"])
    video_id = json.loads(request.form["video_id"])

    if request.method == 'POST':
        # print('GO')
        data_size = len(data)
        # This for loop retrieves all created FAQ data from form data
        for i in range(data_size):
            # This condition gets FAQ intent
            if i == 0:
                intent = data[i]
            elif i == (data_size - 1):
                answer = data[i]
            elif i >= 1 and i != (data_size - 1):
                questions.append(data[i])
        if video_id == "None":
            video_id = None
        # print('GO')

        if not intent:
            message = 'Intent is required.'
        for question in questions:
            if "/n" in question or not question:
                message = 'All questions are required.'
        if not answer:
            message = 'Answer is required.'
        # print('GO')

        # To check if intent arleady exists in database
        if check_intent(g.user['user_id'], faq_id, intent, qna_int):
            if intent != original_intent:
                # print(intent + ' same as ' + original_intent)
                message = 'Intent already Exists!'
        # print('GO')

        if message is None:
            # index_set array is used to store the rows that have a duplicate question
            index_set = []
            # indexes array is used to store the row index of rows that have a duplicate question
            indexes = []

            # To check Question exists, and get sets of same Question. Example: 1,3,5 and 2,4 is the same
            for question in questions:
                x = questions
                # x and xs in this lambda expression is the function arguments(parameters) of get_indexes as seen below
                get_indexes = lambda x, xs: [i for (y, i) in zip(xs, range(len(xs))) if x == y]
                # In this if condition, question is lambda expression 'x' and x is lambda expression 'xs'
                # The output of the get_indexes is an array that contains variables as seen in the example below
                # E.g. Output -> [ '<question>', '<index position of qn in questions array>']
                if len(get_indexes(question, x)) > 1 and get_indexes(question, x) not in index_set:
                    # print('Duplicate found!!!!!!!!!!!!!')
                    index_set.append(get_indexes(question, x))
                    # print('Appended to set!!')

                if check_qa(g.user['user_id'], faq_id, question, qna, qna_int):
                    # print('question not equals to original question')
                    message = 'Question "' + question + '" already Exists!'
                    break

            # print('Exit from for loop!')
            # To extract the indexes and display as error.
            if index_set:
                # print('Start printing duplicate question rows')
                # print('Duplicate questions detected!')
                for set in index_set:
                    for index in set:
                        indexes.append(index + 1)

                message = "Duplicate Questions! Rows: "
                indexes.sort()
                for index in indexes:
                    if not index == indexes[-1]:
                        message += str(index) + ", "
                    else:
                        message += str(index)

            # print(message)
            if message is None:
                # Edit FAQs in MongoDB
                faq_type = fetch_qa_type(original_intent, 'intent', g.user['username'], 'username', qna_int)
                # print(faq_type)
                if faq_type == "Draft":
                    # print('start mongo update')
                    result = del_qa(original_intent, g.user['user_id'], faq_type, qna, qna_int)
                    if result:
                        result = add_qa(g.user['user_id'], g.user['username'], intent, questions, answer, qna, qna_int,
                                        faq_type, original_intent, video_id, 'Edit', False, faq_id)
                        if result:
                            message = 'Saved'
                        else:
                            message = 'Failed to update FAQ'
                    else:
                        message = 'Failed to update FAQ'
                elif faq_type == "Saved":
                    result = del_qa(original_intent, g.user['user_id'], faq_type, qna, qna_int)
                    if result:
                        result = add_qa(g.user['user_id'], g.user['username'], intent, questions, answer, qna, qna_int,
                                        'Draft', original_intent, video_id, 'Edit', False, faq_id)
                        if result:
                            message = 'Saved'
                        else:
                            message = 'Failed to update FAQ'
                    else:
                        message = 'Failed to update FAQ'
        # If message = "Saved", it automatically goes to href from AJAX codes in ajaxScript.js
        return Response(json.dumps(message), mimetype='application/json')

@bp.route('/delete', methods=['POST'])
@login_required
def delete():
    message = None
    req_intent = request.form['intent']
    qaType = fetch_qa_type(req_intent, 'intent', g.user['username'], 'username', qna_int)
    username = g.user['username']
    success = None

    if qaType == "Draft":
        qa = fetch_one_qa(req_intent, 'intent', username, 'username', qna, qna_int)
        print(qa)
        if qa["intent"] != "None":
            result = delete_intent([qa['intent']], g.user['clientAlias'], g.user['bot_id'])
            if result:
                success = del_qa(req_intent, g.user['user_id'], qaType, qna, qna_int)
            if success:
                if qaType == "Draft":
                    message = 'FAQ deleted!'
                else:
                    message = 'Failed to delete FAQ, please contact customer support.'
            else:
                message = 'FAQ deletion unsuccessful, please contact customer support.'
        else:
            success = del_qa(req_intent, g.user['user_id'], qaType, qna, qna_int)
            if success:
                message = 'FAQ deleted!'
            else:
                message = 'Failed to delete FAQ, please contact customer support.'

    elif qaType == "Saved":
        qa = fetch_one_qa(req_intent, 'intent', username, 'username', qna, qna_int)
        intent = qa['intent']
        qns = qa['questions']
        questions = []
        for qn in qns:
            questions.append(qn['question'])
        answer = qa['answer']
        if len(qa) == 6:
            videoId = qa['videoId']
        else:
            videoId = None
        success = del_qa(req_intent, g.user['user_id'], qaType, qna, qna_int)
        if success:
            success = add_qa(g.user["user_id"], username, intent, questions, answer, qna, qna_int, "Draft", qa['prevAka'], videoId, 'Delete', False)
            if success:
                if qaType == "Saved":
                    message = 'FAQ moved to Drafted!'
            else:
                message = 'Failed to delete FAQ, please contact customer support.'
        else:
            message = 'FAQ deletion unsuccessful, please contact customer support.'

    return Response(json.dumps(message), mimetype='application/json')

@bp.route('/<action>/preview', methods=('GET', 'POST'))
@login_required
def preview(action):
    session.pop('_flashes', None)
    return render_template('process/preview.html', action=action)

#For testing aboutus
@bp.route('/aboutUs')
def aboutUs():
    session.pop('_flashes', None)
    return render_template('process/aboutUs.html')

#For testing instruction
@bp.route('/userGuide')
@login_required
def userGuide():
    session.pop('_flashes', None)
    return render_template('process/userGuide.html')

#For testing instruction
@bp.route('/gtwbManual')
@login_required
def gtwbManual():
    session.pop('_flashes', None)
    return render_template('process/gtwbManual.html')

#For testing rulesFAQ
@bp.route('/rules')
@login_required
def rulesFAQ():
    session.pop('_flashes', None)
    return render_template('process/rulesFAQ.html')

#Adminstration web pages
@bp.route('/admin', methods=('GET','POST'))
@login_required
def admin():
    session.pop('_flashes', None)
    createMessage = None
    if session.get("createMessage"):
        createMessage = session.get("createMessage")
        session.pop('createMessage', None)
    return render_template('process/admin.html', createMessage=createMessage)