import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for, jsonify, Response
)
from werkzeug.security import check_password_hash, generate_password_hash

import json
from instance.config import app_config
from pymongo import MongoClient
from util_funcs import user_exists, new_user, fetch_user, fetch_accounts, change_password, clientname_exist, user_id_exist, bot_id_exist, update_user

import http

import time

bp = Blueprint('auth', __name__, url_prefix='/auth')
mongo = MongoClient(app_config["development"].MONGODB_URL)
qna = mongo.get_database()["gtrobqa"]
uinfo = mongo.get_database()["gtrobtest"]

def admin_required(view):
    @functools.wraps(view)
    def wrapper(**kwargs):
        if g.user['Role'] != 'Admin':
            return redirect(url_for('auth.login'))

        return view(**kwargs)

    return wrapper

@bp.route('/register', methods=('GET', 'POST'))
@admin_required
def register():
    username = ""
    password = ""
    client_name = ""
    client_alias = ""
    user_id = ""
    bot_id = ""

    if request.method == 'POST':
        role = request.form['role']
        error = None
        if role == "General":
            username = request.form['username']
            password = request.form['password']
            client_name = request.form['clientName']
            client_alias = request.form['clientAlias']
            user_id = request.form['user_id']
            bot_id = request.form['bot_id']

            if user_exists(username, uinfo):
                error = "Username exist"
            # elif clientname_exist(client_name, uinfo):
            #     error = "Client already has account"
            elif user_id_exist(user_id, uinfo):
                error = "User ID already used"
            # elif bot_id_exist(bot_id, uinfo):
            #     error = "Bot ID already used"
            else:
                if new_user(role, username, generate_password_hash(password), uinfo, client_name, client_alias, user_id, bot_id):
                    session["createMessage"] = "Successfully created "+username
                    return redirect(url_for('process.admin'))
                else:
                    error = "Save Error"

        elif role == "Admin":
            username = request.form['username']
            password = request.form['password']

            if not user_exists(username, uinfo):
                if new_user(role, username, generate_password_hash(password), uinfo):
                    session["createMessage"] = "Successfully created " + username
                    return redirect(url_for('process.admin'))
                else:
                    error = "Save Error"
            else:
                error = "Username exist"

        if error is not None:
            flash(error)

    registerAcc = {'username': username, 'password': password, 'client_name': client_name, 'client_alias': client_alias,
                   'user_id': user_id, 'bot_id': bot_id}

    return render_template('auth/register.html', registerAcc=registerAcc)


@bp.route('/login', methods=('GET', 'POST'))
def login():
    error = None
    if request.method == 'POST':
        if 'login' in request.form.keys():
            username = request.form['username']
            password = request.form['password']
            user = fetch_user(username, 'username', uinfo)

            if user is None:
                error = 'Incorrect username.'
            elif not check_password_hash(user['password'], password):
                error = 'Incorrect password.'

            if error is None:
                session.clear()
                session.pop('_flashes', None)
                session['user_id'] = user['_id']
                session['Role'] = user['Role']
                session.permanent = True
                # print(user)
                #print('my role is ' + user['Role'])
                if user['Role'] == "General":
                    return redirect(url_for('process.index'))
                else:
                    return redirect(url_for('process.admin'))
        elif 'register' in request.form.keys():
            username = request.form['email']
            password = request.form['password']
            if not username:
                error = 'Username is required.'
            elif not password:
                error = 'Password is required.'
            elif user_exists(username, uinfo):
                error = 'User {} is already registered.'.format(username)

            if error is None:
                flash('User successfully created!' if new_user(username, generate_password_hash(password), uinfo) else 'Failed to create user!')
                return redirect(url_for('process.index'))
        flash(error)

    return render_template('auth/login.html')

@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        g.user = fetch_user(user_id,'_id',uinfo)

@bp.route('/logout')
def logout():
    session.pop('_flashes', None)
    session.clear()
    return redirect(url_for('index'))

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))
        return view(**kwargs)
    return wrapped_view

#Admin page for changing account passwords
@bp.route('/userList')
@login_required
def userList():
    #On page load, display user accounts
    result = fetch_accounts('General','Role',uinfo)
    updateMessage = None
    if session.get("updateMessage"):
        updateMessage = session.get("updateMessage")
        session.pop('updateMessage', None)

    #Remove current logged in user from list
    username = g.user['username']
    for acc in result:
        if acc['username'] == username:
            result.remove(acc)

    session.pop('_flashes', None)
    return render_template('auth/updUser.html', result=result, updateMessage=updateMessage)

@bp.route('/refreshUserList', methods=['POST'])
@login_required
def grabUserList():
    role = request.form["acctType"]
    result = fetch_accounts(role,'Role',uinfo)
    updateMessage = None

    return render_template('auth/updUserList.html', result=result, updateMessage=updateMessage)

# #This route is for html button to trigger python code
# @bp.route('/getUsers')
# def user_list(request):
#     request.POST['some_data_from_page']
#
#     return http.HttpResponses("Yolo")

#General User page for changing account passwords
@bp.route('/changePass', methods=('GET', 'POST'))
@login_required
def changePass():
    username = json.loads(request.form["modUser"])
    if username:
        session['modUser'] = username
        return Response(json.dumps("True"), mimetype='application/json')

@bp.route('/updateUserPass', methods=('GET', 'POST'))
@login_required
def updateUserPass():
    username = session.get("modUser")
    session.pop('modUser', None)

    if request.method == 'POST':
        username = request.form['username']

        if g.user['Role'] == "General":
            current_password = request.form['currentPassword']

        new_password = request.form['newPassword']
        confirm_password = request.form['confirmPassword']
        error = None

        if not new_password == confirm_password:
            error = 'Password does not match'
        elif g.user['Role'] == "General":
            if new_password == current_password:
                error = 'New password is the same'

        if error is not None:
            flash(error)
        elif g.user['Role'] == "General":
            if not check_password_hash(g.user['password'], current_password):
                error = 'Incorrect password'
                flash(error)

        if error is None:
            if not change_password("$set", username, "username", generate_password_hash(new_password), "password", uinfo):
                flash('Save error!')
            else:
                session.pop('_flashes', None)
                if g.user['Role'] == "General":
                    session["passwordMessage"] = "Password change successful"
                    return redirect(url_for('index'))
                else:
                    #Go to successful page
                    session["updateMessage"] = "Password change complete for " + username
                    return redirect(url_for('auth.userList'))
    return render_template('auth/changePass.html', username=username)

@bp.route('/<username>/modifyAccount', methods=('GET', 'POST'))
@admin_required
def modifyAccount(username):
    if request.method == 'POST':
        # role = request.form['role']       // Future can change roles, now is only general can use
        role = "General"
        original_user = fetch_user(username, 'username', uinfo)
        error = None
        if role == "General":
            client_name = request.form['clientName']
            client_alias = request.form['clientAlias']
            user_id = request.form['user_id']
            bot_id = request.form['bot_id']

            # if clientname_exist(client_name, uinfo) and client_name != modifable_user["clientName"]:
            #     error = "Client already has account"
            # elif bot_id_exist(bot_id, uinfo) and bot_id != modifable_user["bot_id"]:
            #     error = "Bot ID already used"
            if user_id_exist(user_id, uinfo) and user_id != original_user["user_id"]:
                error = "User ID already used"
            else:
                if update_user(original_user, uinfo, role, client_name, client_alias, user_id, bot_id, qna):
                    session["updateMessage"] = "Modification complete for "+username
                    return redirect(url_for('auth.userList'))
                else:
                    error = "Save Error"
        # elif role == "Admin":
        if error is not None:
            repeat = True
            flash(error)

    if 'repeat' in locals():
        modifiable_user = {'Role': role, 'clientName': client_name, 'clientAlias': client_alias, 'user_id': user_id, 'bot_id': bot_id}
    else:
        repeat = False
        modifiable_user = fetch_user(username, 'username', uinfo)

    # print(modifiable_user)
    return render_template('auth/modifyAccount.html', mod_user=modifiable_user, repeat=repeat)

