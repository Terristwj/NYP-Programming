from google.appengine.ext import vendor
vendor.add('lib')