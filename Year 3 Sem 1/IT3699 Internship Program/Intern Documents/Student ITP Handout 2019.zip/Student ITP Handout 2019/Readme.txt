1. Student Internship Guide.pdf
 - Read this to know what's going on for ITP
 - "Annex 3: Templates for ITP Poster" is for creation of ITP poster later for submission
 - "Annex 5: Student Performance Grading Form" to be printed at the end of ITP for IIM to grade

2. Student Internship Report.docx
- A template for you to prepare your ITP Final report to be submitted to IIM for grading at the end of ITP.

3. Internship_Company Feedback.docx
- To be printed and given to IIM to give feedback at the end of ITP

4. Student_ITP_eLog.pptx
- For doing daily reflection. 
- Need to add in IIM contact so that 
  + IIM can login to grade and comment
  + SIM will also login to check your reflection and may add in comment.
  + These reflections are one of the items to be evaluated durign grading.

Deliverables at the end of ITP to be submitted to SIM
- ITP poster (softcopy to be submitted through Blackboard, hardcopy to be submitted to SIM)
  (See 1. Student Internship Guide.pdf)
- Performance Grading Form with IIM's grading and signature
  (See 1. Student Internship Guide.pdf)
- Internship report with  OVERALL REPORT GRADING as front page with IIM's grading and signature
  (See 2. Student Internship Report.docx)
- Company Feedback Form
  (See 3. Internship_Company Feedback.docx)