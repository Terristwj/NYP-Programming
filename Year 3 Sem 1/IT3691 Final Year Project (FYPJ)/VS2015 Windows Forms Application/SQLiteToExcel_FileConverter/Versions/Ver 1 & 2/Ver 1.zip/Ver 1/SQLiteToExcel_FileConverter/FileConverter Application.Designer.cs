﻿namespace SQLiteToExcel_FileConverter
{
    partial class FileConverter_Application
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.testConnect = new System.Windows.Forms.Button();
            this.generateExcel = new System.Windows.Forms.Button();
            this.uploadSQLite = new System.Windows.Forms.Button();
            this.fileName = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // testConnect
            // 
            this.testConnect.Location = new System.Drawing.Point(85, 80);
            this.testConnect.Name = "testConnect";
            this.testConnect.Size = new System.Drawing.Size(94, 23);
            this.testConnect.TabIndex = 0;
            this.testConnect.Text = "Test Connection";
            this.testConnect.UseVisualStyleBackColor = true;
            this.testConnect.Click += new System.EventHandler(this.testConnect_Click);
            // 
            // generateExcel
            // 
            this.generateExcel.Location = new System.Drawing.Point(77, 143);
            this.generateExcel.Name = "generateExcel";
            this.generateExcel.Size = new System.Drawing.Size(111, 23);
            this.generateExcel.TabIndex = 1;
            this.generateExcel.Text = "Generate Excel File";
            this.generateExcel.UseVisualStyleBackColor = true;
            this.generateExcel.Click += new System.EventHandler(this.generateExcel_Click);
            // 
            // uploadSQLite
            // 
            this.uploadSQLite.Location = new System.Drawing.Point(12, 12);
            this.uploadSQLite.Name = "uploadSQLite";
            this.uploadSQLite.Size = new System.Drawing.Size(103, 23);
            this.uploadSQLite.TabIndex = 2;
            this.uploadSQLite.Text = "Upload SQLite File";
            this.uploadSQLite.UseVisualStyleBackColor = true;
            this.uploadSQLite.Click += new System.EventHandler(this.uploadSQLite_Click);
            // 
            // fileName
            // 
            this.fileName.AutoSize = true;
            this.fileName.Location = new System.Drawing.Point(15, 41);
            this.fileName.Name = "fileName";
            this.fileName.Size = new System.Drawing.Size(26, 13);
            this.fileName.TabIndex = 3;
            this.fileName.Text = "File:";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(18, 172);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(239, 23);
            this.progressBar1.TabIndex = 4;
            // 
            // FileConverter_Application
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 233);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.fileName);
            this.Controls.Add(this.uploadSQLite);
            this.Controls.Add(this.generateExcel);
            this.Controls.Add(this.testConnect);
            this.Name = "FileConverter_Application";
            this.Text = "FileConverter Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button testConnect;
        private System.Windows.Forms.Button generateExcel;
        private System.Windows.Forms.Button uploadSQLite;
        private System.Windows.Forms.Label fileName;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}