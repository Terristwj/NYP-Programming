﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Reference for Excel
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
// Reference for SQLite
using System.Data.SQLite;

// File Name Without Extension
using System.IO;
// ArrayList
using System.Collections;

namespace SQLiteToExcel_FileConverter
{
    public partial class FileConverter_Application : Form
    {
        public static SQLiteConnection sqlite_conn = null;
        public static ArrayList table_names = null;

        public FileConverter_Application()
        {
            InitializeComponent();
        }

        private void uploadSQLite_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Database Files | *.mdf; *.db";         // File types, that will be allowed to upload
            dialog.Multiselect = false;                             // Allow/deny user to upload more than one file at a time
            if (dialog.ShowDialog() == DialogResult.OK)             // If user clicked OK
            {
                string upload_FullPath = dialog.FileName;

                String path = dialog.SafeFileName;                          // Get name of file
                fileName.Text = path;                                       // Set label text

                // Take file name without extension
                string fileName_noExtension = Path.GetFileNameWithoutExtension(dialog.SafeFileName);
                tb_newName.Text = fileName_noExtension;

                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=" + upload_FullPath + ";Version=3;New=False;Compress=True;");

                // Create a new set of table names:
                set_table_names();
            }
        }

        private void testConnect_Click(object sender, EventArgs e)
        {
            if (sqlite_conn == null)
            {
                MessageBox.Show("Upload a database first!");
            }
            else
            {
                DatabaseView dbView = new DatabaseView();
                dbView.ShowDialog();
            }
        }

        private void generateExcel_Click(object sender, EventArgs e)
        {
            if (sqlite_conn == null)
            {
                MessageBox.Show("Upload a database first!");
            }
            else
            {
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed!!");
                    return;
                }

                // Starts progress bars, or resets too
                start_progressBar();                      // Prog = 4

                ArrayList dataSet_table = get_databaseValues();
                update_progressBar(15);                 // Prog = 19

                //// Debugging Code, Uncomment below to debug

                //// Controls
                //int table_test = 1;
                //int col_test = 2;
                //int row_test = 4;

                //// Output
                //ArrayList anotherData = (ArrayList)dataSet_table[table_test - 1];
                //ArrayList anotherData2 = (ArrayList)anotherData[col_test - 1];
                //MessageBox.Show(anotherData2[row_test - 1].ToString());


                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                xlWorkBook = xlApp.Workbooks.Add(misValue);
                update_progressBar(6);                  // Prog = 25

                // Add worksheets
                int tableCount = get_table_count();
                for (int i = 1; i < tableCount; i++)
                {
                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.Add();     // Create new sheet
                }
                
                update_progressBar(10);                 // Prog = 45
                // Formula for later usage
                int progress_afterExcel_algorithm = 80;
                int progress_per_table = (progress_afterExcel_algorithm - getCurrent_progressBar()) / tableCount;

                // Leave it, else error
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                // Fill in eacg worksheet
                int worksheet_no = 1, col, row;
                foreach (string table_name in table_names)
                {
                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(worksheet_no);
                    xlWorkSheet.Name = table_name;

                    ArrayList dataSet = new ArrayList();
                    dataSet.Add(dataSet_table[worksheet_no-1]);

                    foreach (ArrayList dataCol in dataSet)
                    {
                        row = 1;
                        foreach (ArrayList dataRow in dataCol)
                        {
                            col = 1;
                            foreach (string data in dataRow)
                            {
                                xlWorkSheet.Cells[col, row] = data;
                                ++col;
                            }
                            ++row;
                        }
                        update_progressBar(progress_per_table);    // Prog = 45 + (35 / Table Number)
                    }
                    ++worksheet_no;
                }
                set_progressBar(progress_afterExcel_algorithm);     // Prog = 80
               
                try
                {
                    // Save to beside the application folder, file name is custom
                    xlWorkBook.SaveAs(Environment.CurrentDirectory + "\\..\\..\\..\\" + tb_newName.Text + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    xlWorkBook.Close(true, misValue, misValue);
                    xlApp.Quit();
                    update_progressBar(10);                             // Prog = 90

                    Marshal.ReleaseComObject(xlWorkSheet);
                    Marshal.ReleaseComObject(xlWorkBook);
                    Marshal.ReleaseComObject(xlApp);
                    update_progressBar(10);                         // Prog = 100

                    MessageBox.Show("Excel file created , you can find the file ");
                }
                catch (COMException ex)
                {
                    MessageBox.Show(ex.Message);
                    MessageBox.Show("Action Cancelled");        // For when file already exist and they click "No", or "Cancel"
                }
                finally
                {
                    set_progressBar(0);     // Reset to 0
                }
            }
        }

        private void set_table_names()
        {
            // Resets Array
            table_names = new ArrayList();
            try
            {
                sqlite_conn.Open();
                if (sqlite_conn.State == ConnectionState.Open)
                {
                    DataTable schema = sqlite_conn.GetSchema("Tables");

                    // Get table names and fills in
                    foreach (DataRow row in schema.Rows)
                    {
                        string tablename = (string)row[2];
                        table_names.Add(tablename);
                    }
                    table_names.Sort();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlite_conn.Close();
            }
        }

        private int get_table_count()
        {
            int num = table_names.Count;
            return num;
        }

        private ArrayList get_databaseValues()
        {
            ArrayList myArray = null;
            try
            {
                sqlite_conn.Open();
                if (sqlite_conn.State == ConnectionState.Open)
                {
                    SQLiteCommand sqlite_cmd;
                    SQLiteDataReader sqlite_dr;

                    ArrayList new_table = new ArrayList();

                    foreach (string table_name in table_names)
                    {
                        // My variables to store the data
                        ArrayList columnNames = new ArrayList();
                        ArrayList columnData;

                        ArrayList new_tableCol = new ArrayList();
                        ArrayList new_tableColRow;

                        // Prep for Retrieve column Names
                        string[] restrictionsColumns = new string[4];
                        restrictionsColumns[2] = table_name;
                        DataTable schemaColumns = sqlite_conn.GetSchema("Columns", restrictionsColumns);

                        // Prep for Retrieve each column's dataset
                        sqlite_cmd = sqlite_conn.CreateCommand();
                        sqlite_cmd.CommandText = "SELECT * FROM '" + table_name + "'";

                        foreach (DataRow rowColumn in schemaColumns.Rows)
                        {
                            // Retrieve column Names
                            new_tableColRow = new ArrayList();
                            string columnName = rowColumn[3].ToString();
                            new_tableColRow.Add(columnName);


                            // Retrieve each column's dataset
                            columnData = new ArrayList();
                            sqlite_dr = sqlite_cmd.ExecuteReader();
                            while (sqlite_dr.Read())
                            {
                                string data = Convert.ToString(sqlite_dr[columnName]);
                                new_tableColRow.Add(data);
                            }
                            sqlite_dr.Close();

                            new_tableCol.Add(new_tableColRow);
                        }

                        new_table.Add(new_tableCol);
                    }
                    myArray = new_table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlite_conn.Close();
            }

            return myArray;
        }

        private void start_progressBar()
        {
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;
            progressBar1.Value = 0;

            update_progressBar(4);
        }
        private int getCurrent_progressBar()
        {
            return progressBar1.Value;
        }

        private void set_progressBar(int fixedProgress)
        {
            progressBar1.Value = fixedProgress;
        }

        private void update_progressBar(int addProgress)
        {
            progressBar1.Step = addProgress;
            progressBar1.PerformStep();
        }
    }
}
