﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Reference for SQLite
using System.Data.SQLite;
// ArrayList
using System.Collections;

namespace SQLiteToExcel_FileConverter
{
    public partial class DatabaseView : Form
    {
        // Declared borrowed variables
        SQLiteConnection sqlite_conn = null;
        static ArrayList table_names = null;
        string current_table = null;

        // Control first time load
        Boolean dataLoaded = false;

        public DatabaseView()
        {
            InitializeComponent();
        }

        private void DatabaseView_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            sqlite_conn = FileConverter_Application.sqlite_conn;
            table_names = FileConverter_Application.table_names;
            current_table = table_names[0].ToString();

            // Set drop-down-list items
            foreach (string table_name in table_names)
            {
                ddl_tableNames.Items.Add(table_name);
            }

            // Set first item displayed
            ddl_tableNames.Text = current_table;
            
            populateDataGrid(current_table);
            dataLoaded = true;
        }

        private void ddl_tableNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dataLoaded)  // Required to prevent first-time load error
            {
                current_table = ddl_tableNames.SelectedItem.ToString();
                populateDataGrid(current_table);
            }
        }

        private void populateDataGrid(string current_table)
        {
            try
            {
                sqlite_conn.Open();
                if (sqlite_conn.State == ConnectionState.Open)
                {
                    string sqlite_cmd = "SELECT * FROM '" + current_table + "'";
                    SQLiteDataAdapter sqlite_da = new SQLiteDataAdapter(sqlite_cmd, sqlite_conn);
                    DataTable dt = new DataTable();
                    sqlite_da.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlite_conn.Close();
            }
        }
    }
}
