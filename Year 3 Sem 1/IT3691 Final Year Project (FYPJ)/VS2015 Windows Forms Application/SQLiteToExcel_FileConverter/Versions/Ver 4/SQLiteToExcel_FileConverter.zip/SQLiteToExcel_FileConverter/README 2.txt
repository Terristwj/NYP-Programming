
This project is fully functional with some limitations.

1. It can only convert SQLite databases as of now.

2. This project folder MUST be somewhere easily accessable as there is a link limit.

Eg. 
C:\Users\TheUser\Desktop\FYPJ - Quick Access\FYPJ 2019 Period 2 - For Submission\Source Codes\VS2015 Windows Forms Application\SQLiteToExcel_FileConverter

Is too long and will create a "Save error".
Solution is to place somewhere short like "C:\Users\Terris Tan\Desktop\VS2015 Windows Forms Application\SQLiteToExcel_FileConverter"