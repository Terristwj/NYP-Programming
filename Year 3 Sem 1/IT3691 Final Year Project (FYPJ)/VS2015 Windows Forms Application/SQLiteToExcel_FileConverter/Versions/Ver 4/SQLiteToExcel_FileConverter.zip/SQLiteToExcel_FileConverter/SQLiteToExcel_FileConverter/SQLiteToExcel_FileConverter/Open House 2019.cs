﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Reference for SQLite
using System.Data.SQLite;
// ArrayList
using System.Collections;

namespace SQLiteToExcel_FileConverter
{
    public partial class Open_House_2019 : Form
    {
        // Declared borrowed variables
        SQLiteConnection sqlite_conn = null;
        static ArrayList table_names = null;
        static ArrayList dataSet_table = null;

        // Track table
        string current_table = null;
        // Control first time load
        Boolean dataLoaded = false;

        public Open_House_2019()
        {
            InitializeComponent();
        }

        private void Open_House_2019_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            sqlite_conn = FileConverter_Application.sqlite_conn;
            table_names = FileConverter_Application.table_names;
            dataSet_table = FileConverter_Application.dataSet_table;

            current_table = table_names[0].ToString();

            // Load data into controls
            populate_dllTables();
            populate_ddlColumns();
            display_tableColumnList();
            dataLoaded = true;
        }

        private void populate_dllTables()
        {
            // Set drop-down-list items
            foreach (string table_name in table_names)
            {
                ddl_tableNames.Items.Add(table_name);
            }
            // Set first item displayed
            ddl_tableNames.Text = current_table;
        }

        private void populate_ddlColumns()
        {
            ddl_columnNames.Items.Clear();

            // Algorithm to fill in drop down list for column names
            //------------------------------------------------------//
            int table_no = 1, col, row;
            foreach (string table_name in table_names)
            {
                if (table_name == current_table)        // Taking the data set from Main_App, selectively take the table then columns
                {
                    ArrayList dataSet = new ArrayList();
                    dataSet.Add(dataSet_table[table_no - 1]);

                    foreach (ArrayList dataCol in dataSet)
                    {
                        row = 1;
                        foreach (ArrayList dataRow in dataCol)
                        {
                            col = 1;
                            foreach (string data in dataRow)
                            {
                                if (col == 1)
                                {
                                    ddl_columnNames.Items.Add(data);    // Add the column
                                    if (row == 1)
                                        ddl_columnNames.Text = data;    // Replace name to display first item, ONLY occurs when change table or first time load
                                }
                                ++col;
                            }
                            ++row;
                        }
                    }
                }
                ++table_no;
            }
            //------------------------------------------------------//
        }

        private void ddl_tableNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dataLoaded)  // Required to prevent first-time load error
            {
                current_table = ddl_tableNames.Text;
                populate_ddlColumns();
            }
        }

        private void ddl_columnNames_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Control for Add/Remove button
        // If new item      --> Add     (Add new row)
        // If existing item --> Delete  (Empty the row, NOT ACTUALLY DELETE)
        private void addRemove_Click(object sender, EventArgs e)
        {
            string table = ddl_tableNames.Text;
            string column = ddl_columnNames.Text;

            string[] data = new string[2] { table, column };
            string itemStr = "[" + data[0] + ", " + data[1] + "]";

            int index = 1;

            // Algorithm to find an index for delete
            foreach (string[] dataItem in FileConverter_Application.custFeat_OH2019_listData)
            {
                string item = dataItem[1];
                if (item == itemStr)
                    break;
                ++index;
            }
            try                                 // Deletes the row
            {
                population_tableColumnList(index, data);
                FileConverter_Application.custFeat_OH2019[index] = null;
            }
            catch(Exception ex)                 // If cannot delete, tells the program that is an Add row
            {
                population_tableColumnList(index, data, true);
                index = FileConverter_Application.custFeat_OH2019_listData.Count;
                FileConverter_Application.custFeat_OH2019.Add(index, data);
            }
        }

        private void population_tableColumnList(int index, string[] data, Boolean add = false)
        {
            // Tidy data into a proper dataItems
            string item = "[" + data[0] + ", " + data[1] + "]";
            string[] dataItem = new string[2] { index.ToString(), item };

            // Depending on called variable, Add/Remove the dataItem
            if (add == true)
                FileConverter_Application.custFeat_OH2019_listData.Add(dataItem);
            else
            {
                dataItem = new string[2] { index.ToString(), null };
                FileConverter_Application.custFeat_OH2019_listData[index-1] = dataItem;
            }

            display_tableColumnList();
        }

        private void display_tableColumnList()      // Display method for the list of tableColumns label. Data used are from Main_App
        {
            lb_tableColumnList.Text = "";

            FileConverter_Application.custFeat_OH2019_firstData = true;     // Check if is first data. First data have no ", " while others have.
            foreach (string[] dataItem2 in FileConverter_Application.custFeat_OH2019_listData)
            {
                if (dataItem2[1] != null)           // Because Delete is not actaully delete instead empties. So must check if null
                {
                    string itemStr = dataItem2[1];
                    if (FileConverter_Application.custFeat_OH2019_firstData) 
                    {
                        lb_tableColumnList.Text = itemStr;
                        FileConverter_Application.custFeat_OH2019_firstData = false;
                    }
                    else
                        lb_tableColumnList.Text += ", " + itemStr;
                }
            }
        }
    }
}
