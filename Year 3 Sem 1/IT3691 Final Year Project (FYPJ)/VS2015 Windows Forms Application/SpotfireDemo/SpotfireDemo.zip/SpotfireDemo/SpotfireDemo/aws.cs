﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// SQL client
using System.Data.SqlClient;
// ArrayList
using System.Collections;
// Convert String To Float
using System.Globalization;

namespace SpotfireDemo
{
    public partial class aws : UserControl
    {
        // Declared borrowed variables
        SqlConnection conn = null;
        ArrayList table_names = null;
        string current_table = null;
        string language = null;

        // For btn_computeSales
        float totalSales = -1;      // Store the amound of sales genererated
        int juiceSold = -1;       // Store the number of juice sold

        // Langauges Supported
        string[] language_supported = { "EN", "CH" };

        public aws()
        {
            InitializeComponent();
        }

        private void aws_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            conn = SpotfireDemo.conn;
            table_names = SpotfireDemo.table_names;
            current_table = table_names[0].ToString();
            language = SpotfireDemo.language;

            // Check if current language is supported
            checkCurrentLanguage();

            // Display fruits
            populate_flowLayoutPanel(current_table);
            populate_buttonControls();
        }


        //
        //  Language Controls
        //
        //------------------------Start---------------------------//
        private void checkCurrentLanguage()                                 // Checks if the current language is supported
        {
            if (!(Array.IndexOf(language_supported, language) > -1))        // If not supported, reset to "EN"
                language = "EN";                                            // NOTE: After loading, immediately go to SpotfireDemo
        }                                                                   //       to reload the entire "EN" version

        private void populate_buttonControls()
        {
            if (language.Equals("EN"))
            {
                Sales_Title.Text = "Sales For The Day";
                controls_Title.Text = "Controls";

                btn_apple_plus5.Text = "Add 5 Apple Juice";
                btn_pear_plus5.Text = "Add 5 Pear Juice";
                btn_orange_plus5.Text = "Add 5 Orange Juice";
                btn_kiwi_plus5.Text = "Add 5 Kiwi Juice";
                btn_watermelon_plus5.Text = "Add 5 Watermelon Juice";
                btn_dragonfruit_plus5.Text = "Add 5 Dragon Fruit Juice";
                btn_banana_plus5.Text = "Add 5 Banana Juice";
                btn_lemon_plus5.Text = "Add 5 Lemon Juice";
                btn_mango_plus5.Text = "Add 5 Mango Juice";
                btn_computeSales.Text = "Compute Sales";
                btn_resetDemo.Text = "Reset Demo";
            }
            else if (language.Equals("CH"))
            {
                Sales_Title.Text = "今天销售";
                controls_Title.Text = "管制";

                btn_apple_plus5.Text = "加 5 苹果汁";
                btn_pear_plus5.Text = "加 5 梨汁";
                btn_orange_plus5.Text = "加 5 橙汁";
                btn_kiwi_plus5.Text = "加 5 猕猴桃汁";
                btn_watermelon_plus5.Text = "加 5 西瓜汁";
                btn_dragonfruit_plus5.Text = "加 5 火龙果汁";
                btn_banana_plus5.Text = "加 5 香蕉汁";
                btn_lemon_plus5.Text = "加 5 柠檬汁";
                btn_mango_plus5.Text = "加 5 芒果汁";
                btn_computeSales.Text = "计算销售";
                btn_resetDemo.Text = "重启演示";
            }
        }


        //
        //  Display Controls
        //
        //------------------------Start---------------------------//
        private void populate_flowLayoutPanel(string current_table)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)                         // Retrieve data
                {
                    string cmd = "SELECT * FROM " + current_table + "";
                    SqlDataAdapter da = new SqlDataAdapter(cmd, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    flowLayoutPanel1.Controls.Clear();
                    foreach (DataRow row in dt.Rows)                        // Foreach fruit, create an item frame
                    {
                        // Picture
                        PictureBox juicePic = new PictureBox();
                        juicePic.BackgroundImageLayout = ImageLayout.Zoom;
                        juicePic.BorderStyle = BorderStyle.FixedSingle;
                        juicePic.Dock = DockStyle.Top;
                        juicePic.Size = new Size(183, 150);

                        // Sales
                        Button juiceSale = new Button();
                        juiceSale.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
                        juiceSale.Font = new Font("Microsoft Sans Serif", 16);
                        juiceSale.FlatStyle = FlatStyle.Flat;

                        if (language.Equals("EN"))                              // Language
                            juiceSale.Text = "Sold: ";
                        else if (language.Equals("CH"))
                            juiceSale.Text = "卖了: ";

                        juiceSale.Dock = DockStyle.Bottom;
                        juiceSale.Size = new Size(183, 64);

                        // Add in image
                        int columnIndex = 0;
                        columnIndex = get_columnIndex(dt, "imageUrl");
                        juicePic.BackgroundImage = Image.FromFile("../.././Images/AWS/" + row[columnIndex].ToString());

                        // Add in data
                        columnIndex = get_columnIndex(dt, "sale_count");
                        juiceSale.Text += row[columnIndex].ToString();
                        
                        // Item frame
                        Panel juiceItem = new Panel();
                        juiceItem.BorderStyle = BorderStyle.FixedSingle;
                        juiceItem.Size = new Size(185, 216);

                        // Add everything into item frame, then into the layout
                        juiceItem.Controls.Add(juicePic);
                        juiceItem.Controls.Add(juiceSale);
                        flowLayoutPanel1.Controls.Add(juiceItem);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private int get_columnIndex(DataTable dt, string columnName, int counter = 0)           // Reusuable counter for column index
        {
            foreach (DataColumn col in dt.Columns)
            {
                if (col.ColumnName.ToString().Equals(columnName))
                {
                    break;
                }
                counter++;
            }
            return counter;
        }

        private void display_computeSale(float totalSales, int juiceSold)
        {
            ////////////////////////////////////
            //
            //     1. Display the total sales
            //
            ////////////////////////////////////

            // Picture (Total Sales)
            PictureBox salePic = new PictureBox();
            salePic.BackgroundImageLayout = ImageLayout.Zoom;
            salePic.BorderStyle = BorderStyle.FixedSingle;
            salePic.Dock = DockStyle.Top;
            salePic.Size = new Size(183, 150);

            // Sum of sale
            Button saleSum = new Button();
            saleSum.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
            saleSum.Font = new Font("Microsoft Sans Serif", 16);
            saleSum.FlatStyle = FlatStyle.Flat;

            if (language.Equals("EN"))                              // Language
                saleSum.Text = "Total Sales: ";
            else if (language.Equals("CH"))
                saleSum.Text = "总销售: ";

            saleSum.Dock = DockStyle.Bottom;
            saleSum.Size = new Size(183, 64);

            // Add in image
            salePic.BackgroundImage = Image.FromFile("../.././Images/AWS/totalSales.png");

            // Add in data
            saleSum.Text += "$" + String.Format("{0:0.00}", totalSales);

            // Item frame
            Panel saleSum_item = new Panel();
            saleSum_item.BorderStyle = BorderStyle.FixedSingle;
            saleSum_item.Size = new Size(185, 216);


            ////////////////////////////////////////
            //
            //     2. Display the number juice sold
            //
            ////////////////////////////////////////

            // Picture (Juice Sold)
            PictureBox juicePic = new PictureBox();
            juicePic.BackgroundImageLayout = ImageLayout.Zoom;
            juicePic.BorderStyle = BorderStyle.FixedSingle;
            juicePic.Dock = DockStyle.Top;
            juicePic.Size = new Size(183, 150);

            // Soda sold counter
            Button soldCounter = new Button();
            soldCounter.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
            soldCounter.Font = new Font("Microsoft Sans Serif", 16);
            soldCounter.FlatStyle = FlatStyle.Flat;

            if (language.Equals("EN"))                              // Language
                soldCounter.Text = "Total Sold: ";
            else if (language.Equals("CH"))
                soldCounter.Text = "总果汁卖了: ";

            soldCounter.Dock = DockStyle.Bottom;
            soldCounter.Size = new Size(183, 64);

            // Add in image
            juicePic.BackgroundImage = Image.FromFile("../.././Images/AWS/juiceSold.jpg");

            // Add in data
            soldCounter.Text += juiceSold.ToString();

            // Item frame
            Panel juiceSold_item = new Panel();
            juiceSold_item.BorderStyle = BorderStyle.FixedSingle;
            juiceSold_item.Size = new Size(185, 216);


            ////////////////////////////////////////
            //
            //     3. Add the displays
            //
            ////////////////////////////////////////

            // Check if the displays are currently loaded

            // Reload the data to remove any previously added displays
            populate_flowLayoutPanel(current_table);

            // Add everything into item frame, then into the layout
            saleSum_item.Controls.Add(salePic);
            saleSum_item.Controls.Add(saleSum);
            flowLayoutPanel1.Controls.Add(saleSum_item);

            // Add everything into item frame, then into the layout
            juiceSold_item.Controls.Add(juicePic);
            juiceSold_item.Controls.Add(soldCounter);
            flowLayoutPanel1.Controls.Add(juiceSold_item);
        }
        //--------------------------End---------------------------//




        //
        //  Database Manipulation - Buttons
        //
        //------------------------Start---------------------------//
        private void salesIncrease(string juice, int increment)                 // Main method for all buttons
        {
            try
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();

                if (conn.State == ConnectionState.Open)
                {
                    try
                    {
                        string query = "UPDATE Juice_Sales SET sale_count=sale_count+" + increment + " WHERE drink=@drink";
                        SqlCommand cmd = new SqlCommand(query, conn, trans);              
                        cmd.Parameters.AddWithValue("@drink", juice);                // Update new sales of item

                        cmd.ExecuteNonQuery();
                        trans.Commit();
                        //MessageBox.Show(fruit + " increased by " + increment + " stock.");
                    }
                    catch (Exception)
                    {
                        trans.Rollback();
                        MessageBox.Show("Error in updating. Please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populate_flowLayoutPanel(current_table);
            }
        }

        private float aws_computeJuiceSale()
        {
            float totalSales = 0;
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "SELECT sale_cost, sale_count FROM " + current_table + " WHERE sale_count != @sale_count";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@sale_count", 0);

                    SqlDataReader sqlRdr = cmd.ExecuteReader();
                    while (sqlRdr.Read())
                    {
                        float saleCost = float.Parse(sqlRdr["sale_cost"].ToString());
                        int saleCount = Convert.ToInt32(sqlRdr["sale_count"].ToString());
                        totalSales += (saleCost * saleCount);
                        
                    }
                    sqlRdr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.GetType().ToString());
            }
            finally
            {
                conn.Close();
            }
            return totalSales;
        }

        private int aws_computeJuiceSold()
        {
            int juiceSold = 0;
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    // Return 0 if value is null. Filter out sale_count=0 to save time processing.
                    string query = "SELECT ISNULL(SUM(sale_count), 0) AS juiceSold FROM " + current_table + " WHERE sale_count != @sale_count";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@sale_count", 0);

                    SqlDataReader sqlRdr = cmd.ExecuteReader();

                    while (sqlRdr.Read())
                    {
                        juiceSold += Convert.ToInt32(sqlRdr["juiceSold"].ToString()); ;
                    }
                    sqlRdr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return juiceSold;
        }

        private void aws_resetJuiceSale()
        {
            try
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();

                if (conn.State == ConnectionState.Open)
                {
                    try
                    {
                        string query = "UPDATE " + current_table  + " SET sale_count = 0  WHERE sale_count != @sale_count";
                        SqlCommand cmd = new SqlCommand(query, conn, trans);
                        cmd.Parameters.AddWithValue("@sale_count", 0);               

                        cmd.ExecuteNonQuery();
                        trans.Commit();
                        //MessageBox.Show(fruit + " increased by " + increment + " stock.");
                    }
                    catch (Exception)
                    {
                        trans.Rollback();
                        MessageBox.Show("Error in updating. Please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populate_flowLayoutPanel(current_table);        // Reset the dispays after updating and retrieval
            }
        }
        private void updateSpecify(string juice, int value)                 // Main method for all buttons
        {
            try
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();

                if (conn.State == ConnectionState.Open)
                {
                    try
                    {
                        string query = "UPDATE Juice_Sales SET sale_count=@sale_count WHERE drink=@drink";
                        SqlCommand cmd = new SqlCommand(query, conn, trans);
                        cmd.Parameters.AddWithValue("@sale_count", value);                
                        cmd.Parameters.AddWithValue("@drink", juice);                // Update new sales of item

                        cmd.ExecuteNonQuery();
                        trans.Commit();
                        //MessageBox.Show(fruit + " increased by " + increment + " stock.");
                    }
                    catch (Exception)
                    {
                        trans.Rollback();
                        MessageBox.Show("Error in updating. Please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        //--------------------------End---------------------------//




        //
        //  Buttons
        //
        //------------------------Start---------------------------//
        // List of buttons
        // Method Signature: stockIncrease(Fruit, StockIncrement);
        private void btn_apple_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Apple Juice", 5);
        }

        private void btn_pear_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Pear Juice", 5);
        }

        private void btn_orange_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Orange Juice", 5);
        }

        private void btn_kiwi_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Kiwi Juice", 5);
        }

        private void btn_watermelon_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Watermelon Juice", 5);
        }

        private void btn_dragonfruit_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Dragon Fruit Juice", 5);
        }

        private void btn_banana_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Banana Juice", 5);
        }

        private void btn_lemon_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Lemon Juice", 5);
        }

        private void btn_mango_plus5_Click(object sender, EventArgs e)
        {
            salesIncrease("Mango Juice", 5);
        }

        private void btn_computeSales_Click(object sender, EventArgs e)
        {
            totalSales = aws_computeJuiceSale();
            juiceSold = aws_computeJuiceSold();
            display_computeSale(totalSales, juiceSold);
        }

        private void btn_resetDemo_Click(object sender, EventArgs e)
        {
            aws_resetJuiceSale();
        }

        private void btn_preset_Click(object sender, EventArgs e)
        {
            updateSpecify("Apple Juice", 25);
            updateSpecify("Pear Juice", 15);
            updateSpecify("Orange Juice", 20);
            updateSpecify("Kiwi Juice", 10);
            updateSpecify("Watermelon Juice", 25);
            updateSpecify("Dragon Fruit Juice", 5);
            updateSpecify("Banana Juice", 5);
            updateSpecify("Lemon Juice", 10);
            updateSpecify("Mango Juice", 10);
            populate_flowLayoutPanel(current_table);
        }
        //--------------------------End---------------------------//
    }
}
