﻿namespace SpotfireDemo
{
    partial class IoT_AWS
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IoT_AWS));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb_tapCount = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.pb_keyCard = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.pb_lights = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pb_motion = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.pb_buzzer = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.pb_button = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.pb_redLED = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.pb_greenLED = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tab_logs = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lb_DataComms2 = new System.Windows.Forms.ListBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btn_clearComms = new System.Windows.Forms.Button();
            this.tab_comments = new System.Windows.Forms.TabPage();
            this.lb_DataComms = new System.Windows.Forms.ListBox();
            this.tab_settings = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.cb_endTime = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.ddl_bookingDuration = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.ddl_startTime = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.mC_bookingDate = new System.Windows.Forms.MonthCalendar();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btn_confirmDuration = new System.Windows.Forms.Button();
            this.panel27 = new System.Windows.Forms.Panel();
            this.btn_changeDuration = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.panel1.SuspendLayout();
            this.panel15.SuspendLayout();
            this.flowLayoutPanel9.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_keyCard)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lights)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_motion)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_buzzer)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_button)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_redLED)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_greenLED)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tab_logs.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tab_comments.SuspendLayout();
            this.tab_settings.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(813, 625);
            this.panel1.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.flowLayoutPanel9);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 50);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(813, 510);
            this.panel15.TabIndex = 7;
            // 
            // flowLayoutPanel9
            // 
            this.flowLayoutPanel9.AutoScroll = true;
            this.flowLayoutPanel9.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel9.Controls.Add(this.panel3);
            this.flowLayoutPanel9.Controls.Add(this.panel12);
            this.flowLayoutPanel9.Controls.Add(this.panel5);
            this.flowLayoutPanel9.Controls.Add(this.panel9);
            this.flowLayoutPanel9.Controls.Add(this.panel10);
            this.flowLayoutPanel9.Controls.Add(this.panel11);
            this.flowLayoutPanel9.Controls.Add(this.panel13);
            this.flowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel9.Name = "flowLayoutPanel9";
            this.flowLayoutPanel9.Padding = new System.Windows.Forms.Padding(18);
            this.flowLayoutPanel9.Size = new System.Drawing.Size(813, 510);
            this.flowLayoutPanel9.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lb_tapCount);
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.pb_keyCard);
            this.panel3.Location = new System.Drawing.Point(21, 21);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(184, 216);
            this.panel3.TabIndex = 0;
            // 
            // lb_tapCount
            // 
            this.lb_tapCount.AutoSize = true;
            this.lb_tapCount.BackColor = System.Drawing.Color.LightCyan;
            this.lb_tapCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lb_tapCount.Location = new System.Drawing.Point(31, 185);
            this.lb_tapCount.Name = "lb_tapCount";
            this.lb_tapCount.Size = new System.Drawing.Size(118, 24);
            this.lb_tapCount.TabIndex = 4;
            this.lb_tapCount.Text = "Tap Count: 0";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.LightCyan;
            this.button8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(0, 150);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(182, 64);
            this.button8.TabIndex = 3;
            this.button8.Text = "Key Card";
            this.button8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // pb_keyCard
            // 
            this.pb_keyCard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_keyCard.BackgroundImage")));
            this.pb_keyCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_keyCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_keyCard.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_keyCard.Location = new System.Drawing.Point(0, 0);
            this.pb_keyCard.Name = "pb_keyCard";
            this.pb_keyCard.Size = new System.Drawing.Size(182, 150);
            this.pb_keyCard.TabIndex = 0;
            this.pb_keyCard.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.button7);
            this.panel12.Controls.Add(this.pb_lights);
            this.panel12.Location = new System.Drawing.Point(211, 21);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(184, 216);
            this.panel12.TabIndex = 4;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightCyan;
            this.button7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(0, 150);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(182, 64);
            this.button7.TabIndex = 3;
            this.button7.Text = "Lights";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // pb_lights
            // 
            this.pb_lights.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_lights.BackgroundImage")));
            this.pb_lights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_lights.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_lights.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_lights.Location = new System.Drawing.Point(0, 0);
            this.pb_lights.Name = "pb_lights";
            this.pb_lights.Size = new System.Drawing.Size(182, 150);
            this.pb_lights.TabIndex = 0;
            this.pb_lights.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.pb_motion);
            this.panel5.Location = new System.Drawing.Point(401, 21);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(184, 216);
            this.panel5.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCyan;
            this.button2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(0, 150);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(182, 64);
            this.button2.TabIndex = 3;
            this.button2.Text = "Motion";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // pb_motion
            // 
            this.pb_motion.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_motion.BackgroundImage")));
            this.pb_motion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_motion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_motion.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_motion.Location = new System.Drawing.Point(0, 0);
            this.pb_motion.Name = "pb_motion";
            this.pb_motion.Size = new System.Drawing.Size(182, 150);
            this.pb_motion.TabIndex = 0;
            this.pb_motion.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.button3);
            this.panel9.Controls.Add(this.pb_buzzer);
            this.panel9.Location = new System.Drawing.Point(591, 21);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(184, 216);
            this.panel9.TabIndex = 4;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightCyan;
            this.button3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(0, 150);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(182, 64);
            this.button3.TabIndex = 3;
            this.button3.Text = "Buzzer";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // pb_buzzer
            // 
            this.pb_buzzer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_buzzer.BackgroundImage")));
            this.pb_buzzer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_buzzer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_buzzer.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_buzzer.Location = new System.Drawing.Point(0, 0);
            this.pb_buzzer.Name = "pb_buzzer";
            this.pb_buzzer.Size = new System.Drawing.Size(182, 150);
            this.pb_buzzer.TabIndex = 0;
            this.pb_buzzer.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.button4);
            this.panel10.Controls.Add(this.pb_button);
            this.panel10.Location = new System.Drawing.Point(21, 243);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(184, 216);
            this.panel10.TabIndex = 4;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightCyan;
            this.button4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(0, 150);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(182, 64);
            this.button4.TabIndex = 3;
            this.button4.Text = "Button";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // pb_button
            // 
            this.pb_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_button.BackgroundImage")));
            this.pb_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_button.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_button.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_button.Location = new System.Drawing.Point(0, 0);
            this.pb_button.Name = "pb_button";
            this.pb_button.Size = new System.Drawing.Size(182, 150);
            this.pb_button.TabIndex = 0;
            this.pb_button.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.button5);
            this.panel11.Controls.Add(this.pb_redLED);
            this.panel11.Location = new System.Drawing.Point(211, 243);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(184, 216);
            this.panel11.TabIndex = 4;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightCyan;
            this.button5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(0, 150);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(182, 64);
            this.button5.TabIndex = 3;
            this.button5.Text = "Red LED";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // pb_redLED
            // 
            this.pb_redLED.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_redLED.BackgroundImage")));
            this.pb_redLED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_redLED.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_redLED.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_redLED.Location = new System.Drawing.Point(0, 0);
            this.pb_redLED.Name = "pb_redLED";
            this.pb_redLED.Size = new System.Drawing.Size(182, 150);
            this.pb_redLED.TabIndex = 0;
            this.pb_redLED.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.button9);
            this.panel13.Controls.Add(this.pb_greenLED);
            this.panel13.Location = new System.Drawing.Point(401, 243);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(184, 216);
            this.panel13.TabIndex = 4;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.LightCyan;
            this.button9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(0, 150);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(182, 64);
            this.button9.TabIndex = 3;
            this.button9.Text = "Green LED";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // pb_greenLED
            // 
            this.pb_greenLED.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_greenLED.BackgroundImage")));
            this.pb_greenLED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_greenLED.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_greenLED.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_greenLED.Location = new System.Drawing.Point(0, 0);
            this.pb_greenLED.Name = "pb_greenLED";
            this.pb_greenLED.Size = new System.Drawing.Size(182, 150);
            this.pb_greenLED.TabIndex = 0;
            this.pb_greenLED.TabStop = false;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.LightCyan;
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.Location = new System.Drawing.Point(0, 560);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(813, 65);
            this.panel14.TabIndex = 6;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightCyan;
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(813, 50);
            this.button6.TabIndex = 4;
            this.button6.Text = "Sensors";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(813, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(373, 625);
            this.panel2.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(373, 575);
            this.panel4.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.flowLayoutPanel8);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(373, 510);
            this.panel7.TabIndex = 2;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.tabControl1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 20);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(373, 490);
            this.panel8.TabIndex = 6;
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.flowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Size = new System.Drawing.Size(373, 20);
            this.flowLayoutPanel8.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button10);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 510);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(373, 65);
            this.panel6.TabIndex = 1;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button10.Cursor = System.Windows.Forms.Cursors.Default;
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.button10.Location = new System.Drawing.Point(0, 0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(373, 65);
            this.button10.TabIndex = 4;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(373, 50);
            this.button1.TabIndex = 2;
            this.button1.Text = "Controls";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // tab_logs
            // 
            this.tab_logs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(255)))), ((int)(((byte)(245)))));
            this.tab_logs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tab_logs.Controls.Add(this.panel17);
            this.tab_logs.Controls.Add(this.panel16);
            this.tab_logs.Location = new System.Drawing.Point(4, 30);
            this.tab_logs.Name = "tab_logs";
            this.tab_logs.Padding = new System.Windows.Forms.Padding(3);
            this.tab_logs.Size = new System.Drawing.Size(365, 456);
            this.tab_logs.TabIndex = 1;
            this.tab_logs.Text = "Developer Logs";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.lb_DataComms2);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(3, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(357, 448);
            this.panel16.TabIndex = 0;
            // 
            // lb_DataComms2
            // 
            this.lb_DataComms2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(255)))), ((int)(((byte)(245)))));
            this.lb_DataComms2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lb_DataComms2.Cursor = System.Windows.Forms.Cursors.Default;
            this.lb_DataComms2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_DataComms2.FormattingEnabled = true;
            this.lb_DataComms2.HorizontalScrollbar = true;
            this.lb_DataComms2.ItemHeight = 21;
            this.lb_DataComms2.Location = new System.Drawing.Point(0, 0);
            this.lb_DataComms2.Name = "lb_DataComms2";
            this.lb_DataComms2.Size = new System.Drawing.Size(357, 448);
            this.lb_DataComms2.TabIndex = 0;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.btn_clearComms);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel17.Location = new System.Drawing.Point(3, 396);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(357, 55);
            this.panel17.TabIndex = 4;
            // 
            // btn_clearComms
            // 
            this.btn_clearComms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_clearComms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_clearComms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_clearComms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clearComms.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btn_clearComms.Location = new System.Drawing.Point(0, 0);
            this.btn_clearComms.Name = "btn_clearComms";
            this.btn_clearComms.Size = new System.Drawing.Size(357, 55);
            this.btn_clearComms.TabIndex = 3;
            this.btn_clearComms.Text = "Clear Logs";
            this.btn_clearComms.UseVisualStyleBackColor = false;
            this.btn_clearComms.Click += new System.EventHandler(this.btn_clearComms_Click);
            // 
            // tab_comments
            // 
            this.tab_comments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tab_comments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tab_comments.Controls.Add(this.lb_DataComms);
            this.tab_comments.Location = new System.Drawing.Point(4, 30);
            this.tab_comments.Name = "tab_comments";
            this.tab_comments.Padding = new System.Windows.Forms.Padding(3);
            this.tab_comments.Size = new System.Drawing.Size(365, 456);
            this.tab_comments.TabIndex = 3;
            this.tab_comments.Text = "Comments";
            // 
            // lb_DataComms
            // 
            this.lb_DataComms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lb_DataComms.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lb_DataComms.Cursor = System.Windows.Forms.Cursors.Default;
            this.lb_DataComms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_DataComms.FormattingEnabled = true;
            this.lb_DataComms.HorizontalScrollbar = true;
            this.lb_DataComms.ItemHeight = 21;
            this.lb_DataComms.Location = new System.Drawing.Point(3, 3);
            this.lb_DataComms.Name = "lb_DataComms";
            this.lb_DataComms.Size = new System.Drawing.Size(357, 448);
            this.lb_DataComms.TabIndex = 1;
            // 
            // tab_settings
            // 
            this.tab_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(245)))));
            this.tab_settings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tab_settings.Controls.Add(this.panel20);
            this.tab_settings.Controls.Add(this.panel18);
            this.tab_settings.Cursor = System.Windows.Forms.Cursors.Default;
            this.tab_settings.Location = new System.Drawing.Point(4, 30);
            this.tab_settings.Name = "tab_settings";
            this.tab_settings.Size = new System.Drawing.Size(365, 456);
            this.tab_settings.TabIndex = 0;
            this.tab_settings.Text = "Settings";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.panel23);
            this.panel18.Controls.Add(this.panel24);
            this.panel18.Controls.Add(this.panel22);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(363, 343);
            this.panel18.TabIndex = 0;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label1);
            this.panel19.Controls.Add(this.cb_endTime);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel19.Location = new System.Drawing.Point(0, 292);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(363, 51);
            this.panel19.TabIndex = 2;
            // 
            // cb_endTime
            // 
            this.cb_endTime.BackColor = System.Drawing.Color.White;
            this.cb_endTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cb_endTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cb_endTime.Enabled = false;
            this.cb_endTime.ForeColor = System.Drawing.SystemColors.InfoText;
            this.cb_endTime.FormattingEnabled = true;
            this.cb_endTime.Items.AddRange(new object[] {
            "10 min",
            "15 min",
            "20 min",
            "30 min",
            "60 min"});
            this.cb_endTime.Location = new System.Drawing.Point(126, 7);
            this.cb_endTime.Name = "cb_endTime";
            this.cb_endTime.Size = new System.Drawing.Size(227, 29);
            this.cb_endTime.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "End Time:";
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.label2);
            this.panel22.Controls.Add(this.ddl_bookingDuration);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel22.Location = new System.Drawing.Point(0, 242);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(363, 50);
            this.panel22.TabIndex = 3;
            // 
            // ddl_bookingDuration
            // 
            this.ddl_bookingDuration.BackColor = System.Drawing.Color.White;
            this.ddl_bookingDuration.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ddl_bookingDuration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_bookingDuration.ForeColor = System.Drawing.SystemColors.InfoText;
            this.ddl_bookingDuration.FormattingEnabled = true;
            this.ddl_bookingDuration.Items.AddRange(new object[] {
            "10 min",
            "15 min",
            "20 min",
            "30 min",
            "60 min"});
            this.ddl_bookingDuration.Location = new System.Drawing.Point(126, 6);
            this.ddl_bookingDuration.Name = "ddl_bookingDuration";
            this.ddl_bookingDuration.Size = new System.Drawing.Size(227, 29);
            this.ddl_bookingDuration.TabIndex = 1;
            this.ddl_bookingDuration.SelectedIndexChanged += new System.EventHandler(this.ddl_bookingDuration_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Duration:";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.label4);
            this.panel24.Controls.Add(this.ddl_startTime);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel24.Location = new System.Drawing.Point(0, 194);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(363, 48);
            this.panel24.TabIndex = 4;
            // 
            // ddl_startTime
            // 
            this.ddl_startTime.BackColor = System.Drawing.Color.White;
            this.ddl_startTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ddl_startTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddl_startTime.ForeColor = System.Drawing.SystemColors.InfoText;
            this.ddl_startTime.FormattingEnabled = true;
            this.ddl_startTime.Items.AddRange(new object[] {
            "10:00",
            "10:30",
            "11:00",
            "11:30",
            "12:00",
            "12:30",
            "13:00",
            "13:30",
            "14:00",
            "14:30",
            "15:00",
            "15:30",
            "16:00"});
            this.ddl_startTime.Location = new System.Drawing.Point(126, 5);
            this.ddl_startTime.Name = "ddl_startTime";
            this.ddl_startTime.Size = new System.Drawing.Size(227, 29);
            this.ddl_startTime.TabIndex = 1;
            this.ddl_startTime.SelectedIndexChanged += new System.EventHandler(this.ddl_startTime_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "Start Time:";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.mC_bookingDate);
            this.panel23.Controls.Add(this.label3);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(363, 194);
            this.panel23.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "Booking Date:";
            // 
            // mC_bookingDate
            // 
            this.mC_bookingDate.Location = new System.Drawing.Point(126, 8);
            this.mC_bookingDate.MaxDate = new System.DateTime(2056, 7, 13, 0, 0, 0, 0);
            this.mC_bookingDate.MaxSelectionCount = 1;
            this.mC_bookingDate.MinDate = new System.DateTime(2000, 2, 1, 0, 0, 0, 0);
            this.mC_bookingDate.Name = "mC_bookingDate";
            this.mC_bookingDate.ShowTodayCircle = false;
            this.mC_bookingDate.TabIndex = 4;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.panel27);
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(0, 343);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(363, 64);
            this.panel20.TabIndex = 6;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.btn_confirmDuration);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Padding = new System.Windows.Forms.Padding(10, 15, 10, 5);
            this.panel21.Size = new System.Drawing.Size(178, 64);
            this.panel21.TabIndex = 0;
            // 
            // btn_confirmDuration
            // 
            this.btn_confirmDuration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_confirmDuration.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_confirmDuration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_confirmDuration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_confirmDuration.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btn_confirmDuration.Location = new System.Drawing.Point(10, 15);
            this.btn_confirmDuration.Name = "btn_confirmDuration";
            this.btn_confirmDuration.Size = new System.Drawing.Size(158, 44);
            this.btn_confirmDuration.TabIndex = 4;
            this.btn_confirmDuration.Text = "Confirm";
            this.btn_confirmDuration.UseVisualStyleBackColor = false;
            this.btn_confirmDuration.Click += new System.EventHandler(this.btn_confirmDuration_Click);
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.btn_changeDuration);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel27.Location = new System.Drawing.Point(174, 0);
            this.panel27.Name = "panel27";
            this.panel27.Padding = new System.Windows.Forms.Padding(10, 15, 10, 5);
            this.panel27.Size = new System.Drawing.Size(189, 64);
            this.panel27.TabIndex = 4;
            // 
            // btn_changeDuration
            // 
            this.btn_changeDuration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_changeDuration.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_changeDuration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_changeDuration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_changeDuration.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btn_changeDuration.Location = new System.Drawing.Point(10, 15);
            this.btn_changeDuration.Name = "btn_changeDuration";
            this.btn_changeDuration.Size = new System.Drawing.Size(169, 44);
            this.btn_changeDuration.TabIndex = 5;
            this.btn_changeDuration.Text = "Change";
            this.btn_changeDuration.UseVisualStyleBackColor = false;
            this.btn_changeDuration.Click += new System.EventHandler(this.btn_changeDuration_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab_settings);
            this.tabControl1.Controls.Add(this.tab_comments);
            this.tabControl1.Controls.Add(this.tab_logs);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(373, 490);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 4;
            // 
            // IoT_AWS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "IoT_AWS";
            this.Size = new System.Drawing.Size(1186, 625);
            this.Load += new System.EventHandler(this.DiscussionRoomBooking_Load);
            this.panel1.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.flowLayoutPanel9.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_keyCard)).EndInit();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_lights)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_motion)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_buzzer)).EndInit();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_button)).EndInit();
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_redLED)).EndInit();
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_greenLED)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tab_logs.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.tab_comments.ResumeLayout(false);
            this.tab_settings.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pb_keyCard;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pb_lights;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pb_motion;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pb_buzzer;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pb_button;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pb_redLED;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pb_greenLED;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label lb_tapCount;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_settings;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Button btn_changeDuration;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btn_confirmDuration;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.MonthCalendar mC_bookingDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox ddl_startTime;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ddl_bookingDuration;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_endTime;
        private System.Windows.Forms.TabPage tab_comments;
        private System.Windows.Forms.ListBox lb_DataComms;
        private System.Windows.Forms.TabPage tab_logs;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btn_clearComms;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.ListBox lb_DataComms2;
    }
}
