﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// SQL client
using System.Data.SqlClient;
// ArrayList
using System.Collections;

namespace SpotfireDemo
{
    public partial class FruitStore : UserControl
    {
        // Declared borrowed variables
        SqlConnection conn = null;
        ArrayList table_names = null;
        string current_table = null;

        // Control first time load
        Boolean dataLoaded = false;

        public FruitStore()
        {
            InitializeComponent();
        }

        private void FruitStore_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            conn = SpotfireDemo.conn;
            table_names = SpotfireDemo.table_names;
            current_table = table_names[0].ToString();

            // Set drop-down-list items
            foreach (string table_name in table_names)
            {
                ddl_tables.Items.Add(table_name);
            }

            // Set first item displayed
            ddl_tables.Text = current_table;

            populateDataGrid(current_table);
            dataLoaded = true;
        }

        private void ddl_tables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dataLoaded)  // Required to prevent first-time load error
            {
                current_table = ddl_tables.SelectedItem.ToString();
                populateDataGrid(current_table);
            }
        }

        private void populateDataGrid(string current_table)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string cmd = "SELECT * FROM " + current_table + "";
                    SqlDataAdapter da = new SqlDataAdapter(cmd, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btn_stockBy5_Click(object sender, EventArgs e)
        {
            stockIncrease(5);
        }

        private void btn_stockBy10_Click(object sender, EventArgs e)
        {
            stockIncrease(10);
        }

        private void btn_stockBy15_Click(object sender, EventArgs e)
        {
            stockIncrease(15);
        }

        private void stockIncrease(int increment)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    // Generate a random number for fruit Id. Exclude the "discontinued" fruits
                    int num;
                    do
                    {
                        Random random = new Random();
                        num = random.Next(1, 10);
                    } while (num == 6 || num == 10);

                    string query = "SELECT stock,fruit FROM Fruits WHERE fruit_Id=@id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", num);

                    SqlDataReader dr = cmd.ExecuteReader();
                    string fruit = "";
                    int stock = 0;
                    while (dr.Read())
                    {
                        ;
                        fruit = dr["fruit"].ToString();
                        stock = Convert.ToInt32(dr["stock"]);
                    }
                    dr.Close();

                    stock += increment;

                    SqlTransaction trans = conn.BeginTransaction();
                    try
                    {
                        query = "UPDATE Fruits SET Stock=@newStock WHERE fruit_Id=@id";
                        cmd = new SqlCommand(query, conn, trans);
                        cmd.Parameters.AddWithValue("@Id", num);
                        cmd.Parameters.AddWithValue("@newStock", stock);

                        cmd.ExecuteNonQuery();
                        trans.Commit();
                        MessageBox.Show(fruit + " increased by " + increment + " stock.");
                    }
                    catch (Exception ex)
                    {
                        trans.Rollback();
                        MessageBox.Show("Error in updating. Please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populateDataGrid(current_table);
            }
        }
    }
}
