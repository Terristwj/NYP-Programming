﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// SQL client
using System.Configuration;
using System.Data.SqlClient;
// ArrayList
using System.Collections;

namespace SpotfireDemo
{
    public partial class DiscussionRoomBooking : UserControl
    {
        // Declared borrowed variables
        SqlConnection conn = null;
        ArrayList table_names = null;
        string current_table = null;

        // Control first time load
        Boolean dataLoaded = false;

        // Raspberry Pi related
        DataComms dataComms = SpotfireDemo.dataComms;
        public delegate void myProcessDataDelegate(string strData);

        public DiscussionRoomBooking()
        {
            InitializeComponent();
        }

        private void DiscussionRoomBooking_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            conn = SpotfireDemo.conn;
            table_names = SpotfireDemo.table_names;
            current_table = table_names[0].ToString();

            // Set drop-down-list items
            foreach (string table_name in table_names)
            {
                ddl_tables.Items.Add(table_name);
            }

            // Set first item displayed
            ddl_tables.Text = current_table;

            populateDataGrid(current_table);
            dataLoaded = true;

            // Load Raspberry Pi integrated codes
            InitComms();
        }

        private void ddl_tables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dataLoaded)  // Required to prevent first-time load error
            {
                current_table = ddl_tables.SelectedItem.ToString();
                populateDataGrid(current_table);
            }
        }

        private void populateDataGrid(string current_table)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string cmd = "SELECT * FROM " + current_table + "";
                    SqlDataAdapter da = new SqlDataAdapter(cmd, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        /*=======================================================
                            Utility Methods
        =======================================================*/
        private float extractFloatValue(string strData, string ID)
        {
            return (float.Parse(extractStringValue(strData, ID)));              // Utility to extract float value from data
        }

        private string extractStringValue(string strData, string ID)                // Utility to extract string value from data
        {
            string result = strData.Substring(strData.IndexOf(ID) + ID.Length);
            return result;
        }
        /*-----------------------End---------------------------*/


        /*=======================================================
         
               Below controls the dataComms to IoT Raspberry
         
        =======================================================*/

        private void btn_clearComms_Click(object sender, EventArgs e)
        {
            lb_DataComms.Items.Clear();
        }

        private void InitComms()                // Starts connection to IoT Background Application
        {
            dataComms.dataReceiveEvent += new DataComms.DataReceivedDelegate(commsDataReceive);
            dataComms.dataSendErrorEvent += new DataComms.DataSendErrorDelegate(commsSendError);
        }

        public void commsDataReceive(string dataReceived)       // Auto-triggers when data is received
        {
            processDataReceive(dataReceived);
        }

        public void commsSendError(string errMsg)               // Auto-triggers when error
        {
            MessageBox.Show(errMsg);
            processDataReceive(errMsg);
        }

        public void processDataReceive(string strData)          // Process the message (Data or Error)
        {
            myProcessDataDelegate dataD = new myProcessDataDelegate(handleSensorData);  // Start of message retreival
            lb_DataComms.Invoke(dataD, new object[] { strData });
        }
        
        public void handleSensorData(string strData)        
        {
            string dateTime = DateTime.Now.ToString("s");
            extractSensorData(strData, dateTime);

            string strMessage = dateTime + ":" + strData;
            lb_DataComms.Items.Insert(0, strMessage);
        }
        
        private void extractSensorData(string strData, string strTime)                  // Add sensors here
        {
            // Raspberry Pi can send any type of data
            // Check type of data before extraction

            // Addon sensor data types
            if (strData.IndexOf("LIGHT=") != -1)                        // Light Sensor
                handleLightData(strData, strTime, "LIGHT=");
            else if (strData.IndexOf("BUTTON=") != -1)                  // Button Sensor
                handleButtonData(strTime);
            else if (strData.IndexOf("MOTION=") != -1)                  // PIR Motion Sensor
                handleMotionData(strTime);
        }

        private void handleLightData(string strData, string strTime, string ID)                   // Light sensor data
        {
            string strLightValue = extractStringValue(strData, ID);
            float fLightValue = extractFloatValue(strData, ID);
            string status = "";

            if (fLightValue <= 500)
                status = "Dark";
            else
                status = "Bright";

            saveLightSensorDataToDB(strTime, strLightValue, status);
        }

        private void saveLightSensorDataToDB(string strTime, string strLightValue, string strStatus)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT LightSensor (TimeOccurred, LightValue, LightStatus) Values (@time, @value, @status)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@time", strTime);
                    cmd.Parameters.AddWithValue("@value", strLightValue);
                    cmd.Parameters.AddWithValue("@status", strStatus);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populateDataGrid(current_table);
            }
        }

        private void handleButtonData(string strTime)                                       // Button sensor data
        {
            saveButtonSensorDataToDB(strTime);
        }

        private void saveButtonSensorDataToDB(string strTime)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT ButtonSensor (TimeOccurred) Values (@time)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@time", strTime);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populateDataGrid(current_table);
            }
        }

        private void handleMotionData(string strTime)                                       // PIR Motion sensor data
        {
            saveMotionSensorDataToDB(strTime);
        }

        private void saveMotionSensorDataToDB(string strTime)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT PirMotionSensor (TimeOccurred) Values (@time)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@time", strTime);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populateDataGrid(current_table);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //dataComms.sendData("SENDLIGHT");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //dataComms.sendData("SENDBUTTON");
        }
    }
}
