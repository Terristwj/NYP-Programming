﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// SQL client
using System.Data.SqlClient;
// ArrayList
using System.Collections;

namespace SpotfireDemo
{
    public partial class FruitStore : UserControl
    {
        // Declared borrowed variables
        SqlConnection conn = null;
        ArrayList table_names = null;
        string current_table = null;

        public FruitStore()
        {
            InitializeComponent();
        }

        private void FruitStore_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            conn = SpotfireDemo.conn;
            table_names = SpotfireDemo.table_names;
            current_table = table_names[0].ToString();

            // Display fruits
            populate_flowLayoutPanel(current_table);
        }


        //
        //  Database Manipulation
        //
        //------------------------Start---------------------------//
        private void populate_flowLayoutPanel(string current_table)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)                         // Retrieve data
                {
                    string cmd = "SELECT * FROM " + current_table + "";
                    SqlDataAdapter da = new SqlDataAdapter(cmd, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    flowLayoutPanel1.Controls.Clear();
                    foreach (DataRow row in dt.Rows)                        // Foreach fruit, create an item frame
                    {
                        // Picture
                        PictureBox fruitPic = new PictureBox();
                        fruitPic.BackgroundImageLayout = ImageLayout.Zoom;
                        fruitPic.BorderStyle = BorderStyle.FixedSingle;
                        fruitPic.Dock = DockStyle.Top;
                        fruitPic.Size = new Size(183, 150);

                        // Stock
                        Button fruitStock = new Button();
                        fruitStock.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
                        fruitStock.Font = new Font("Microsoft Sans Serif", 16);
                        fruitStock.FlatStyle = FlatStyle.Flat;
                        fruitStock.Text = "Stock: ";
                        fruitStock.Dock = DockStyle.Bottom;
                        fruitStock.Size = new Size(183, 64);

                        // Add in image
                        int columnIndex = 0;
                        columnIndex = get_columnIndex(dt, "image");
                        fruitPic.BackgroundImage = Image.FromFile("../.././Images/FruitStore/" + row[columnIndex].ToString());

                        // Add in data
                        columnIndex = get_columnIndex(dt, "stock");
                        fruitStock.Text += row[columnIndex].ToString();
                        
                        // Item frame
                        Panel fruitItem = new Panel();
                        fruitItem.BorderStyle = BorderStyle.FixedSingle;
                        fruitItem.Size = new Size(185, 216);

                        // Add everything into item frame, then into the layout
                        fruitItem.Controls.Add(fruitPic);
                        fruitItem.Controls.Add(fruitStock);
                        flowLayoutPanel1.Controls.Add(fruitItem);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private int get_columnIndex(DataTable dt, string columnName, int counter = 0)           // Reusuable counter for column index
        {
            foreach (DataColumn col in dt.Columns)
            {
                if (col.ColumnName.ToString().Equals(columnName))
                {
                    break;
                }
                counter++;
            }
            return counter;
        }

        //--------------------------End---------------------------//




        //
        //  Buttons
        //
        //------------------------Start---------------------------//
        private void stockIncrease(string fruit, int increment)                 // Main method for all buttons
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "SELECT stock FROM Fruits WHERE fruit=@fruit";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@fruit", fruit);

                    SqlDataReader dr = cmd.ExecuteReader();
                    int stock = 0;
                    while (dr.Read())
                    {
                        stock = Convert.ToInt32(dr["stock"]);                           // Get current stock of item
                    }
                    dr.Close();

                    stock += increment;

                    SqlTransaction trans = conn.BeginTransaction();
                    try
                    {
                        query = "UPDATE Fruits SET Stock=@newStock WHERE fruit=@fruit";
                        cmd = new SqlCommand(query, conn, trans);
                        cmd.Parameters.AddWithValue("@newStock", stock);                // Update new stock of same item
                        cmd.Parameters.AddWithValue("@fruit", fruit);

                        cmd.ExecuteNonQuery();
                        trans.Commit();
                        //MessageBox.Show(fruit + " increased by " + increment + " stock.");
                    }
                    catch (Exception)
                    {
                        trans.Rollback();
                        MessageBox.Show("Error in updating. Please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                populate_flowLayoutPanel(current_table);
            }
        }



                                                                            // List of buttons
                                                                            // Method Signature: stockIncrease(Fruit, StockIncrement);
        private void btn_apple_plus4_Click(object sender, EventArgs e)
        {
            stockIncrease("Apple", 5);
        }

        private void btn_pear_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Pear", 5);
        }

        private void btn_orange_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Orange", 5);
        }

        private void btn_kiwi_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Kiwi", 5);
        }

        private void btn_watermelon_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Watermelon", 5);
        }

        private void btn_dragonfruit_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Dragon Fruit", 5);
        }

        private void btn_banana_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Banana", 5);
        }

        private void btn_lemon_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Lemon", 5);
        }

        private void btn_mango_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Mango", 5);
        }

        private void btn_durian_plus5_Click(object sender, EventArgs e)
        {
            stockIncrease("Durian", 5);
        }
        //--------------------------End---------------------------//
    }
}
