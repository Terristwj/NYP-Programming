Using Google BigQuery and Amazon (AWS) RDS (MS SQL).

Google BigQuery setup is easy and straight forwards.
School Wifi has access.
Short term is good because easy to use.


AWS RDS - MS SQL is difficult. 
Database setup and configuration is required and complicated.
Long term use, it is very powerful with all the utilities.
School Wifi blocks most ports. Have to use personal data OR VPN.