﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// SQL client
using System.Data.SqlClient;
// Arraylust
using System.Collections;

namespace SpotfireDemo
{
    public partial class SpotfireDemo : Form
    {
        public static SqlConnection conn;
        public static ArrayList table_names = null;
        public static ArrayList dataSet_table = null;

        // Track the current userControl opened
        private static string current_userControl = "Homepage";     // Value uses the name of the .cs

        // Languages for supported userControls
        public static string language = "EN";
        public static string prev_language = "EN";
        //  Array to edit language items displayed in MenuStrip
        private string[] userControl_languageSupported = null;

        // Raspberry Pi related
        public static DataComms dataComms = new DataComms();

        // BigQuery related
        // Google Service Credentials
        private static string credential_path = @"../.././BigQuery/2019-NYP-FYPJ-27a5e99fc231.json";        // Please use your own .json file

        public SpotfireDemo()
        {
            InitializeComponent();

            // Onload, click the dashboard tab
            UserControl userControl = new Homepage();
            toggle_sideNavi(btn_home, userControl, false, true);
        }



        //
        //  Buttons
        //
        //------------------------Start---------------------------//
        private void btn_home_Click(object sender, EventArgs e)
        {
            current_userControl = "Homepage";
            toggle_sideNavi(btn_home, new Homepage());
        }
        private void btn_fruitStore_Click(object sender, EventArgs e)
        {
            current_userControl = "FruitStore";

            // Connect FruitStore Database
            conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=SpotfireDemo FruitStore;Integrated Security=True");
            // Get data
            get_DatabaseInformation();

            // Langauge options settings
            string[] languages_supported = { "EN", "CH", "RU" };
            userControl_languageSupported = languages_supported;

            toggle_sideNavi(btn_fruitStore, new FruitStore(), true);
        }

        private void btn_discussionRoomBooking_Click(object sender, EventArgs e)
        {
            current_userControl = "DiscussionRoomBooking";

            // Connect FruitStore Database
            conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DiscussionRoomBooking;Integrated Security=True");
            // Get data
            get_DatabaseInformation();

            toggle_sideNavi(btn_discussionRoomBooking, new DiscussionRoomBooking());
        }

        private void btn_bigQuery_Click(object sender, EventArgs e)
        {
            current_userControl = "BigQuery";

            // Not using any SQL database
            conn = null;
            
            // Google Services Credentials
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", credential_path);

            // Langauge options settings
            string[] languages_supported = { "EN", "CH" };
            userControl_languageSupported = languages_supported;

            try
            {
                toggle_sideNavi(btn_bigQuery, new BigQuery(), true);
            }
            catch (TypeInitializationException ex)          //  This error catch only appears IF credenial_path is wrong
            {
                MessageBox.Show(ex.InnerException.Message); // Narrows down the error type, then displays the innerException message
            }
        }

        private void btn_aws_Click(object sender, EventArgs e)
        {
            current_userControl = "aws";

            try
            {
                // Connect AWS Cloud Database
                // Please use your own account AWS RDS - Microsoft SQL Server database connection.
                string dataSource = "fypj-sample.chx5jxm4lukg.ap-northeast-2.rds.amazonaws.com,5222";   // Server name, port number
                string databaseName = "JuiceStore";
                string aws_credentials_userID = "awsuser";
                string aws_credentials_password = "T0026507h";

                string connectionStr = "Data Source=" + dataSource + ";";
                connectionStr += "Initial Catalog=" + databaseName + ";";
                connectionStr += "User ID=" + aws_credentials_userID + ";";
                connectionStr += "Password=" + aws_credentials_password;
                conn = new SqlConnection(connectionStr);

                conn.Open();                // Test connection
                conn.Close();               // If no connection will exit into catch


                // Get data
                get_DatabaseInformation();

                // Langauge options settings
                string[] languages_supported = { "EN", "CH" };
                userControl_languageSupported = languages_supported;

                toggle_sideNavi(btn_aws, new aws(), true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured: Connection to AWS Server is blocked. \nUse a VPN to make a connection.");
            }
        }

        private void get_DatabaseInformation()
        {
            // Create a new set of table names:
            set_table_names();

            // Create data set with the new connection
            dataSet_table = get_databaseValues();
        }


        private void toggle_sideNavi(Button sender, UserControl userControl, Boolean hasLanguages = false, Boolean onload = false)    // When corresponding navigation tab is clicked
        {
            // To remove the current mainContent
            if (onload == false)
                panel_mainContent.Controls.RemoveAt(0);

            // Check to see if supports other languages
            if (hasLanguages)
                language_Item.DisplayStyle = ToolStripItemDisplayStyle.Text;
            else
                language_Item.DisplayStyle = ToolStripItemDisplayStyle.None;


            // List of buttons at side nav
            Button[] buttons = new Button[]                     // IMPORTANT: Must add on for any new side navigation buttons
            {
                btn_home,
                btn_fruitStore,
                btn_discussionRoomBooking,
                btn_bigQuery,
                btn_aws
            };

            // Manages the CSS of all buttons to default
            foreach (Button button in buttons)
            {
                button.Enabled = true;
                button.BackColor = Color.FromArgb(41, 53, 65);
            }

            // Manages the CSS of clicked button
            sender.Enabled = false;
            sender.BackColor = Color.AliceBlue;

            // Edits the display for selecting language
            modify_languageOptions();

            // To add the new mainContent
            try
            {
                panel_mainContent.Controls.Add(userControl);
                userControl.Dock = DockStyle.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error");
            }

            // Essential for any userControl page with langaugeSupport
            checkCurrentLanguage();

            // Reset languageSupported since already loaded the userControl page
            userControl_languageSupported = null;
        }
        //--------------------------End---------------------------//


        //
        //  Get Database Information
        //
        //------------------------Start---------------------------//
        private void set_table_names()
        {
            // Resets Array
            table_names = new ArrayList();
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    DataTable schema = conn.GetSchema("Tables");

                    // Get table names and fills in
                    foreach (DataRow row in schema.Rows)
                    {
                        string tablename = (string)row[2];
                        table_names.Add(tablename);
                    }
                    table_names.Sort();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        private ArrayList get_databaseValues()
        {
            ArrayList myArray = null;
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    SqlCommand cmd;
                    SqlDataReader dr;

                    ArrayList new_table = new ArrayList();

                    foreach (string table_name in table_names)
                    {
                        // My variables to store the data
                        ArrayList columnNames = new ArrayList();
                        ArrayList columnData;

                        ArrayList new_tableCol = new ArrayList();
                        ArrayList new_tableColRow;

                        // Prep for Retrieve column Names
                        string[] restrictionsColumns = new string[4];
                        restrictionsColumns[2] = table_name;
                        DataTable schemaColumns = conn.GetSchema("Columns", restrictionsColumns);

                        // Prep for Retrieve each column's dataset
                        cmd = conn.CreateCommand();
                        cmd.CommandText = "SELECT * FROM " + table_name + "";       // SQLite requires '' in table_name, but SQL dont need

                        foreach (DataRow rowColumn in schemaColumns.Rows)
                        {
                            // Retrieve column Names
                            new_tableColRow = new ArrayList();
                            string columnName = rowColumn[3].ToString();
                            new_tableColRow.Add(columnName);


                            // Retrieve each column's dataset
                            columnData = new ArrayList();
                            dr = cmd.ExecuteReader();
                            while (dr.Read())
                            {
                                string data = Convert.ToString(dr[columnName]);
                                new_tableColRow.Add(data);
                            }
                            dr.Close();

                            new_tableCol.Add(new_tableColRow);
                        }

                        new_table.Add(new_tableCol);
                    }
                    myArray = new_table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return myArray;
        }
        //--------------------------End---------------------------//


        //
        //  Settings And Languages Settings
        //
        //------------------------Start---------------------------//
        private void AppClose_Click(object sender, EventArgs e)                         // Close entire program
        {
            Application.Exit();
        }

        private void fullScreenToolStripMenuItem_Click(object sender, EventArgs e)      // Fullscreen
        {
            if (WindowState.ToString() == "Maximized")
                WindowState = FormWindowState.Normal;
            else if (WindowState.ToString() == "Normal")
                WindowState = FormWindowState.Maximized;
        }

        private void resizeToolStripMenuItem_Click(object sender, EventArgs e)          // Resize
        {
            if (FormBorderStyle.ToString() == "Sizable")
                FormBorderStyle = FormBorderStyle.None;
            else if (FormBorderStyle.ToString() == "None")
                FormBorderStyle = FormBorderStyle.Sizable;
        }

        private void defaultToolStripMenuItem_Click(object sender, EventArgs e)         // Default
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size (1413, 668);
            CenterToScreen();
        }

        private void EnglishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            language = "EN";
            if (languageToolStripMenuItem())
                EnglishToolStripMenuItem.CheckState = CheckState.Checked;               // Checked selected language
        }

        private void ChineseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            language = "CH";
            if (languageToolStripMenuItem())
                ChineseToolStripMenuItem.CheckState = CheckState.Checked;               // Checked selected language
        }

        private void RussianToolStripMenuItem_Click(object sender, EventArgs e)
        {
            language = "RU";
            if (languageToolStripMenuItem())
                RussianToolStripMenuItem.CheckState = CheckState.Checked;               // Checked selected language
        }

        private Boolean languageToolStripMenuItem()
        {
            if (!prev_language.Equals(language))                                    // Run change language only when neccessary
            {
                foreach (ToolStripMenuItem languageItem in language_Item.DropDownItems)     // Uncheck all languages
                {
                    languageItem.CheckState = CheckState.Unchecked;
                }

                if (current_userControl.Equals("FruitStore"))                               // Addon if new buttons
                {
                    // Langauge options settings
                    string[] languages_supported = { "EN", "CH", "RU" };
                    userControl_languageSupported = languages_supported;

                    toggle_sideNavi(btn_fruitStore, new FruitStore(), true);
                }
                else if (current_userControl.Equals("BigQuery"))
                {
                    // Langauge options settings
                    string[] languages_supported = { "EN", "CH" };
                    userControl_languageSupported = languages_supported;

                    toggle_sideNavi(btn_bigQuery, new BigQuery(), true);
                }
                else if (current_userControl.Equals("aws"))
                {
                    // Langauge options settings
                    string[] languages_supported = { "EN", "CH" };
                    userControl_languageSupported = languages_supported;

                    toggle_sideNavi(btn_aws, new aws(), true);
                }
                prev_language = language;
                return true;
            }
            return false;
        }
                                                                            
        public void modify_languageOptions()                 //Method used to display the options available
        {                                                    // Differs for every userControl page
            foreach (ToolStripMenuItem languageOption in language_Item.DropDownItems)
            {
                languageOption.Enabled = false;                          // Disables all options
                languageOption.ToolTipText = "Language not supported";
            }

            if (userControl_languageSupported != null)                      // Language options is supported
                foreach (string languageItem in userControl_languageSupported)
                    if (languageItem.Equals("EN"))
                        enable_language(EnglishToolStripMenuItem);          // Enables "EN"
                    else if (languageItem.Equals("CH"))
                        enable_language(ChineseToolStripMenuItem);          // Enables "CH"
                    else if (languageItem.Equals("RU"))
                        enable_language(RussianToolStripMenuItem);          // Enables "RU"
        }

        private void enable_language(ToolStripMenuItem languageItem)
        {
            languageItem.ToolTipText = null;
            languageItem.Enabled = true;         // Enables the language
        }


        private void checkCurrentLanguage()                                 // Checks if the current language is supported
        {
            if (userControl_languageSupported != null)                      // Language options is supported
                if (!(Array.IndexOf(userControl_languageSupported, language) > -1))         // If cuurent language not supported,
                    EnglishToolStripMenuItem.PerformClick();                                // reset to "EN"
        }
        //--------------------------End---------------------------//
    }
}
