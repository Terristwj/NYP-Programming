﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpotfireDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            UserControl userControl = new Dashboard();
            toggle_sideNavi(btn_dashboard, userControl, true);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            UserControl userControl = new Dashboard();
            toggle_sideNavi(btn_dashboard, userControl);
        }

        private void btn_visualizations_Click(object sender, EventArgs e)
        {
            UserControl userControl = new Visualizations();
            toggle_sideNavi(btn_visualizations, userControl);
        }

        private void btn_database_Click(object sender, EventArgs e)
        {
            UserControl usercontrol = new Database();
            toggle_sideNavi(btn_database, usercontrol);
        }

        private void toggle_sideNavi(Button sender, UserControl userControl, Boolean onload = false)
        {
            if (onload == false)
                panel2.Controls.RemoveAt(0);

            btn_dashboard.Enabled = true;
            btn_visualizations.Enabled = true;
            btn_database.Enabled = true;
            
            btn_dashboard.BackColor = Color.FromArgb(41, 53, 65);
            btn_visualizations.BackColor = Color.FromArgb(41, 53, 65);
            btn_database.BackColor = Color.FromArgb(41, 53, 65);


            sender.Enabled = false;
            sender.BackColor = Color.AliceBlue;

            panel2.Controls.Add(userControl);
            userControl.Dock = DockStyle.Fill;
        }

        private void fullScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WindowState.ToString() == "Maximized")
                WindowState = FormWindowState.Normal;
            else if (WindowState.ToString() == "Normal")
                WindowState = FormWindowState.Maximized;
        }

        private void resizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FormBorderStyle.ToString() == "Sizable")
                FormBorderStyle = FormBorderStyle.None;
            else if (FormBorderStyle.ToString() == "None")
                FormBorderStyle = FormBorderStyle.Sizable;
        }

        private void defaultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size (1413, 668);
            CenterToScreen();
        }
    }
}
