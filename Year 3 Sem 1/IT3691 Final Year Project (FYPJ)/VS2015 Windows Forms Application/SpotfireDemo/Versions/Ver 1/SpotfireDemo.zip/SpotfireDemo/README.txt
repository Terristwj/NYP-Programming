Spotfire Demo Project to test compatibility between TIBCO Spotfire and Windows Forms

Guide to start creating:
1.	Open Visual Studio
2.	Create Windows Forms (Ver 4.6)
3.	Create a web browser controller
4.	Link the url to Spotfire
5.	Start development
6.	Refer to the links aboves for development

Guide to open:
Alt 1.	Open Visual Studio
Alt 2.	Run .exe file inside project > bin > debug

Guide to use:
1.	View analyses
2.	Modify analyses
3.	Receive notifications



References

1	General
1.1	Prerequisites
TIBCO Spotfire: https://cloud.tibco.com/
Spotfire JavaScript API: https://community.tibco.com/wiki/tibco-spotfire-javascript-api-overview
Extending Spotfire: https://community.tibco.com/wiki/extending-tibco-spotfire#toc-9

1.2	Utilities
Comment Shortcut: https://community.dynamics.com/gp/b/gpdynland/archive/2017/06/10/changing-visual-studio-keyboard-shortcut-for-comment-and-uncomment
Free Icons: http://www.iconarchive.com/
Database Formats: https://fileinfo.com/filetypes/database


2	C# Coding
2.1	TIBCO Spotfire JavaScript API
Overview: https://community.tibco.com/wiki/tibco-spotfire-javascript-api-overview#toc-3

2.4	General



3	C# Windows Forms
3.1	Sections
UI Ideas: 
https://www.youtube.com/watch?v=tgqKd7l7_s8
https://www.youtube.com/watch?v=K9Ps66GoD-k

Full-Screen App:
https://www.youtube.com/watch?v=LPeMsjvLoco


3.2	Controls:
WebBrowser:
https://stackoverflow.com/questions/5362591/how-to-display-the-string-html-contents-into-webbrowser-control

Button:
https://stackoverflow.com/questions/17796151/close-form-button-event
https://stackoverflow.com/questions/48490184/visual-studio-windows-forms-button-background-color-selected-when-click

MenuStrip:
https://www.youtube.com/watch?v=_MwlrBouHWs

Form:
https://stackoverflow.com/questions/2891686/set-form-backcolor-to-custom-color
https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.form.size?view=netframework-4.8
https://stackoverflow.com/questions/4601827/how-do-i-center-a-window-onscreen-in-c

UserControl:
https://www.codeproject.com/Questions/156146/How-to-load-UserControl-into-panel
https://stackoverflow.com/questions/10871565/how-to-make-winforms-usercontrol-fill-the-size-of-its-container


