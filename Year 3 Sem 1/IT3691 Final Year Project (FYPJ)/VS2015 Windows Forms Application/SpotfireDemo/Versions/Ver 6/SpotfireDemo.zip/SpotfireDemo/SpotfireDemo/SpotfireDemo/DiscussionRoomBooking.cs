﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// SQL client
using System.Configuration;
using System.Data.SqlClient;
// ArrayList
using System.Collections;
using System.Threading;

namespace SpotfireDemo
{
    public partial class DiscussionRoomBooking : UserControl
    {
        // Declared borrowed variables
        SqlConnection conn = null;

        // For image folder
        string imageFolder_initialUrl = "../.././Images/DiscussionRoomBooking/";

        // Raspberry Pi related
        DataComms dataComms = SpotfireDemo.dataComms;
        public delegate void myProcessDataDelegate(string strData);

        // As this is a demo, I will be using dateTime of student arrival as booking_ID
        string bookingID_usingDateTime;                                 

        public DiscussionRoomBooking()
        {
            InitializeComponent();
        }

        private void DiscussionRoomBooking_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            conn = SpotfireDemo.conn;

            // Load images
            loadImages_firstTime();

            // Load Raspberry Pi integrated codes
            InitComms();
        }

        /*=======================================================
                            Load Images
        =======================================================*/
        private void loadImages_firstTime()
        {
            string status = "off";
            imageFor_keyCard(status);
            imageFor_lights(status);
            imageFor_motion(status);
            imageFor_buzzer(status);
            imageFor_button(status);
            imageFor_redLED(status);
            imageFor_greenLED(status);
        }
        private void loadImages_lastTime()
        {
            string status = "off";
            imageFor_keyCard(status);
            imageFor_lights(status);
            imageFor_motion(status);
            imageFor_buzzer("on");
            imageFor_button("on");
            imageFor_redLED(status);
            imageFor_greenLED(status);
            
            Wait(1000);
            imageFor_buzzer("off");
        }

        private void imageFor_keyCard(string status)
        {
            if (status == "on")
                pb_keyCard.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "keycardon.png");
            else if (status == "off")
                pb_keyCard.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "keycardoff.png");
        }
        private void imageFor_lights(string status)
        {
            if (status == "on")
                pb_lights.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "lighton.png");
            else if (status == "off")
                pb_lights.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "lightoff.png");
        }
        private void imageFor_motion(string status)
        {
            if (status == "on")
                pb_motion.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "motionfalse.png");
            else if (status == "off")
                pb_motion.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "motiontrue.png");
        }
        private void imageFor_buzzer(string status)
        {
            if (status == "on")
                pb_buzzer.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "buzzeron.png");
            else if (status == "off")
                pb_buzzer.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "buzzeroff.png");
        }
        private void imageFor_button(string status)
        {
            if (status == "on")
                pb_button.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "buttonpress.jpg");
            else if (status == "off")
                pb_button.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "button.png");
        }
        private void imageFor_redLED(string status)
        {
            if (status == "on")
                pb_redLED.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "lightonred.png");
            else if (status == "off")
                pb_redLED.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "lightoff.png");
        }
        private void imageFor_greenLED(string status)
        {
            if (status == "on")
                pb_greenLED.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "lightongreen.png");
            else if (status == "off")
                pb_greenLED.BackgroundImage = Image.FromFile(imageFolder_initialUrl + "lightoff.png");
        }
        /*-----------------------End---------------------------*/

        /*=======================================================
                            Utility Methods
        =======================================================*/
        private float extractFloatValue(string strData, string ID)
        {
            return (float.Parse(extractStringValue(strData, ID)));                      // Utility to extract float value from data
        }

        private string extractStringValue(string strData, string ID)                    // Utility to extract string value from data
        {
            string result = strData.Substring(strData.IndexOf(ID) + ID.Length);
            return result;
        }
        public void Wait(int time_second)                                               // Wait for specified seconds without affecting loading parts
        {
            Thread thread = new Thread(delegate ()
            {
                System.Threading.Thread.Sleep(time_second);
            });
            thread.Start();
            while (thread.IsAlive)
                Application.DoEvents();
        }
        /*-----------------------End---------------------------*/


        /*=======================================================
         
               Below controls the dataComms to IoT Raspberry
         
        =======================================================*/
        private void btn_clearComms_Click(object sender, EventArgs e)
        {
            lb_DataComms.Items.Clear();
        }

        private void InitComms()                // Starts connection to IoT Background Application
        {
            dataComms.dataReceiveEvent += new DataComms.DataReceivedDelegate(commsDataReceive);
            dataComms.dataSendErrorEvent += new DataComms.DataSendErrorDelegate(commsSendError);
        }

        public void commsDataReceive(string dataReceived)       // Auto-triggers when data is received
        {
            processDataReceive(dataReceived);
        }

        public void commsSendError(string errMsg)               // Auto-triggers when error
        {
            MessageBox.Show(errMsg);
            processDataReceive(errMsg);
        }

        public void processDataReceive(string strData)          // Process the message (Data or Error)
        {
            myProcessDataDelegate dataD = new myProcessDataDelegate(handleSensorData);  // Start of message retreival
            lb_DataComms.Invoke(dataD, new object[] { strData });
        }
        
        public void handleSensorData(string strData)        
        {
            string dateTime = DateTime.Now.ToString("s");
            extractSensorData(strData, dateTime);

            string strMessage = dateTime + ":" + strData;                              //Uncomment this to debug IoT sensor reading
            lb_DataComms.Items.Insert(0, strMessage);
        }

        private void fill_logs(string[] myMessages)
        {
            myMessages.Reverse();                                                       // Reverse so fill_logs will present in top-bottom order
            lb_DataComms.Items.Insert(0, " ");                                          // Add empty line

            foreach (string message in myMessages)                                      // Add messages into logs
                lb_DataComms.Items.Insert(0, message);
        }
        
        private void extractSensorData(string strData, string strTime)                  // Add sensors here
        {
            // Raspberry Pi can send any type of data
            // Check type of data before extraction



            ///********************************///
            ///*  Add sensor data types here  *///
            ///                                ///
            ///********************************///
            
            // Admin data types
            if (strData.IndexOf("CONNECTION=") != -1)                        // Connection check
                handle_Connection();
            else if (strData.IndexOf("WRONGCARD=") != -1)                    // Card check - Used to also create booking Id
                handle_WrongCard(strData, "WRONGCARD=");
            else if (strData.IndexOf("BEGIN=") != -1)                        // Begin sensor data collection
                handle_begin(strData, "BEGIN=");

            // Sensor data types
            else if (strData.IndexOf("CARDTAP=") != -1)                      // RFID Sensor - number of taps
                handle_cardTap(strData, strTime, "CARDTAP=");
            else if (strData.IndexOf("REDLED=") != -1)                       // redLED Sensor - Booking but no card tap yet
                handle_redLED(strData, strTime, "REDLED=");
            else if (strData.IndexOf("GREENLED=") != -1)                     // greenLED Sensor - Booking and have at least one card tap
                handle_greenLED(strData, strTime, "GREENLED=");

            else if (strData.IndexOf("LIGHT=") != -1)                        // Light Sensor
                handle_lightData(strData, strTime, "LIGHT=");
            //else if (strData.IndexOf("BUTTON=") != -1)                     // Button Sensor - Never used because used to alrdy end simulation
                //handle_ButtonData(strTime);  
            else if (strData.IndexOf("MOTION=") != -1)                       // PIR Motion Sensor            
                handle_motionData(strData, strTime, "MOTION=");

            // Buzzer alarm if no movement. Adjust duration cap in (IoT) Background App
            else if (strData.IndexOf("BUZZER=") != -1)                       // PIR Motion Sensor + Buzzer Sensor   - Alarm
                handle_buzzer(strData, strTime, "BUZZER=");
        }

        private void handle_Connection()
        {
            // Each string in myMessage represents 1 sentence
            String[] myMessages = { "Connection to IoT is successful", "Beginning IoT Simulation", "Tap card to begin" };
            fill_logs(myMessages);
        }
        private void handle_WrongCard(string strData, string ID)
        {
            string cardNumber = extractStringValue(strData, ID);

            // Each string in myMessage represents 1 sentence
            String[] myMessages = { "This card is not accessible", "Please use card ID: " + cardNumber };
            fill_logs(myMessages);
        }
        private void handle_begin(string strData, string ID)
        {
            string strValue = extractStringValue(strData, ID);
            string dateTime = DateTime.Now.ToString("s");

            // Each string in myMessage represents 1 sentence
            String[] myMessages = new string[1];
            if (strValue.Equals("True"))
            {
                myMessages[0] = "Students arrived for their booking at " + dateTime;
                imageFor_keyCard("on");

                imageFor_buzzer("on");
                Wait(500);
                imageFor_buzzer("off");


                bookingID_usingDateTime = dateTime;                // This bookingID will be used for all sensor data in this session
            }
            else
            {
                myMessages[0] = "Ending IoT Simulation";
                loadImages_lastTime();                             // "off" image for all
            }
            fill_logs(myMessages);
        }
        private void handle_cardTap(string strData, string strTime, string ID)                   // RFID - number of taps.  Includes aw short buzzer sound
        {
            string strCardTap = extractStringValue(strData, ID);
            // Each string in myMessage represents 1 sentence
            String[] myMessages = { "Total number of card taps: " + strCardTap };
            fill_logs(myMessages);

            lb_tapCount.Text = "Tap Count: " + strCardTap;      // Display change on UI

            saveToDB_cardTap(strCardTap);
        }
        private void handle_redLED(string strData, string strTime, string ID)                   // redLED - student yet to enter room
        {
            string strCardTap = extractStringValue(strData, ID);
            imageFor_redLED(strCardTap.ToLower());
        }
        private void handle_greenLED(string strData, string strTime, string ID)                   // greenLED - student entered room
        {
            string strCardTap = extractStringValue(strData, ID);
            imageFor_greenLED(strCardTap.ToLower());
        }
        private void handle_lightData(string strData, string strTime, string ID)                   // Light sensor data
        {
            string strLightValue = extractStringValue(strData, ID);
            float fLightValue = extractFloatValue(strData, ID);
            string status = "";
            string isBright = "";

            // Each string in myMessage represents 1 sentence
            String[] myMessages = new string[1];
            if (fLightValue <= 500)
            {
                status = "Dark";
                isBright = "0";
                myMessages[0] = "Lights are off";
                imageFor_lights("off");
            }
            else
            {
                myMessages[0] = "Lights are on";
                isBright = "1";
                status = "Bright";
                imageFor_lights("on");
            }
            fill_logs(myMessages);

            saveToDB_lightData(strLightValue, status, isBright);
        }
        private void handle_buttonData(string strTime)                                       // Button sensor data - Not in use
        {
            saveToDB(strTime);
        }
        private void handle_motionData(string strData, string strTime, string ID)           // PIR Motion sensor data
        {
            string strMotionValue = extractStringValue(strData, ID);

            // Each string in myMessage represents 1 sentence
            String[] myMessages = new string[1];
            string motionTrue = "";
            if (strMotionValue.Equals("True"))
            {
                myMessages[0] = "Movement";
                motionTrue = "1";
                imageFor_motion("on");
            }
            else
            {
                myMessages[0] = "No movement";
                motionTrue = "0";
                imageFor_motion("off");
            }
            fill_logs(myMessages);

            saveToDB_motionData(motionTrue);
        }

        private void handle_buzzer(string strData, string strTime, string ID)           // PIR Motion sensor data
        {
            string strBuzzerCapValue = extractStringValue(strData, ID);

            String[] myMessages = { "Buzzer alarm rang", "No motion was detected for " + strBuzzerCapValue + " seconds"};
            fill_logs(myMessages);

            imageFor_buzzer("on");
            saveToDB_buzzer(strBuzzerCapValue);
            Wait(10000);       // Wait 10 seconds then reset back to buzzer off
            imageFor_buzzer("off");
        }


        /*=======================================================
         
                        Save to Database codes
         
        =======================================================*/
        private void saveToDB(string sensorValue)     // Just for sample
        {
            string query = "INSERT SensorData (booking_id, sensorName, sensorValue) Values (@booking_id, @sensorName, @sensorValue)";
            string cmd = "new SqlCommand(query, conn)";
            string cmd_Parameters_AddWithValue = "(...)";

            string result = "cmd.ExecuteNonQuery()";
        }
        private void saveToDB_cardTap(string cardTap_count)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT SensorData (booking_id, sensorName, card_numTaps) Values (@booking_id, @sensorName, @card_numTaps)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@booking_id", bookingID_usingDateTime);
                    cmd.Parameters.AddWithValue("@sensorName", "RFID");
                    cmd.Parameters.AddWithValue("@card_numTaps", cardTap_count);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        private void saveToDB_lightData(string strLightValue, string status, string isBright)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT SensorData (booking_id, sensorName, light_lightValue, light_lightStatus, light_brightTrue) Values (@booking_id, @sensorName, @light_lightValue, @light_lightStatus, @light_brightTrue)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@booking_id", bookingID_usingDateTime);
                    cmd.Parameters.AddWithValue("@sensorName", "Light");
                    cmd.Parameters.AddWithValue("@light_lightValue", strLightValue);
                    cmd.Parameters.AddWithValue("@light_lightStatus", status);
                    cmd.Parameters.AddWithValue("@light_brightTrue", isBright);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        private void saveToDB_motionData(string motionTrue)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT SensorData (booking_id, sensorName, pir_motionTrue) Values (@booking_id, @sensorName, @pir_motionTrue)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@booking_id", bookingID_usingDateTime);
                    cmd.Parameters.AddWithValue("@sensorName", "PIR");
                    cmd.Parameters.AddWithValue("@pir_motionTrue", motionTrue);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        private void saveToDB_buzzer(string secondsNoMotion)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string query = "INSERT SensorData (booking_id, sensorName, buzzer_timeRang, buzzer_secondsNoMotion) Values (@booking_id, @sensorName, @buzzer_timeRang, @buzzer_secondsNoMotion)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@booking_id", bookingID_usingDateTime);
                    cmd.Parameters.AddWithValue("@sensorName", "Buzzer");
                    cmd.Parameters.AddWithValue("@buzzer_timeRang", DateTime.Now);
                    cmd.Parameters.AddWithValue("@buzzer_secondsNoMotion", secondsNoMotion);

                    int result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
