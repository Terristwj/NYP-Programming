﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// SQL client
using System.Data.SqlClient;
// Arraylust
using System.Collections;

namespace SpotfireDemo
{
    public partial class SpotfireDemo : Form
    {
        public static SqlConnection conn;
        public static ArrayList table_names = null;
        public static ArrayList dataSet_table = null;

        // Inuse: FruitStore
        public static string language = "EN";
        public static string prev_language = "EN";

        // Raspberry Pi related
        public static DataComms dataComms = new DataComms();

        public SpotfireDemo()
        {
            InitializeComponent();

            // Onload, click the dashboard tab
            UserControl userControl = new Homepage();
            toggle_sideNavi(btn_home, userControl, false, true);
        }



        //
        //  Buttons
        //
        //------------------------Start---------------------------//
        private void btn_home_Click(object sender, EventArgs e)
        {
            toggle_sideNavi(btn_home, new Homepage());
        }
        private void btn_fruitStore_Click(object sender, EventArgs e)
        {
            // Connect FruitStore Database
            conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=SpotfireDemo FruitStore;Integrated Security=True");
            // Get data
            get_DatabaseInformation();

            toggle_sideNavi(btn_fruitStore, new FruitStore(), true);
        }

        private void btn_discussionRoomBooking_Click(object sender, EventArgs e)
        {
            // Connect FruitStore Database
            conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DiscussionRoomBooking;Integrated Security=True");
            // Get data
            get_DatabaseInformation();

            toggle_sideNavi(btn_discussionRoomBooking, new DiscussionRoomBooking());
        }

        private void get_DatabaseInformation()
        {
            // Create a new set of table names:
            set_table_names();

            // Create data set with the new connection
            dataSet_table = get_databaseValues();
        }


        private void toggle_sideNavi(Button sender, UserControl userControl, Boolean hasLanguages = false, Boolean onload = false)    // When corresponding navigation tab is clicked
        {
            // To remove the current mainContent
            if (onload == false)
                panel_mainContent.Controls.RemoveAt(0);


            // Check to see if supports other languages
            if (hasLanguages)
                language_Item.DisplayStyle = ToolStripItemDisplayStyle.Text;
            else
                language_Item.DisplayStyle = ToolStripItemDisplayStyle.None;


            // Manages the CSS of all buttons to default
            Button[] buttons = new Button[] { btn_home, btn_fruitStore, btn_discussionRoomBooking};          // IMPORTANT to add on if new side navigation buttons
            foreach (Button button in buttons)
            {
                button.Enabled = true;
                button.BackColor = Color.FromArgb(41, 53, 65);
            }

            // Manages the CSS of clicked button
            sender.Enabled = false;
            sender.BackColor = Color.AliceBlue;

            // To add the new mainContent
            panel_mainContent.Controls.Add(userControl);
            userControl.Dock = DockStyle.Fill;
        }
        //--------------------------End---------------------------//


        //
        //  Get Database Information
        //
        //------------------------Start---------------------------//
        private void set_table_names()
        {
            // Resets Array
            table_names = new ArrayList();
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    DataTable schema = conn.GetSchema("Tables");

                    // Get table names and fills in
                    foreach (DataRow row in schema.Rows)
                    {
                        string tablename = (string)row[2];
                        table_names.Add(tablename);
                    }
                    table_names.Sort();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        private ArrayList get_databaseValues()
        {
            ArrayList myArray = null;
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    SqlCommand cmd;
                    SqlDataReader dr;

                    ArrayList new_table = new ArrayList();

                    foreach (string table_name in table_names)
                    {
                        // My variables to store the data
                        ArrayList columnNames = new ArrayList();
                        ArrayList columnData;

                        ArrayList new_tableCol = new ArrayList();
                        ArrayList new_tableColRow;

                        // Prep for Retrieve column Names
                        string[] restrictionsColumns = new string[4];
                        restrictionsColumns[2] = table_name;
                        DataTable schemaColumns = conn.GetSchema("Columns", restrictionsColumns);

                        // Prep for Retrieve each column's dataset
                        cmd = conn.CreateCommand();
                        cmd.CommandText = "SELECT * FROM " + table_name + "";       // SQLite requires '' in table_name, but SQL dont need

                        foreach (DataRow rowColumn in schemaColumns.Rows)
                        {
                            // Retrieve column Names
                            new_tableColRow = new ArrayList();
                            string columnName = rowColumn[3].ToString();
                            new_tableColRow.Add(columnName);


                            // Retrieve each column's dataset
                            columnData = new ArrayList();
                            dr = cmd.ExecuteReader();
                            while (dr.Read())
                            {
                                string data = Convert.ToString(dr[columnName]);
                                new_tableColRow.Add(data);
                            }
                            dr.Close();

                            new_tableCol.Add(new_tableColRow);
                        }

                        new_table.Add(new_tableCol);
                    }
                    myArray = new_table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return myArray;
        }
        //--------------------------End---------------------------//


        //
        //  Settings
        //
        //------------------------Start---------------------------//
        private void AppClose_Click(object sender, EventArgs e)                         // Close entire program
        {
            Application.Exit();
        }

        private void fullScreenToolStripMenuItem_Click(object sender, EventArgs e)      // Fullscreen
        {
            if (WindowState.ToString() == "Maximized")
                WindowState = FormWindowState.Normal;
            else if (WindowState.ToString() == "Normal")
                WindowState = FormWindowState.Maximized;
        }

        private void resizeToolStripMenuItem_Click(object sender, EventArgs e)          // Resize
        {
            if (FormBorderStyle.ToString() == "Sizable")
                FormBorderStyle = FormBorderStyle.None;
            else if (FormBorderStyle.ToString() == "None")
                FormBorderStyle = FormBorderStyle.Sizable;
        }

        private void defaultToolStripMenuItem_Click(object sender, EventArgs e)         // Default
        {
            WindowState = FormWindowState.Normal;
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size (1413, 668);
            CenterToScreen();
        }

        private void EnglishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            language = "EN";
            if (languageToolStripMenuItem())
                EnglishToolStripMenuItem.CheckState = CheckState.Checked;               // Checked selected language
        }

        private void ChineseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            language = "CH";
            if (languageToolStripMenuItem())
                ChineseToolStripMenuItem.CheckState = CheckState.Checked;               // Checked selected language
        }

        private void RussianToolStripMenuItem_Click(object sender, EventArgs e)
        {
            language = "RU";
            if (languageToolStripMenuItem())
                RussianToolStripMenuItem.CheckState = CheckState.Checked;               // Checked selected language
        }

        private Boolean languageToolStripMenuItem()
        {
            if (!prev_language.Equals(language))                                    // Run change language only when neccessary
            {
                foreach (ToolStripMenuItem language in language_Item.DropDownItems)     // Uncheck all languages
                {
                    language.CheckState = CheckState.Unchecked;
                }
                toggle_sideNavi(btn_fruitStore, new FruitStore(), true);
                prev_language = language;
                return true;
            }
            return false;
        }
        //--------------------------End---------------------------//
    }
}
