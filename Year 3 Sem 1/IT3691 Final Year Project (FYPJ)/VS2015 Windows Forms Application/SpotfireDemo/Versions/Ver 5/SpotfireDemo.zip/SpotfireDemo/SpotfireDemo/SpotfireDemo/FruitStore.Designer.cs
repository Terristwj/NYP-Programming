﻿namespace SpotfireDemo
{
    partial class FruitStore
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FruitStore));
            this.panel2 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_durian_plus5 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.btn_mango_plus5 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btn_lemon_plus5 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.btn_banana_plus5 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.btn_dragonfruit_plus5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btn_watermelon_plus5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.btn_kiwi_plus5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_orange_plus5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_pear_plus5 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_apple_plus4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(813, 525);
            this.panel2.TabIndex = 1;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 50);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(15);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(813, 475);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.button8);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Location = new System.Drawing.Point(18, 18);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(184, 216);
            this.panel4.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(0, 150);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(182, 64);
            this.button8.TabIndex = 3;
            this.button8.Text = "Stock: Num";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(182, 150);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightCyan;
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(813, 50);
            this.button6.TabIndex = 3;
            this.button6.Text = "Inventory";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(813, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(373, 525);
            this.panel1.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.AutoScroll = true;
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.btn_durian_plus5);
            this.panel7.Controls.Add(this.button14);
            this.panel7.Controls.Add(this.btn_mango_plus5);
            this.panel7.Controls.Add(this.button10);
            this.panel7.Controls.Add(this.btn_lemon_plus5);
            this.panel7.Controls.Add(this.button13);
            this.panel7.Controls.Add(this.btn_banana_plus5);
            this.panel7.Controls.Add(this.button11);
            this.panel7.Controls.Add(this.btn_dragonfruit_plus5);
            this.panel7.Controls.Add(this.button9);
            this.panel7.Controls.Add(this.btn_watermelon_plus5);
            this.panel7.Controls.Add(this.button7);
            this.panel7.Controls.Add(this.btn_kiwi_plus5);
            this.panel7.Controls.Add(this.button4);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.btn_orange_plus5);
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.btn_pear_plus5);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Controls.Add(this.btn_apple_plus4);
            this.panel7.Controls.Add(this.button3);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(70, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(233, 475);
            this.panel7.TabIndex = 5;
            // 
            // btn_durian_plus5
            // 
            this.btn_durian_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_durian_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_durian_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_durian_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_durian_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_durian_plus5.Location = new System.Drawing.Point(0, 753);
            this.btn_durian_plus5.Name = "btn_durian_plus5";
            this.btn_durian_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_durian_plus5.TabIndex = 25;
            this.btn_durian_plus5.Tag = "";
            this.btn_durian_plus5.Text = "Add 5 Durians";
            this.btn_durian_plus5.UseVisualStyleBackColor = false;
            this.btn_durian_plus5.Click += new System.EventHandler(this.btn_durian_plus5_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Cursor = System.Windows.Forms.Cursors.Default;
            this.button14.Dock = System.Windows.Forms.DockStyle.Top;
            this.button14.Enabled = false;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(0, 738);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(216, 15);
            this.button14.TabIndex = 24;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // btn_mango_plus5
            // 
            this.btn_mango_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_mango_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_mango_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_mango_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mango_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mango_plus5.Location = new System.Drawing.Point(0, 671);
            this.btn_mango_plus5.Name = "btn_mango_plus5";
            this.btn_mango_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_mango_plus5.TabIndex = 23;
            this.btn_mango_plus5.Tag = "";
            this.btn_mango_plus5.Text = "Add 5 Mangoes";
            this.btn_mango_plus5.UseVisualStyleBackColor = false;
            this.btn_mango_plus5.Click += new System.EventHandler(this.btn_mango_plus5_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Cursor = System.Windows.Forms.Cursors.Default;
            this.button10.Dock = System.Windows.Forms.DockStyle.Top;
            this.button10.Enabled = false;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(0, 656);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(216, 15);
            this.button10.TabIndex = 22;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.btn_lemon_plus5_Click);
            // 
            // btn_lemon_plus5
            // 
            this.btn_lemon_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_lemon_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_lemon_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_lemon_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_lemon_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lemon_plus5.Location = new System.Drawing.Point(0, 589);
            this.btn_lemon_plus5.Name = "btn_lemon_plus5";
            this.btn_lemon_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_lemon_plus5.TabIndex = 21;
            this.btn_lemon_plus5.Tag = "";
            this.btn_lemon_plus5.Text = "Add 5 Lemons";
            this.btn_lemon_plus5.UseVisualStyleBackColor = false;
            this.btn_lemon_plus5.Click += new System.EventHandler(this.btn_lemon_plus5_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Cursor = System.Windows.Forms.Cursors.Default;
            this.button13.Dock = System.Windows.Forms.DockStyle.Top;
            this.button13.Enabled = false;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(0, 574);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(216, 15);
            this.button13.TabIndex = 20;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // btn_banana_plus5
            // 
            this.btn_banana_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_banana_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_banana_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_banana_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_banana_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_banana_plus5.Location = new System.Drawing.Point(0, 507);
            this.btn_banana_plus5.Name = "btn_banana_plus5";
            this.btn_banana_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_banana_plus5.TabIndex = 19;
            this.btn_banana_plus5.Tag = "";
            this.btn_banana_plus5.Text = "Add 5 Bananas";
            this.btn_banana_plus5.UseVisualStyleBackColor = false;
            this.btn_banana_plus5.Click += new System.EventHandler(this.btn_banana_plus5_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Cursor = System.Windows.Forms.Cursors.Default;
            this.button11.Dock = System.Windows.Forms.DockStyle.Top;
            this.button11.Enabled = false;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(0, 492);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(216, 15);
            this.button11.TabIndex = 18;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // btn_dragonfruit_plus5
            // 
            this.btn_dragonfruit_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_dragonfruit_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_dragonfruit_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_dragonfruit_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dragonfruit_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dragonfruit_plus5.Location = new System.Drawing.Point(0, 425);
            this.btn_dragonfruit_plus5.Name = "btn_dragonfruit_plus5";
            this.btn_dragonfruit_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_dragonfruit_plus5.TabIndex = 17;
            this.btn_dragonfruit_plus5.Tag = "";
            this.btn_dragonfruit_plus5.Text = "Add 5 Dragon Fruits";
            this.btn_dragonfruit_plus5.UseVisualStyleBackColor = false;
            this.btn_dragonfruit_plus5.Click += new System.EventHandler(this.btn_dragonfruit_plus5_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Cursor = System.Windows.Forms.Cursors.Default;
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.Enabled = false;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(0, 410);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(216, 15);
            this.button9.TabIndex = 16;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // btn_watermelon_plus5
            // 
            this.btn_watermelon_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_watermelon_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_watermelon_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_watermelon_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_watermelon_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_watermelon_plus5.Location = new System.Drawing.Point(0, 343);
            this.btn_watermelon_plus5.Name = "btn_watermelon_plus5";
            this.btn_watermelon_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_watermelon_plus5.TabIndex = 15;
            this.btn_watermelon_plus5.Tag = "";
            this.btn_watermelon_plus5.Text = "Add 5 Watermelons";
            this.btn_watermelon_plus5.UseVisualStyleBackColor = false;
            this.btn_watermelon_plus5.Click += new System.EventHandler(this.btn_watermelon_plus5_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Cursor = System.Windows.Forms.Cursors.Default;
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.Enabled = false;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(0, 333);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(216, 10);
            this.button7.TabIndex = 14;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // btn_kiwi_plus5
            // 
            this.btn_kiwi_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_kiwi_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_kiwi_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_kiwi_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kiwi_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kiwi_plus5.Location = new System.Drawing.Point(0, 266);
            this.btn_kiwi_plus5.Name = "btn_kiwi_plus5";
            this.btn_kiwi_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_kiwi_plus5.TabIndex = 13;
            this.btn_kiwi_plus5.Tag = "";
            this.btn_kiwi_plus5.Text = "Add 5 Kiwis";
            this.btn_kiwi_plus5.UseVisualStyleBackColor = false;
            this.btn_kiwi_plus5.Click += new System.EventHandler(this.btn_kiwi_plus5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Cursor = System.Windows.Forms.Cursors.Default;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.Enabled = false;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(0, 251);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(216, 15);
            this.button4.TabIndex = 12;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 820);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(216, 20);
            this.panel8.TabIndex = 5;
            // 
            // btn_orange_plus5
            // 
            this.btn_orange_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_orange_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_orange_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_orange_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_orange_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_orange_plus5.Location = new System.Drawing.Point(0, 184);
            this.btn_orange_plus5.Name = "btn_orange_plus5";
            this.btn_orange_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_orange_plus5.TabIndex = 6;
            this.btn_orange_plus5.Tag = "";
            this.btn_orange_plus5.Text = "Add 5 Oranges";
            this.btn_orange_plus5.UseVisualStyleBackColor = false;
            this.btn_orange_plus5.Click += new System.EventHandler(this.btn_orange_plus5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Cursor = System.Windows.Forms.Cursors.Default;
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.Enabled = false;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(0, 169);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(216, 15);
            this.button2.TabIndex = 11;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btn_pear_plus5
            // 
            this.btn_pear_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_pear_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pear_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_pear_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pear_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pear_plus5.Location = new System.Drawing.Point(0, 102);
            this.btn_pear_plus5.Name = "btn_pear_plus5";
            this.btn_pear_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_pear_plus5.TabIndex = 10;
            this.btn_pear_plus5.Tag = "";
            this.btn_pear_plus5.Text = "Add 5 Pears";
            this.btn_pear_plus5.UseVisualStyleBackColor = false;
            this.btn_pear_plus5.Click += new System.EventHandler(this.btn_pear_plus5_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Cursor = System.Windows.Forms.Cursors.Default;
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.Enabled = false;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(0, 87);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(216, 15);
            this.button5.TabIndex = 9;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // btn_apple_plus4
            // 
            this.btn_apple_plus4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_apple_plus4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_apple_plus4.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_apple_plus4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_apple_plus4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_apple_plus4.Location = new System.Drawing.Point(0, 20);
            this.btn_apple_plus4.Name = "btn_apple_plus4";
            this.btn_apple_plus4.Size = new System.Drawing.Size(216, 67);
            this.btn_apple_plus4.TabIndex = 8;
            this.btn_apple_plus4.Tag = "";
            this.btn_apple_plus4.Text = "Add 5 Apples";
            this.btn_apple_plus4.UseVisualStyleBackColor = false;
            this.btn_apple_plus4.Click += new System.EventHandler(this.btn_apple_plus4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Cursor = System.Windows.Forms.Cursors.Default;
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.Enabled = false;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(216, 20);
            this.button3.TabIndex = 7;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(303, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(70, 475);
            this.panel5.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(70, 475);
            this.panel3.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(373, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "Controls";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.AutoScroll = true;
            this.panel9.Controls.Add(this.panel7);
            this.panel9.Controls.Add(this.panel5);
            this.panel9.Controls.Add(this.panel3);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 50);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(373, 475);
            this.panel9.TabIndex = 2;
            // 
            // FruitStore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "FruitStore";
            this.Size = new System.Drawing.Size(1186, 525);
            this.Load += new System.EventHandler(this.FruitStore_Load);
            this.panel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_orange_plus5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_banana_plus5;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button btn_dragonfruit_plus5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btn_watermelon_plus5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btn_kiwi_plus5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_pear_plus5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btn_apple_plus4;
        private System.Windows.Forms.Button btn_lemon_plus5;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_durian_plus5;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button btn_mango_plus5;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel9;
    }
}
