﻿namespace SpotfireDemo
{
    partial class DiscussionRoomBooking
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiscussionRoomBooking));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.pb_keyCard = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.pb_lights = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pb_motion = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.pb_buzzer = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.pb_button = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.pb_redLED = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.pb_greenLED = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lb_DataComms = new System.Windows.Forms.ListBox();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_clearComms = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lb_tapCount = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel15.SuspendLayout();
            this.flowLayoutPanel9.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_keyCard)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lights)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_motion)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_buzzer)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_button)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_redLED)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_greenLED)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(813, 525);
            this.panel1.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.flowLayoutPanel9);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 50);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(813, 410);
            this.panel15.TabIndex = 7;
            // 
            // flowLayoutPanel9
            // 
            this.flowLayoutPanel9.AutoScroll = true;
            this.flowLayoutPanel9.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel9.Controls.Add(this.panel3);
            this.flowLayoutPanel9.Controls.Add(this.panel12);
            this.flowLayoutPanel9.Controls.Add(this.panel5);
            this.flowLayoutPanel9.Controls.Add(this.panel9);
            this.flowLayoutPanel9.Controls.Add(this.panel10);
            this.flowLayoutPanel9.Controls.Add(this.panel11);
            this.flowLayoutPanel9.Controls.Add(this.panel13);
            this.flowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel9.Name = "flowLayoutPanel9";
            this.flowLayoutPanel9.Padding = new System.Windows.Forms.Padding(18);
            this.flowLayoutPanel9.Size = new System.Drawing.Size(813, 410);
            this.flowLayoutPanel9.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lb_tapCount);
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.pb_keyCard);
            this.panel3.Location = new System.Drawing.Point(21, 21);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(184, 216);
            this.panel3.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.LightCyan;
            this.button8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(0, 150);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(182, 64);
            this.button8.TabIndex = 3;
            this.button8.Text = "Key Card";
            this.button8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // pb_keyCard
            // 
            this.pb_keyCard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_keyCard.BackgroundImage")));
            this.pb_keyCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_keyCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_keyCard.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_keyCard.Location = new System.Drawing.Point(0, 0);
            this.pb_keyCard.Name = "pb_keyCard";
            this.pb_keyCard.Size = new System.Drawing.Size(182, 150);
            this.pb_keyCard.TabIndex = 0;
            this.pb_keyCard.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.button7);
            this.panel12.Controls.Add(this.pb_lights);
            this.panel12.Location = new System.Drawing.Point(211, 21);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(184, 216);
            this.panel12.TabIndex = 4;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightCyan;
            this.button7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(0, 150);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(182, 64);
            this.button7.TabIndex = 3;
            this.button7.Text = "Lights";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // pb_lights
            // 
            this.pb_lights.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_lights.BackgroundImage")));
            this.pb_lights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_lights.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_lights.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_lights.Location = new System.Drawing.Point(0, 0);
            this.pb_lights.Name = "pb_lights";
            this.pb_lights.Size = new System.Drawing.Size(182, 150);
            this.pb_lights.TabIndex = 0;
            this.pb_lights.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.pb_motion);
            this.panel5.Location = new System.Drawing.Point(401, 21);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(184, 216);
            this.panel5.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCyan;
            this.button2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(0, 150);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(182, 64);
            this.button2.TabIndex = 3;
            this.button2.Text = "Motion";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // pb_motion
            // 
            this.pb_motion.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_motion.BackgroundImage")));
            this.pb_motion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_motion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_motion.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_motion.Location = new System.Drawing.Point(0, 0);
            this.pb_motion.Name = "pb_motion";
            this.pb_motion.Size = new System.Drawing.Size(182, 150);
            this.pb_motion.TabIndex = 0;
            this.pb_motion.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.button3);
            this.panel9.Controls.Add(this.pb_buzzer);
            this.panel9.Location = new System.Drawing.Point(591, 21);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(184, 216);
            this.panel9.TabIndex = 4;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightCyan;
            this.button3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(0, 150);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(182, 64);
            this.button3.TabIndex = 3;
            this.button3.Text = "Buzzer";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // pb_buzzer
            // 
            this.pb_buzzer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_buzzer.BackgroundImage")));
            this.pb_buzzer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_buzzer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_buzzer.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_buzzer.Location = new System.Drawing.Point(0, 0);
            this.pb_buzzer.Name = "pb_buzzer";
            this.pb_buzzer.Size = new System.Drawing.Size(182, 150);
            this.pb_buzzer.TabIndex = 0;
            this.pb_buzzer.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.button4);
            this.panel10.Controls.Add(this.pb_button);
            this.panel10.Location = new System.Drawing.Point(21, 243);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(184, 216);
            this.panel10.TabIndex = 4;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightCyan;
            this.button4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(0, 150);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(182, 64);
            this.button4.TabIndex = 3;
            this.button4.Text = "Button";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // pb_button
            // 
            this.pb_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_button.BackgroundImage")));
            this.pb_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_button.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_button.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_button.Location = new System.Drawing.Point(0, 0);
            this.pb_button.Name = "pb_button";
            this.pb_button.Size = new System.Drawing.Size(182, 150);
            this.pb_button.TabIndex = 0;
            this.pb_button.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.button5);
            this.panel11.Controls.Add(this.pb_redLED);
            this.panel11.Location = new System.Drawing.Point(211, 243);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(184, 216);
            this.panel11.TabIndex = 4;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightCyan;
            this.button5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(0, 150);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(182, 64);
            this.button5.TabIndex = 3;
            this.button5.Text = "Red LED";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // pb_redLED
            // 
            this.pb_redLED.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_redLED.BackgroundImage")));
            this.pb_redLED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_redLED.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_redLED.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_redLED.Location = new System.Drawing.Point(0, 0);
            this.pb_redLED.Name = "pb_redLED";
            this.pb_redLED.Size = new System.Drawing.Size(182, 150);
            this.pb_redLED.TabIndex = 0;
            this.pb_redLED.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.button9);
            this.panel13.Controls.Add(this.pb_greenLED);
            this.panel13.Location = new System.Drawing.Point(401, 243);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(184, 216);
            this.panel13.TabIndex = 4;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.LightCyan;
            this.button9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(0, 150);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(182, 64);
            this.button9.TabIndex = 3;
            this.button9.Text = "Green LED";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // pb_greenLED
            // 
            this.pb_greenLED.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_greenLED.BackgroundImage")));
            this.pb_greenLED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_greenLED.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_greenLED.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_greenLED.Location = new System.Drawing.Point(0, 0);
            this.pb_greenLED.Name = "pb_greenLED";
            this.pb_greenLED.Size = new System.Drawing.Size(182, 150);
            this.pb_greenLED.TabIndex = 0;
            this.pb_greenLED.TabStop = false;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.LightCyan;
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.Location = new System.Drawing.Point(0, 460);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(813, 65);
            this.panel14.TabIndex = 6;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightCyan;
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(813, 50);
            this.button6.TabIndex = 4;
            this.button6.Text = "Sensors";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(813, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(373, 525);
            this.panel2.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(373, 475);
            this.panel4.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.flowLayoutPanel8);
            this.panel7.Controls.Add(this.flowLayoutPanel7);
            this.panel7.Controls.Add(this.flowLayoutPanel6);
            this.panel7.Controls.Add(this.flowLayoutPanel5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(373, 410);
            this.panel7.TabIndex = 2;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.lb_DataComms);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(20, 25);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(333, 375);
            this.panel8.TabIndex = 6;
            // 
            // lb_DataComms
            // 
            this.lb_DataComms.BackColor = System.Drawing.Color.White;
            this.lb_DataComms.Cursor = System.Windows.Forms.Cursors.Default;
            this.lb_DataComms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lb_DataComms.FormattingEnabled = true;
            this.lb_DataComms.ItemHeight = 21;
            this.lb_DataComms.Location = new System.Drawing.Point(0, 0);
            this.lb_DataComms.Name = "lb_DataComms";
            this.lb_DataComms.Size = new System.Drawing.Size(333, 375);
            this.lb_DataComms.TabIndex = 0;
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.flowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel8.Location = new System.Drawing.Point(20, 0);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Size = new System.Drawing.Size(333, 25);
            this.flowLayoutPanel8.TabIndex = 5;
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.Cursor = System.Windows.Forms.Cursors.Default;
            this.flowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel7.Location = new System.Drawing.Point(20, 400);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Size = new System.Drawing.Size(333, 10);
            this.flowLayoutPanel7.TabIndex = 4;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Cursor = System.Windows.Forms.Cursors.Default;
            this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(353, 0);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(20, 410);
            this.flowLayoutPanel6.TabIndex = 3;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Cursor = System.Windows.Forms.Cursors.Default;
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(20, 410);
            this.flowLayoutPanel5.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btn_clearComms);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 410);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(373, 65);
            this.panel6.TabIndex = 1;
            // 
            // btn_clearComms
            // 
            this.btn_clearComms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_clearComms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_clearComms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clearComms.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btn_clearComms.Location = new System.Drawing.Point(0, 0);
            this.btn_clearComms.Name = "btn_clearComms";
            this.btn_clearComms.Size = new System.Drawing.Size(373, 65);
            this.btn_clearComms.TabIndex = 3;
            this.btn_clearComms.Text = "Clear Logs";
            this.btn_clearComms.UseVisualStyleBackColor = false;
            this.btn_clearComms.Click += new System.EventHandler(this.btn_clearComms_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(373, 50);
            this.button1.TabIndex = 2;
            this.button1.Text = "Logs";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // lb_tapCount
            // 
            this.lb_tapCount.AutoSize = true;
            this.lb_tapCount.BackColor = System.Drawing.Color.LightCyan;
            this.lb_tapCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lb_tapCount.Location = new System.Drawing.Point(31, 185);
            this.lb_tapCount.Name = "lb_tapCount";
            this.lb_tapCount.Size = new System.Drawing.Size(118, 24);
            this.lb_tapCount.TabIndex = 4;
            this.lb_tapCount.Text = "Tap Count: 0";
            // 
            // DiscussionRoomBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "DiscussionRoomBooking";
            this.Size = new System.Drawing.Size(1186, 525);
            this.Load += new System.EventHandler(this.DiscussionRoomBooking_Load);
            this.panel1.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.flowLayoutPanel9.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_keyCard)).EndInit();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_lights)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_motion)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_buzzer)).EndInit();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_button)).EndInit();
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_redLED)).EndInit();
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_greenLED)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListBox lb_DataComms;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btn_clearComms;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pb_keyCard;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pb_lights;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pb_motion;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pb_buzzer;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pb_button;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pb_redLED;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pb_greenLED;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label lb_tapCount;
    }
}
