﻿namespace SpotfireDemo
{
    partial class SpotfireDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpotfireDemo));
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_aws = new System.Windows.Forms.Button();
            this.btn_bigQuery = new System.Windows.Forms.Button();
            this.btn_discussionRoomBooking = new System.Windows.Forms.Button();
            this.btn_fruitStore = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_title = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.view_Item = new System.Windows.Forms.ToolStripMenuItem();
            this.fullScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defaultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.language_Item = new System.Windows.Forms.ToolStripMenuItem();
            this.EnglishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChineseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RussianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AppClose = new System.Windows.Forms.Button();
            this.panel_mainContent = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btn_IoT_AWS = new System.Windows.Forms.Button();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.panel5.Controls.Add(this.btn_IoT_AWS);
            this.panel5.Controls.Add(this.btn_aws);
            this.panel5.Controls.Add(this.btn_bigQuery);
            this.panel5.Controls.Add(this.btn_discussionRoomBooking);
            this.panel5.Controls.Add(this.btn_fruitStore);
            this.panel5.Controls.Add(this.btn_home);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(231, 781);
            this.panel5.TabIndex = 1;
            // 
            // btn_aws
            // 
            this.btn_aws.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_aws.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_aws.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_aws.FlatAppearance.BorderSize = 0;
            this.btn_aws.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_aws.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_aws.ForeColor = System.Drawing.Color.White;
            this.btn_aws.Location = new System.Drawing.Point(0, 557);
            this.btn_aws.Name = "btn_aws";
            this.btn_aws.Size = new System.Drawing.Size(231, 112);
            this.btn_aws.TabIndex = 8;
            this.btn_aws.Text = "Juice Sales (AWS RDS)";
            this.btn_aws.UseVisualStyleBackColor = true;
            this.btn_aws.Click += new System.EventHandler(this.btn_aws_Click);
            // 
            // btn_bigQuery
            // 
            this.btn_bigQuery.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_bigQuery.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_bigQuery.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_bigQuery.FlatAppearance.BorderSize = 0;
            this.btn_bigQuery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bigQuery.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bigQuery.ForeColor = System.Drawing.Color.White;
            this.btn_bigQuery.Location = new System.Drawing.Point(0, 445);
            this.btn_bigQuery.Name = "btn_bigQuery";
            this.btn_bigQuery.Size = new System.Drawing.Size(231, 112);
            this.btn_bigQuery.TabIndex = 7;
            this.btn_bigQuery.Text = "Soda Sales (BigQuery)";
            this.btn_bigQuery.UseVisualStyleBackColor = true;
            this.btn_bigQuery.Click += new System.EventHandler(this.btn_bigQuery_Click);
            // 
            // btn_discussionRoomBooking
            // 
            this.btn_discussionRoomBooking.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_discussionRoomBooking.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_discussionRoomBooking.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_discussionRoomBooking.FlatAppearance.BorderSize = 0;
            this.btn_discussionRoomBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_discussionRoomBooking.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_discussionRoomBooking.ForeColor = System.Drawing.Color.White;
            this.btn_discussionRoomBooking.Location = new System.Drawing.Point(0, 333);
            this.btn_discussionRoomBooking.Name = "btn_discussionRoomBooking";
            this.btn_discussionRoomBooking.Size = new System.Drawing.Size(231, 112);
            this.btn_discussionRoomBooking.TabIndex = 6;
            this.btn_discussionRoomBooking.Text = "Discussion Room Booking";
            this.btn_discussionRoomBooking.UseVisualStyleBackColor = true;
            this.btn_discussionRoomBooking.Click += new System.EventHandler(this.btn_discussionRoomBooking_Click);
            // 
            // btn_fruitStore
            // 
            this.btn_fruitStore.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_fruitStore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fruitStore.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_fruitStore.FlatAppearance.BorderSize = 0;
            this.btn_fruitStore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fruitStore.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fruitStore.ForeColor = System.Drawing.Color.White;
            this.btn_fruitStore.Location = new System.Drawing.Point(0, 221);
            this.btn_fruitStore.Name = "btn_fruitStore";
            this.btn_fruitStore.Size = new System.Drawing.Size(231, 112);
            this.btn_fruitStore.TabIndex = 5;
            this.btn_fruitStore.Text = "Fruit Store";
            this.btn_fruitStore.UseVisualStyleBackColor = true;
            this.btn_fruitStore.Click += new System.EventHandler(this.btn_fruitStore_Click);
            // 
            // btn_home
            // 
            this.btn_home.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_home.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_home.FlatAppearance.BorderSize = 0;
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.White;
            this.btn_home.Location = new System.Drawing.Point(0, 109);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(231, 112);
            this.btn_home.TabIndex = 2;
            this.btn_home.Text = "Home";
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.lbl_title);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(231, 109);
            this.panel1.TabIndex = 0;
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title.ForeColor = System.Drawing.Color.White;
            this.lbl_title.Location = new System.Drawing.Point(6, 35);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(224, 39);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.Text = "SpotfireDemo";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.AppClose);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel3.Location = new System.Drawing.Point(231, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1182, 34);
            this.panel3.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.menuStrip1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 34);
            this.panel4.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.menuStrip1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.view_Item,
            this.language_Item});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(200, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // view_Item
            // 
            this.view_Item.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fullScreenToolStripMenuItem,
            this.resizeToolStripMenuItem,
            this.defaultToolStripMenuItem});
            this.view_Item.Name = "view_Item";
            this.view_Item.Size = new System.Drawing.Size(60, 25);
            this.view_Item.Text = "View";
            // 
            // fullScreenToolStripMenuItem
            // 
            this.fullScreenToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fullScreenToolStripMenuItem.Image")));
            this.fullScreenToolStripMenuItem.Name = "fullScreenToolStripMenuItem";
            this.fullScreenToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.fullScreenToolStripMenuItem.Text = "FullScreen";
            this.fullScreenToolStripMenuItem.Click += new System.EventHandler(this.fullScreenToolStripMenuItem_Click);
            // 
            // resizeToolStripMenuItem
            // 
            this.resizeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("resizeToolStripMenuItem.Image")));
            this.resizeToolStripMenuItem.Name = "resizeToolStripMenuItem";
            this.resizeToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.resizeToolStripMenuItem.Text = "Resize";
            this.resizeToolStripMenuItem.Click += new System.EventHandler(this.resizeToolStripMenuItem_Click);
            // 
            // defaultToolStripMenuItem
            // 
            this.defaultToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("defaultToolStripMenuItem.Image")));
            this.defaultToolStripMenuItem.Name = "defaultToolStripMenuItem";
            this.defaultToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.defaultToolStripMenuItem.Text = "Default";
            this.defaultToolStripMenuItem.Click += new System.EventHandler(this.defaultToolStripMenuItem_Click);
            // 
            // language_Item
            // 
            this.language_Item.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.language_Item.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EnglishToolStripMenuItem,
            this.ChineseToolStripMenuItem,
            this.RussianToolStripMenuItem});
            this.language_Item.Name = "language_Item";
            this.language_Item.Size = new System.Drawing.Size(12, 25);
            this.language_Item.Text = "Language";
            // 
            // EnglishToolStripMenuItem
            // 
            this.EnglishToolStripMenuItem.Checked = true;
            this.EnglishToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.EnglishToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("EnglishToolStripMenuItem.Image")));
            this.EnglishToolStripMenuItem.Name = "EnglishToolStripMenuItem";
            this.EnglishToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.EnglishToolStripMenuItem.Text = "English";
            this.EnglishToolStripMenuItem.Click += new System.EventHandler(this.EnglishToolStripMenuItem_Click);
            // 
            // ChineseToolStripMenuItem
            // 
            this.ChineseToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ChineseToolStripMenuItem.Image")));
            this.ChineseToolStripMenuItem.Name = "ChineseToolStripMenuItem";
            this.ChineseToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.ChineseToolStripMenuItem.Text = "Chinese";
            this.ChineseToolStripMenuItem.Click += new System.EventHandler(this.ChineseToolStripMenuItem_Click);
            // 
            // RussianToolStripMenuItem
            // 
            this.RussianToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("RussianToolStripMenuItem.Image")));
            this.RussianToolStripMenuItem.Name = "RussianToolStripMenuItem";
            this.RussianToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.RussianToolStripMenuItem.Text = "Russian";
            this.RussianToolStripMenuItem.Click += new System.EventHandler(this.RussianToolStripMenuItem_Click);
            // 
            // AppClose
            // 
            this.AppClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AppClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.AppClose.FlatAppearance.BorderSize = 0;
            this.AppClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AppClose.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppClose.ForeColor = System.Drawing.Color.Black;
            this.AppClose.Location = new System.Drawing.Point(1134, 0);
            this.AppClose.Name = "AppClose";
            this.AppClose.Size = new System.Drawing.Size(48, 34);
            this.AppClose.TabIndex = 0;
            this.AppClose.Text = "X";
            this.AppClose.UseVisualStyleBackColor = true;
            this.AppClose.Click += new System.EventHandler(this.AppClose_Click);
            // 
            // panel_mainContent
            // 
            this.panel_mainContent.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel_mainContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_mainContent.Location = new System.Drawing.Point(231, 34);
            this.panel_mainContent.Name = "panel_mainContent";
            this.panel_mainContent.Size = new System.Drawing.Size(1182, 747);
            this.panel_mainContent.TabIndex = 2;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // btn_IoT_AWS
            // 
            this.btn_IoT_AWS.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_IoT_AWS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.btn_IoT_AWS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_IoT_AWS.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_IoT_AWS.FlatAppearance.BorderSize = 0;
            this.btn_IoT_AWS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_IoT_AWS.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_IoT_AWS.ForeColor = System.Drawing.Color.White;
            this.btn_IoT_AWS.Location = new System.Drawing.Point(0, 669);
            this.btn_IoT_AWS.Name = "btn_IoT_AWS";
            this.btn_IoT_AWS.Size = new System.Drawing.Size(231, 112);
            this.btn_IoT_AWS.TabIndex = 9;
            this.btn_IoT_AWS.Text = "Room Booking (AWS RDS)";
            this.btn_IoT_AWS.UseVisualStyleBackColor = false;
            this.btn_IoT_AWS.Click += new System.EventHandler(this.btn_IoT_AWS_Click);
            // 
            // SpotfireDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1413, 781);
            this.Controls.Add(this.panel_mainContent);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SpotfireDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Spotfire Demo";
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button AppClose;
        private System.Windows.Forms.Panel panel_mainContent;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem language_Item;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem EnglishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ChineseToolStripMenuItem;
        private System.Windows.Forms.Button btn_fruitStore;
        private System.Windows.Forms.Button btn_discussionRoomBooking;
        private System.Windows.Forms.ToolStripMenuItem view_Item;
        private System.Windows.Forms.ToolStripMenuItem fullScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defaultToolStripMenuItem;
        private System.Windows.Forms.Button btn_bigQuery;
        private System.Windows.Forms.ToolStripMenuItem RussianToolStripMenuItem;
        private System.Windows.Forms.Button btn_aws;
        private System.Windows.Forms.Button btn_IoT_AWS;
    }
}

