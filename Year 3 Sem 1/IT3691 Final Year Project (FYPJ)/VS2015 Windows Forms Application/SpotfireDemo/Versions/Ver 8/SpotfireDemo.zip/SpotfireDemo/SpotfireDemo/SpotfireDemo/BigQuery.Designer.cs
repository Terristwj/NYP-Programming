﻿namespace SpotfireDemo
{
    partial class BigQuery
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Sales_Title = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_resetDemo = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.btn_computeSales = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.btn_pepsi_plus5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btn_7Up_plus5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.btn_rootBeer_plus5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_fanta_plus5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_sprite_plus5 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_cocaCola_plus5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.controls_Title = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_preset = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Controls.Add(this.Sales_Title);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(813, 525);
            this.panel2.TabIndex = 1;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 50);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(813, 475);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // Sales_Title
            // 
            this.Sales_Title.BackColor = System.Drawing.Color.LightCyan;
            this.Sales_Title.Dock = System.Windows.Forms.DockStyle.Top;
            this.Sales_Title.FlatAppearance.BorderSize = 0;
            this.Sales_Title.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sales_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sales_Title.Location = new System.Drawing.Point(0, 0);
            this.Sales_Title.Name = "Sales_Title";
            this.Sales_Title.Size = new System.Drawing.Size(813, 50);
            this.Sales_Title.TabIndex = 3;
            this.Sales_Title.Text = "Sales For The Day";
            this.Sales_Title.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.controls_Title);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(813, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(373, 525);
            this.panel1.TabIndex = 2;
            // 
            // panel9
            // 
            this.panel9.AutoScroll = true;
            this.panel9.Controls.Add(this.panel7);
            this.panel9.Controls.Add(this.panel5);
            this.panel9.Controls.Add(this.panel3);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 50);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(373, 475);
            this.panel9.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.AutoScroll = true;
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.btn_preset);
            this.panel7.Controls.Add(this.button1);
            this.panel7.Controls.Add(this.btn_resetDemo);
            this.panel7.Controls.Add(this.Button12);
            this.panel7.Controls.Add(this.btn_computeSales);
            this.panel7.Controls.Add(this.button11);
            this.panel7.Controls.Add(this.btn_pepsi_plus5);
            this.panel7.Controls.Add(this.button9);
            this.panel7.Controls.Add(this.btn_7Up_plus5);
            this.panel7.Controls.Add(this.button7);
            this.panel7.Controls.Add(this.btn_rootBeer_plus5);
            this.panel7.Controls.Add(this.button4);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.btn_fanta_plus5);
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.btn_sprite_plus5);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Controls.Add(this.btn_cocaCola_plus5);
            this.panel7.Controls.Add(this.button3);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(70, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(233, 475);
            this.panel7.TabIndex = 5;
            // 
            // btn_resetDemo
            // 
            this.btn_resetDemo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_resetDemo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_resetDemo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_resetDemo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_resetDemo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_resetDemo.Location = new System.Drawing.Point(0, 594);
            this.btn_resetDemo.Name = "btn_resetDemo";
            this.btn_resetDemo.Size = new System.Drawing.Size(216, 67);
            this.btn_resetDemo.TabIndex = 21;
            this.btn_resetDemo.Tag = "";
            this.btn_resetDemo.Text = "Reset Demo";
            this.btn_resetDemo.UseVisualStyleBackColor = false;
            this.btn_resetDemo.Click += new System.EventHandler(this.btn_resetDemo_Click);
            // 
            // Button12
            // 
            this.Button12.BackColor = System.Drawing.Color.White;
            this.Button12.Cursor = System.Windows.Forms.Cursors.Default;
            this.Button12.Dock = System.Windows.Forms.DockStyle.Top;
            this.Button12.Enabled = false;
            this.Button12.FlatAppearance.BorderSize = 0;
            this.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button12.Location = new System.Drawing.Point(0, 579);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(216, 15);
            this.Button12.TabIndex = 20;
            this.Button12.UseVisualStyleBackColor = false;
            // 
            // btn_computeSales
            // 
            this.btn_computeSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_computeSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_computeSales.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_computeSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_computeSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_computeSales.Location = new System.Drawing.Point(0, 512);
            this.btn_computeSales.Name = "btn_computeSales";
            this.btn_computeSales.Size = new System.Drawing.Size(216, 67);
            this.btn_computeSales.TabIndex = 19;
            this.btn_computeSales.Tag = "";
            this.btn_computeSales.Text = "Compute Sales";
            this.btn_computeSales.UseVisualStyleBackColor = false;
            this.btn_computeSales.Click += new System.EventHandler(this.btn_computeSales_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Cursor = System.Windows.Forms.Cursors.Default;
            this.button11.Dock = System.Windows.Forms.DockStyle.Top;
            this.button11.Enabled = false;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(0, 497);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(216, 15);
            this.button11.TabIndex = 18;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // btn_pepsi_plus5
            // 
            this.btn_pepsi_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_pepsi_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pepsi_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_pepsi_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pepsi_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pepsi_plus5.Location = new System.Drawing.Point(0, 430);
            this.btn_pepsi_plus5.Name = "btn_pepsi_plus5";
            this.btn_pepsi_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_pepsi_plus5.TabIndex = 17;
            this.btn_pepsi_plus5.Tag = "";
            this.btn_pepsi_plus5.Text = "Add 5 Pepsi";
            this.btn_pepsi_plus5.UseVisualStyleBackColor = false;
            this.btn_pepsi_plus5.Click += new System.EventHandler(this.btn_pepsi_plus5_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Cursor = System.Windows.Forms.Cursors.Default;
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.Enabled = false;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(0, 415);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(216, 15);
            this.button9.TabIndex = 16;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // btn_7Up_plus5
            // 
            this.btn_7Up_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_7Up_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_7Up_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_7Up_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_7Up_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_7Up_plus5.Location = new System.Drawing.Point(0, 348);
            this.btn_7Up_plus5.Name = "btn_7Up_plus5";
            this.btn_7Up_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_7Up_plus5.TabIndex = 15;
            this.btn_7Up_plus5.Tag = "";
            this.btn_7Up_plus5.Text = "Add 5 7-Up";
            this.btn_7Up_plus5.UseVisualStyleBackColor = false;
            this.btn_7Up_plus5.Click += new System.EventHandler(this.btn_7Up_plus5_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Cursor = System.Windows.Forms.Cursors.Default;
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.Enabled = false;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(0, 333);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(216, 15);
            this.button7.TabIndex = 14;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // btn_rootBeer_plus5
            // 
            this.btn_rootBeer_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_rootBeer_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_rootBeer_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_rootBeer_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rootBeer_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rootBeer_plus5.Location = new System.Drawing.Point(0, 266);
            this.btn_rootBeer_plus5.Name = "btn_rootBeer_plus5";
            this.btn_rootBeer_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_rootBeer_plus5.TabIndex = 13;
            this.btn_rootBeer_plus5.Tag = "";
            this.btn_rootBeer_plus5.Text = "Add 5 Root Beer";
            this.btn_rootBeer_plus5.UseVisualStyleBackColor = false;
            this.btn_rootBeer_plus5.Click += new System.EventHandler(this.btn_rootBeer_plus5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Cursor = System.Windows.Forms.Cursors.Default;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.Enabled = false;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(0, 251);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(216, 15);
            this.button4.TabIndex = 12;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 743);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(216, 20);
            this.panel8.TabIndex = 5;
            // 
            // btn_fanta_plus5
            // 
            this.btn_fanta_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_fanta_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fanta_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_fanta_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fanta_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fanta_plus5.Location = new System.Drawing.Point(0, 184);
            this.btn_fanta_plus5.Name = "btn_fanta_plus5";
            this.btn_fanta_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_fanta_plus5.TabIndex = 6;
            this.btn_fanta_plus5.Tag = "";
            this.btn_fanta_plus5.Text = "Add 5 Fanta";
            this.btn_fanta_plus5.UseVisualStyleBackColor = false;
            this.btn_fanta_plus5.Click += new System.EventHandler(this.btn_fanta_plus5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Cursor = System.Windows.Forms.Cursors.Default;
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.Enabled = false;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(0, 169);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(216, 15);
            this.button2.TabIndex = 11;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btn_sprite_plus5
            // 
            this.btn_sprite_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_sprite_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sprite_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_sprite_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sprite_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sprite_plus5.Location = new System.Drawing.Point(0, 102);
            this.btn_sprite_plus5.Name = "btn_sprite_plus5";
            this.btn_sprite_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_sprite_plus5.TabIndex = 10;
            this.btn_sprite_plus5.Tag = "";
            this.btn_sprite_plus5.Text = "Add 5 Sprite";
            this.btn_sprite_plus5.UseVisualStyleBackColor = false;
            this.btn_sprite_plus5.Click += new System.EventHandler(this.btn_sprite_plus5_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Cursor = System.Windows.Forms.Cursors.Default;
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.Enabled = false;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(0, 87);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(216, 15);
            this.button5.TabIndex = 9;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // btn_cocaCola_plus5
            // 
            this.btn_cocaCola_plus5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_cocaCola_plus5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cocaCola_plus5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_cocaCola_plus5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cocaCola_plus5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cocaCola_plus5.Location = new System.Drawing.Point(0, 20);
            this.btn_cocaCola_plus5.Name = "btn_cocaCola_plus5";
            this.btn_cocaCola_plus5.Size = new System.Drawing.Size(216, 67);
            this.btn_cocaCola_plus5.TabIndex = 8;
            this.btn_cocaCola_plus5.Tag = "";
            this.btn_cocaCola_plus5.Text = "Add 5 Coca Cola";
            this.btn_cocaCola_plus5.UseVisualStyleBackColor = false;
            this.btn_cocaCola_plus5.Click += new System.EventHandler(this.btn_cocaCola_plus5_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Cursor = System.Windows.Forms.Cursors.Default;
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.Enabled = false;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(216, 20);
            this.button3.TabIndex = 7;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(303, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(70, 475);
            this.panel5.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(70, 475);
            this.panel3.TabIndex = 2;
            // 
            // controls_Title
            // 
            this.controls_Title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.controls_Title.Dock = System.Windows.Forms.DockStyle.Top;
            this.controls_Title.FlatAppearance.BorderSize = 0;
            this.controls_Title.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.controls_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controls_Title.Location = new System.Drawing.Point(0, 0);
            this.controls_Title.Name = "controls_Title";
            this.controls_Title.Size = new System.Drawing.Size(373, 50);
            this.controls_Title.TabIndex = 1;
            this.controls_Title.Text = "Controls";
            this.controls_Title.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.Enabled = false;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 661);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(216, 15);
            this.button1.TabIndex = 22;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btn_preset
            // 
            this.btn_preset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_preset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_preset.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_preset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_preset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_preset.Location = new System.Drawing.Point(0, 676);
            this.btn_preset.Name = "btn_preset";
            this.btn_preset.Size = new System.Drawing.Size(216, 67);
            this.btn_preset.TabIndex = 23;
            this.btn_preset.Tag = "";
            this.btn_preset.Text = "Load Preset";
            this.btn_preset.UseVisualStyleBackColor = false;
            this.btn_preset.Click += new System.EventHandler(this.btn_preset_Click);
            // 
            // BigQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "BigQuery";
            this.Size = new System.Drawing.Size(1186, 525);
            this.Load += new System.EventHandler(this.BigQuery_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button controls_Title;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_fanta_plus5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_computeSales;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button btn_pepsi_plus5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btn_7Up_plus5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btn_rootBeer_plus5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_sprite_plus5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btn_cocaCola_plus5;
        private System.Windows.Forms.Button btn_resetDemo;
        private System.Windows.Forms.Button Button12;
        private System.Windows.Forms.Button Sales_Title;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btn_preset;
        private System.Windows.Forms.Button button1;
    }
}
