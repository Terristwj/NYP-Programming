This is the sample typescript setup with usage of api-ai-javascript library inside.

Installation:

`$ npm install`

Running (webpack-dev-server on localhost:8080 by default):

`$ npm start`
