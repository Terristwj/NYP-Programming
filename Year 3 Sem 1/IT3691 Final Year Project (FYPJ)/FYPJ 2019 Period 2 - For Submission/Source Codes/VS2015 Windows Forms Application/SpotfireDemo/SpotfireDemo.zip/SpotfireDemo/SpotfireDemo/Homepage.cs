﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Hyperlink
using System.Diagnostics;

namespace SpotfireDemo
{
    public partial class Homepage : UserControl
    {
        public Homepage()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://spotfire-next.cloud.tibco.com/spotfire/wp/OpenAnalysis?file=/Users/i37ury2vv3keo2u2ft2dd36xjbylsjba/Public/Spotfire%20Database%20Demo%20-%20FruitStore%20%28FYPJ-P2-Terris%29&configurationBlock=SetPage%28pageIndex%3D0%29%3B&options=7-1,8-1,9-1,10-1,11-1,12-1,13-1,14-1,1-1,2-1,3-1,4-1,5-0,6-0,15-1,17-1");
        }
    }
}
