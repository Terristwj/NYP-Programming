﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//BigQuery
using Google.Cloud.BigQuery.V2;
// Convert String To Float
using System.Globalization;

namespace SpotfireDemo
{
    public partial class BigQuery : UserControl
    {
        // BigQuery Connections
        // String values MUST be the same as the names in Google BigQuery
        static BigQueryClient BigQuery_client = BigQueryClient.Create("nyp-fypj");                              // Create a client connecting to project
        static BigQueryTable BigQuery_table = BigQuery_client.GetTable("nyp-fypj", "FYPJ", "Soda_Sales");       // Connect to project > dataSet > dataTable
        BigQueryResults BigQuery_data = null;                                                                   // Stores the data after retrieval

        // For btn_computeSales
        float totalSales = -1;      // Store the amound of sales genererated
        int sodaSold = -1;       // Store the number of soda sold

        // Langauges Supported
        string[] language_supported = { "EN", "CH" };
        // Declared borrowed variables
        string language = null;

        public BigQuery()
        {
            InitializeComponent();
        }

        private void BigQuery_Load(object sender, EventArgs e)
        {
            // Set borrowed variables
            language = SpotfireDemo.language;

            // Check if current language is supported
            checkCurrentLanguage();

            // Connect to Google BigQuery project
            Bigquery_retrieveData();

            // Display fruits
            populate_flowLayoutPanel();
            populate_buttonControls();
        }


        //
        //  Language Controls
        //
        //------------------------Start---------------------------//
        private void checkCurrentLanguage()                                 // Checks if the current language is supported
        {
            if (!(Array.IndexOf(language_supported, language) > -1))        // If not supported, reset to "EN"
                language = "EN";                                            // NOTE: After loading, immediately go to SpotfireDemo
        }                                                                   //       to reload the entire "EN" version

        private void populate_buttonControls()
        {
            if (language.Equals("EN"))
            {
                Sales_Title.Text = "Sales For The Day";
                controls_Title.Text = "Controls";

                btn_cocaCola_plus5.Text = "Add 5 Coca Cola";
                btn_sprite_plus5.Text = "Add 5 Sprite";
                btn_fanta_plus5.Text = "Add 5 Fanta";
                btn_rootBeer_plus5.Text = "Add 5 Root Beer";
                btn_7Up_plus5.Text = "Add 5 7-Up";
                btn_pepsi_plus5.Text = "Add 5 Pepsi";
                btn_computeSales.Text = "Compute Sales";
                btn_resetDemo.Text = "Reset Demo";
            }
            else if (language.Equals("CH"))
            {
                Sales_Title.Text = "今天销售";
                controls_Title.Text = "管制";

                btn_cocaCola_plus5.Text = "加 5 可口可乐";
                btn_sprite_plus5.Text = "加 5 雪碧";
                btn_fanta_plus5.Text = "加 5 芬达";
                btn_rootBeer_plus5.Text = "加 5 根汁汽水";
                btn_7Up_plus5.Text = "加 5 七喜";
                btn_pepsi_plus5.Text = "加 5 百事可乐";
                btn_computeSales.Text = "计算销售";
                btn_resetDemo.Text = "重启演示";
            }
        }


        //
        //  Database Manipulation
        //
        //------------------------Start---------------------------//
        private void Bigquery_retrieveData()
        {
            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            string query = "";
            if (language.Equals("EN"))
                query = $"SELECT drink, sale_count, imageUrl FROM {table} ORDER BY sale_cost DESC, drink";
            else if (language.Equals("CH"))
                query = $"SELECT drink_Chinese, sale_count, imageUrl FROM {table} ORDER BY sale_cost DESC, drink";

            BigQuery_data = client.ExecuteQuery(query, null);           // Retrieve the required data from BigQuery
        }

        private string Bigquery_retrieveSodaSale(string soda)           // NOT USING
        {
            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            string query = $"SELECT sale_count FROM {table} WHERE drink = @drink";

            BigQueryParameter[] parameters = new[]                         // Sets parameter for query. Eg. @drink = soda, w/ settings
            {
                new BigQueryParameter("drink", BigQueryDbType.String, soda)
            };

            BigQueryResults results = client.ExecuteQuery(query, parameters);
            BigQueryRow row = results.First();                     // Query should only return 1 value. Hence, use First().

            return $"{row["sale_Count"]}";
        }

        private void Bigquery_updateSodaSale(string soda, int increment)
        {
            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            string query = $"UPDATE {table} SET sale_count = sale_count + " + increment + " WHERE drink = @drink";

            BigQueryParameter[] parameters = new[]                         // Sets parameter for query. Eg. @drink = soda, w/ settings
            {
                new BigQueryParameter("drink", BigQueryDbType.String, soda)
            };

            client.ExecuteQuery(query, parameters);                        // Update the data inside BigQuery

            Bigquery_retrieveData();                                       // Retrieve newly updated set of data
            populate_flowLayoutPanel();                                    // Reset the dispays after updating and retrieval
        }

        private void Bigquery_updateSpecificSodaSale(string soda, int value)
        {
            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            string query = $"UPDATE {table} SET sale_count = @sale_count WHERE drink = @drink";

            BigQueryParameter[] parameters = new[]                         // Sets parameter for query. Eg. @drink = soda, w/ settings
            {
                new BigQueryParameter("sale_count", BigQueryDbType.Int64, value),
                new BigQueryParameter("drink", BigQueryDbType.String, soda)
            };

            client.ExecuteQuery(query, parameters);                        // Update the data inside BigQuery
        }

        private float Bigquery_computeSodaSale()
        {
            float totalSales = 0;

            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            string query = $"SELECT sale_cost, sale_count FROM {table} WHERE sale_count != @sale_count";

            BigQueryParameter[] parameters = new[]                         // Sets parameter for query. Eg. @sale_count = sale_count, w/ settings
            {
                new BigQueryParameter("sale_count", BigQueryDbType.Int64, 0)
            };

            BigQueryResults results = client.ExecuteQuery(query, parameters);                        // Update the data inside BigQuery (RESET)

            foreach (BigQueryRow row in results)
            {
                float saleCost = float.Parse($"{row["sale_cost"]}", CultureInfo.InvariantCulture.NumberFormat);
                int saleCount = Convert.ToInt32($"{row["sale_count"]}");
                totalSales += (saleCost * saleCount);                          // Get the totalSale per row and sum them together
            }

            return totalSales;
        }

        private int Bigquery_computeSodaSold()
        {
            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            // Return 0 if value is null. Filter out sale_count=0 to save time processing.
            string query = $"SELECT IFNULL(SUM(sale_count), 0) AS sodaSold FROM {table} WHERE sale_count != @sale_count";

            BigQueryParameter[] parameters = new[]                         // Sets parameter for query. Eg. @sale_count = sale_count, w/ settings
            {
                new BigQueryParameter("sale_count", BigQueryDbType.Int64, 0)
            };

            BigQueryResults result = client.ExecuteQuery(query, parameters);
            BigQueryRow row = result.First();                     // Query should only return 1 value. Hence, use First().
            
            return Convert.ToInt32($"{row["sodaSold"]}");
        }

        private void Bigquery_resetSodaSale()
        {
            BigQueryClient client = BigQuery_client;
            BigQueryTable table = BigQuery_table;

            string query = $"UPDATE {table} SET sale_count = 0 WHERE sale_count != @sale_count";

            BigQueryParameter[] parameters = new[]                         // Sets parameter for query. Eg. @sale_count = sale_count, w/ settings
            {
                new BigQueryParameter("sale_count", BigQueryDbType.Int64, 0)
            };

            client.ExecuteQuery(query, parameters);                        // Update the data inside BigQuery (RESET)

            Bigquery_retrieveData();                                       // Retrieve newly updated set of data
            populate_flowLayoutPanel();                                    // Reset the dispays after updating and retrieval
        }
        //--------------------------End---------------------------//




        //
        //  Display Conrols
        //
        //------------------------Start---------------------------//
        private void populate_flowLayoutPanel()
        {
            try
            {
                flowLayoutPanel1.Controls.Clear();

                foreach (BigQueryRow row in BigQuery_data)                    // Foreach soda, create an item frame
                {
                    // Picture
                    PictureBox sodaPic = new PictureBox();
                    sodaPic.BackgroundImageLayout = ImageLayout.Zoom;
                    sodaPic.BorderStyle = BorderStyle.FixedSingle;
                    sodaPic.Dock = DockStyle.Top;
                    sodaPic.Size = new Size(183, 150);

                    // Sales
                    Button sodaSale = new Button();
                    sodaSale.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
                    sodaSale.Font = new Font("Microsoft Sans Serif", 16);
                    sodaSale.FlatStyle = FlatStyle.Flat;

                    if (language.Equals("EN"))                              // Language
                        sodaSale.Text = "Sold: ";
                    else if (language.Equals("CH"))
                        sodaSale.Text = "卖了: ";

                    sodaSale.Dock = DockStyle.Bottom;
                    sodaSale.Size = new Size(183, 64);

                    /*
                     *  Syntax for BigQuery retrieve data
                     * 
                     *  To collect a single data: $"{row["product_Name"]}"
                     *  To collect multiple data: $"{row["product_Name"]}: {row["price"]}: {row["stock"]}"
                     *  
                     *  Eg. string sodaName = $"{row["product_Name"]}";
                     *      string sodaName_AndCost = $"{row["product_Name"]}: {row["price"]}";
                     *      
                     *      Output:
                     *      product_Name
                     *      product_Name: price
                     * 
                     */

                    // Add in image
                    sodaPic.BackgroundImage = Image.FromFile("../.././Images/BigQuery/" + $"{row["imageUrl"]}");

                    // Add in data
                    sodaSale.Text += $"{row["sale_count"]}";

                    // Item frame
                    Panel sodaItem = new Panel();
                    sodaItem.BorderStyle = BorderStyle.FixedSingle;
                    sodaItem.Size = new Size(185, 216);

                    // Add everything into item frame, then into the layout
                    sodaItem.Controls.Add(sodaPic);
                    sodaItem.Controls.Add(sodaSale);
                    flowLayoutPanel1.Controls.Add(sodaItem);
                }
            }
            catch (Exception ex)                                        // Debugging purposes
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void display_computeSale(float totalSales, int sodaSold)
        {
            ////////////////////////////////////
            //
            //     1. Display for total sales
            //
            ////////////////////////////////////

            // Picture (Total Sales)
            PictureBox salePic = new PictureBox();
            salePic.BackgroundImageLayout = ImageLayout.Zoom;
            salePic.BorderStyle = BorderStyle.FixedSingle;
            salePic.Dock = DockStyle.Top;
            salePic.Size = new Size(183, 150);

            // Sum of sale
            Button saleSum = new Button();
            saleSum.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
            saleSum.Font = new Font("Microsoft Sans Serif", 16);
            saleSum.FlatStyle = FlatStyle.Flat;

            if (language.Equals("EN"))                              // Language
                saleSum.Text = "Total Sales: ";
            else if (language.Equals("CH"))
                saleSum.Text = "总销售: ";

            saleSum.Dock = DockStyle.Bottom;
            saleSum.Size = new Size(183, 64);
            
            // Add in image
            salePic.BackgroundImage = Image.FromFile("../.././Images/BigQuery/totalSales.png");

            // Add in data
            saleSum.Text += "$" + String.Format("{0:0.00}", totalSales);

            // Item frame
            Panel saleSum_item = new Panel();
            saleSum_item.BorderStyle = BorderStyle.FixedSingle;
            saleSum_item.Size = new Size(185, 216);


            ////////////////////////////////////////
            //
            //     2. Display for number soda sold
            //
            ////////////////////////////////////////

            // Picture (Soda Sold)
            PictureBox sodaPic = new PictureBox();
            sodaPic.BackgroundImageLayout = ImageLayout.Zoom;
            sodaPic.BorderStyle = BorderStyle.FixedSingle;
            sodaPic.Dock = DockStyle.Top;
            sodaPic.Size = new Size(183, 150);

            // Soda sold counter
            Button soldCounter = new Button();
            soldCounter.BackColor = Color.FromArgb(224, 255, 255);   // Lightcyan
            soldCounter.Font = new Font("Microsoft Sans Serif", 16);
            soldCounter.FlatStyle = FlatStyle.Flat;

            if (language.Equals("EN"))                              // Language
                soldCounter.Text = "Total Sold: ";
            else if (language.Equals("CH"))
                soldCounter.Text = "总汽水卖了: ";

            soldCounter.Dock = DockStyle.Bottom;
            soldCounter.Size = new Size(183, 64);

            // Add in image
            sodaPic.BackgroundImage = Image.FromFile("../.././Images/BigQuery/sodaSold.png");

            // Add in data
            soldCounter.Text += sodaSold.ToString();

            // Item frame
            Panel sodaSold_item = new Panel();
            sodaSold_item.BorderStyle = BorderStyle.FixedSingle;
            sodaSold_item.Size = new Size(185, 216);


            ////////////////////////////////////////
            //
            //     3. Add the displays
            //
            ////////////////////////////////////////

            // Check if the displays are currently loaded

            // Reload the data to remove any previously added displays
            populate_flowLayoutPanel();

            // Add everything into item frame, then into the layout
            saleSum_item.Controls.Add(salePic);
            saleSum_item.Controls.Add(saleSum);
            flowLayoutPanel1.Controls.Add(saleSum_item);
            
            // Add everything into item frame, then into the layout
            sodaSold_item.Controls.Add(sodaPic);
            sodaSold_item.Controls.Add(soldCounter);
            flowLayoutPanel1.Controls.Add(sodaSold_item);
        }
        //--------------------------End---------------------------//




        //
        //  Buttons
        //
        //------------------------Start---------------------------//
        private void saleIncrease(string soda, int increment)                 // Main method for all buttons
        {
            try
            {
                //  Update new stock of same item, 
                //  then retrieve newly updata dataSet,
                //  then update the displays.
                 
                Bigquery_updateSodaSale(soda, increment);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void load_Preset()                 // Main method for all buttons
        {
            try
            {
                // Change all the listed items values to a preset
                Bigquery_updateSpecificSodaSale("Root Beer", 10);
                Bigquery_updateSpecificSodaSale("Fanta", 15);
                Bigquery_updateSpecificSodaSale("Coca Cola", 20);
                Bigquery_updateSpecificSodaSale("Sprite", 15);
                Bigquery_updateSpecificSodaSale("7Up", 5);
                Bigquery_updateSpecificSodaSale("Pepsi", 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Bigquery_retrieveData();                                       // Retrieve newly updated set of data
                populate_flowLayoutPanel();
            }                                   // Reset the dispays after updating and retrieval
        }

        // List of buttons
        // Method Signature: stockIncrease(Fruit, StockIncrement);
        private void btn_rootBeer_plus5_Click(object sender, EventArgs e)
        {
            saleIncrease("Root Beer", 5);
        }

        private void btn_fanta_plus5_Click(object sender, EventArgs e)
        {
            saleIncrease("Fanta", 5);
        }

        private void btn_cocaCola_plus5_Click(object sender, EventArgs e)
        {
            saleIncrease("Coca Cola", 5);
        }

        private void btn_sprite_plus5_Click(object sender, EventArgs e)
        {
            saleIncrease("Sprite", 5);
        }

        private void btn_7Up_plus5_Click(object sender, EventArgs e)
        {
            saleIncrease("7Up", 5);
        }

        private void btn_pepsi_plus5_Click(object sender, EventArgs e)
        {
            saleIncrease("Pepsi", 5);
        }

        private void btn_computeSales_Click(object sender, EventArgs e)
        {
            totalSales = Bigquery_computeSodaSale();
            sodaSold = Bigquery_computeSodaSold();
            display_computeSale(totalSales, sodaSold);
        }

        private void btn_resetDemo_Click(object sender, EventArgs e)
        {
            Bigquery_resetSodaSale();
        }

        private void btn_preset_Click(object sender, EventArgs e)
        {
            load_Preset();
        }
        //--------------------------End---------------------------//
    }
}
