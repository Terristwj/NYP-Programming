﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

using System.Diagnostics;
using System.Threading.Tasks;
using GrovePi;
using GrovePi.Sensors;

namespace P02LedButtonToggleProgram
{
    public sealed class StartupTask : IBackgroundTask
    {
        //State Machine variables to control different mode of operation
        //const keyword is to declare a constant field or local and in this case, the constant is the integer
        const int MODE_OFF = 1;
        const int MODE_ON = 2;
        //to store the current mode the program is at
        static int curMode;

        //useD5 for Red LED and D4 for Push Button
        ILed ledRed;

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral
            //
            while (true)
            {
                Task.Delay(500).Wait();
                try
                {
                    ledRed = DeviceFactory.Build.Led(Pin.DigitalPin5);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message.ToString());
                }
            }
        }
    }
}
