﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

using System.Diagnostics;
using System.Threading.Tasks;

namespace P11RFIDCardReader
{
    public sealed class StartupTask : IBackgroundTask
    {
        private static SerialComms uartComms;
        private static string strRfidDetected = "";

        private void Sleep(int NoOfMs)
        {
            Task.Delay(NoOfMs).Wait();
        }
        static void UartDataHandler(object sender, SerialComms.UartEventArgs e)
        {
            Debug.WriteLine("START 12");
            strRfidDetected = e.data;
            Debug.WriteLine("Card detected: " + strRfidDetected);
            Debug.WriteLine("START 13");
        }
        private void StartUart()
        {
            uartComms = new SerialComms();
            Debug.WriteLine("START 1");
            uartComms.UartEvent += new SerialComms.UartEventDelegate(UartDataHandler);
            Debug.WriteLine("START 2");
        }
        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral
            //
            StartUart();

            while (true)
            {
                Sleep(200);
                if (!strRfidDetected.Equals(""))
                {
                    Debug.WriteLine("One card is detected.");
                }

                strRfidDetected = "";
            }
        }
    }
}
