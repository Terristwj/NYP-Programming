﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

using System.Diagnostics;   
using System.Threading.Tasks;

namespace RfidDetect
{
    public sealed class StartupTask : IBackgroundTask
    {
        private static SerialComms uartComms;
        private static string strRfidDetected = ""; //used to check for RFID

        private void Sleep(int NoOfMs)
        {
            Task.Delay(NoOfMs).Wait();
        }

        //this method is automatically called when there is card detected
        static void UartDataHandler(object sender, SerialComms.UartEventArgs e)
        {
            Debug.WriteLine("c");
            //strRfidDetected can be used anywhere in the program to check
            //for card detected
            strRfidDetected = e.data;
            Debug.WriteLine("Card detected : " + strRfidDetected);
        }

        //Must call this to initialise the Serial Comms
        private void StartUart()
        {
            uartComms = new SerialComms();
            Debug.WriteLine("a");
            uartComms.UartEvent += new SerialComms.UartEventDelegate(UartDataHandler);
            Debug.WriteLine("b");
        }

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral

            //Must call this to init the Serial Comm before you can use it
            StartUart();

            while (true)
            {
                Sleep(200);

                if (!strRfidDetected.Equals(""))//this is true for any card detected
                {
                    Debug.WriteLine("One Card is detected.");
                    Debug.WriteLine("Can you figure out how to check for a specific card?\n");
                }

                //Important: Must always clear after you've processed the data
                strRfidDetected = "";
            }
        }
    }
}
