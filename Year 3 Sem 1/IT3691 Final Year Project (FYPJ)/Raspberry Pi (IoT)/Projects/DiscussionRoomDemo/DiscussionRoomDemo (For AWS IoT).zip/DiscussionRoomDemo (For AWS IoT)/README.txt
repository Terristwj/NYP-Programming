
This project is fully functional by itself.

It can also be used with the WinForm SpotfireDemo App, IoT Demo.

You can refer to the documentation for more details.


Important Note:
1. You can set the time variable for the alarm interval to change the time cap for no motion.

2. You can change the card to initiate the project by changing the cardID.