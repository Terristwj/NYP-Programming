﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

// Additional libraries
using System.Diagnostics;
using System.Threading.Tasks;
using GrovePi;
using GrovePi.Sensors;

namespace DiscussionRoomDemo
{
    public sealed class StartupTask : IBackgroundTask
    {
        /**
        // Sensor Modes - Uncomment and apply to create sensor filters
        const int MODE_SENDLIGHT = 1;
        const int MODE_SENDBUTTON = 2;
        static int curMode;             // Stores the current mode the program is at
        **/

        // For Data Comms (Connect to Windows Forms)
        DataComms dataComms;        // Used to check for any incoming data from WinForm
            
                                                                                                                // Add IoT Sensors HERE
        // Raspberry Pi Hardware Settings                                                   // RPISER - RFID sensor
        Pin lightPin = Pin.AnalogPin1;                                                      // A1 - Light sensor
        IButtonSensor button = DeviceFactory.Build.ButtonSensor(Pin.DigitalPin4);           // D4 - Button sensor
        Pin PirMotionSensorPin = Pin.DigitalPin2;                                           // D2 - Pir Motion Sensor
        Pin buzzerPin = Pin.DigitalPin3;                                                    // D3 - Buzzer Sensor
        ILed ledRed = DeviceFactory.Build.Led(Pin.DigitalPin5);                             // D5 - Red LED sensor
        ILed ledGreen = DeviceFactory.Build.Led(Pin.DigitalPin6);                           // D6 - Green LED sensor


        // Light sensor                                                                                       // Add variables for IoT Sensors HERE
        int lightValue;
        int new_lightValue = 0;
        int prev_lightValue = 0, read_lightValue, diff_lightValue = 0;
        private bool lightDark = true;
        private bool prevLightDark = true;

        // Button sensor
        private bool buttonPressed = false;

        // Motion Sensor
        private bool motionDetected = false;
        private bool prev_motionDetected = false;

        // Mixture of motion and buzzer
        private int secondsOf_noMotion;                         // Used to check how many seconds there is no movement
        private int secondsOf_noMotion_Cap = 15;                // This is the cap. If the number reaches this, sound buzzer.
        private string buzzer_Reason = "Warning";
        private int buzzer_WarningCounter = 0;

        // RFID seonsor - Card Reader
        private static SerialComms uartComms;
        private static string strRfidDetected = "";             // Used to check for RFID
        private string cardNumber = "6A003E3EF399";             // Adjust for specific card
        int card_tapNumber;


        // Other classes added
        Utility utility = new Utility();

        // Start tracking
        Boolean begin = false;              // Begin will start only after card is entered

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral
            //

            dataComms = new DataComms();    // starts connection to WinForms
            utility.Sleep(5000);            // Wait 5 seconds to establish connection

            // Program begins here
            utility.sendDataToWindows(dataComms, "CONNECTION=true");

            specifySwitch_redLED("On");
            specifySwitch_greenLED("Off");

            start_Uart();                   // Rfid sensor - Configuration
            start_RfidMonitoring();         // Rfid monitor - Check for card, then start booking

            // This makes sure the main program runs indefinitely
            while (true)
            {
                if (begin == true)
                {
                    start_ButtonMonitoring();       // Button sensor - If button is pressed, "ends" the simulation by turning off all sensor.
                    start_MotionMonitoring();


                    while (begin == true)
                    {
                        utility.Sleep(1000);    // 1 second
                        
                        lightValue = getLight(); // Get light from sensor

                        //if (lightDark != prevLightDark)                               // Uncomment if want to just check light status
                        if (lightValue <= 500)
                            Debug.WriteLine("Light = " + lightValue + ", " + "Dark");
                        else
                            Debug.WriteLine("Light = " + lightValue + ", " + "Bright");

                        // Handlers for light sensor
                        if (!buttonPressed)                                             // Condition to prevent light retrieval after simulation close
                            handleModeSendLight();
                    }
                }
            }
        }

        /**********************************************************************
                                Light Sensor
        **********************************************************************/
        private int getLight()                                                  // Get light value from sensor
        {
            read_lightValue = DeviceFactory.Build.GrovePi().AnalogRead(lightPin);     

            if (prev_lightValue > read_lightValue)
                diff_lightValue = prev_lightValue - read_lightValue;
            else
                diff_lightValue = read_lightValue - prev_lightValue;

            prev_lightValue = read_lightValue;

            if (diff_lightValue < 100)
                new_lightValue = read_lightValue;

            return new_lightValue;
        }

        private void handleModeSendLight()          
        {
            //  1. Define Behaviour in this mode
            if (lightValue <= 500) // Must be same threshold as Winform
                lightDark = true;
            else
                lightDark = false;

            //if (prevLightDark != lightDark) // Send only when change of light status. Eg: Bright / Dark
            //    utility.sendDataToWindows(dataComms, "LIGHT=" + lightValue);

            utility.sendDataToWindows(dataComms, "LIGHT=" + lightValue);   // Send everytime

            prevLightDark = lightDark; // Must always update
        }
        /*------------------  End Light Sensor  -----------------------------*/



        /**********************************************************************
                                Button Sensor
        **********************************************************************/
                                                                 // Used to stop program/simulation
        private async void start_ButtonMonitoring()              // Runs by itself own forever, asynchronous run
        {
            await Task.Delay(100);
            while (true)
            {
                utility.Sleep(100);
                string buttonState = button.CurrentState.ToString();
                if (buttonState.Equals("On"))
                {
                    buttonState = button.CurrentState.ToString();
                    if (buttonState.Equals("On"))
                    {
                        End_Simulation();
                    }
                }
            }
        }

        private void End_Simulation()
        {
            buttonPressed = true;
            begin = false;

            Debug.WriteLine("Button pressed = " + buttonPressed.ToString());
            Debug.WriteLine("Stopping program");

            //utility.sendDataToWindows(dataComms, "BUTTON=" + "Pressed");      // Not used as button used to end simulation alrdy.
            utility.sendDataToWindows(dataComms, "BEGIN=" + begin);
            utility.Sleep(500);

            // When begin == false
            specifySwitch_LED(ledRed, "Off");
            specifySwitch_LED(ledGreen, "Off");
            soundBuzzer_end();
        }
        /*------------------  End Button Sensor  -----------------------------*/



        /**********************************************************************
                                Motion Sensor
        **********************************************************************/
        private async void start_MotionMonitoring()              // Runs by itself own forever, asynchronous run
        {
            await Task.Delay(100);
            while (true)
            {
                while (begin == true)
                {
                    utility.Sleep(500);
                    if (!buttonPressed)                             // Condition to prevent light retrieval after simulation close
                    {
                        string motionState = DeviceFactory.Build.GrovePi().DigitalRead(PirMotionSensorPin).ToString();

                        if (motionState.Equals("1"))
                            motionDetected = true;
                        else
                            motionDetected = false;

                        if (motionDetected != prev_motionDetected)                                      // Sends motion status if change
                        {
                            Debug.WriteLine("Movement = " + motionDetected.ToString());

                            utility.sendDataToWindows(dataComms, "MOTION=" + motionDetected.ToString());

                            prev_motionDetected = motionDetected;
                            motionDetected = !motionDetected;
                        }

                        if (!motionDetected)                                                             // Buzzer integration for no motion
                        {
                            secondsOf_noMotion++;
                            utility.Sleep(1000);

                            if (secondsOf_noMotion == secondsOf_noMotion_Cap)                           // No_motion_duration_cap is reached
                            {
                                if (buzzer_WarningCounter < 3)                                             // 3 warning chances
                                    buzzer_WarningCounter++;
                                else                                                                        // Activates status "Alarm"
                                    buzzer_Reason = "Alarm";

                                // Send data to WinForms
                                utility.sendDataToWindows(dataComms, "BUZZER=" + secondsOf_noMotion + "," + buzzer_Reason);
                                


                                for (int i = 0; i < 3; i++)                                             // Repeat buzzer 3 times
                                {
                                    Debug.WriteLine(buzzer_Reason);
                                    if (buzzer_Reason.Equals("Warning"))
                                        soundBuzzer_alarm_Warning();                                        // Warning
                                    else if (buzzer_Reason.Equals("Alarm"))
                                        soundBuzzer_alarm_Alarm();                                          // Alarm
                                }

                                if (buzzer_Reason.Equals("Alarm"))
                                    End_Simulation();

                                secondsOf_noMotion = 0;                                                 // Reset to 0 seconds. Buzzer rang
                            }
                        }
                        else                                                                            // Reset to 0 seconds. Motion detected
                        {
                            secondsOf_noMotion = 0;
                        }
                    }
                }
            }
        }
        /*------------------  End Button Sensor  -----------------------------*/



        /**********************************************************************
                                Buzzer Sensor
        **********************************************************************/
        private void soundBuzzer_start()                                            // Call this method to ring buzzer ONCE
        {
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 60);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 0);
        }
        private void soundBuzzer_end()                                                  // Call this method to ring buzzer
        {
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 120);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 90);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 60);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 30);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 0);
            utility.Sleep(2000);
        }
        private void soundBuzzer_alarm_Warning()                                                  // Call this method to ring buzzer warning
        {
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 60);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 120);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 60);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 120);
            utility.Sleep(80);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 0);
            utility.Sleep(2000);
        }
        private void soundBuzzer_alarm_Alarm()                                                  // Call this method to ring buzzer alarm
        {
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 200);
            utility.Sleep(2000);
            DeviceFactory.Build.GrovePi().AnalogWrite(buzzerPin, 0);
            utility.Sleep(2000);
        }
        /*------------------  End Button Sensor  -----------------------------*/



        /**********************************************************************
                             RFID Sensor - Card Reader
        **********************************************************************/
        private void start_Uart()                                                            // Must call this to initialise the Serial Comms
        {
            uartComms = new SerialComms();
            uartComms.UartEvent += new SerialComms.UartEventDelegate(UartDataHandler);
        }

        static void UartDataHandler(object sender, SerialComms.UartEventArgs e)            // Method automatically called when a card is detected
        {
            strRfidDetected = e.data;
            Debug.WriteLine("Card detected: " + strRfidDetected);
        }
        private async void start_RfidMonitoring()              // Runs by itself own forever, asynchronous run
        {
            await Task.Delay(100);
            while (true)
            {
                utility.Sleep(500);
                if (!strRfidDetected.Equals(""))                // A card is detected
                {
                    if (strRfidDetected.Equals(cardNumber))     // Card ID is correct
                    {
                        if (begin == false)                     // First time = student enter room
                        {
                            soundBuzzer_start();
                            begin = true;
                            card_tapNumber = 1;
                            utility.sendDataToWindows(dataComms, "BEGIN=" + begin);
                            utility.sendDataToWindows(dataComms, "CARDTAP=" + card_tapNumber);

                            switch_redLED();        // Will be On
                            switch_greenLED();      // Will be Off
                        }
                        else                                    // Not fist time = count number of taps
                        {
                            card_tapNumber++;
                            utility.sendDataToWindows(dataComms, "CARDTAP=" + card_tapNumber);
                            utility.Sleep(2000);                // Wait 2 seconds if not will count too fast
                        }
                    }
                    else
                    {
                        utility.sendDataToWindows(dataComms, "WRONGCARD=" + cardNumber);
                    }
                    strRfidDetected = "";
                }
            }
        }
        /*------------------  End Button Sensor  -----------------------------*/



        /**********************************************************************
                                Red/Green LED Sensor
        **********************************************************************/
        private void switch_redLED()                                // Call these methods
        {
            switch_LED(ledRed);
            led_dataToWindows("red");
        }
        private void switch_greenLED()
        {
            switch_LED(ledGreen);
            led_dataToWindows("green");
        }
        private void specifySwitch_redLED(string status)
        {
            specifySwitch_LED(ledRed, status);
            led_dataToWindows("red");
        }
        private void specifySwitch_greenLED(string status)
        {
            specifySwitch_LED(ledGreen, status);
            led_dataToWindows("green");
        }


                                                                    // Algorithm for LED sensor
        private void switch_LED(ILed ledColor)
        {
            if (ledColor.CurrentState.ToString().Equals("Off"))
                ledColor.ChangeState(SensorStatus.On);
            else
                ledColor.ChangeState(SensorStatus.Off);
        }
        private void specifySwitch_LED(ILed ledColor, string status)
        {
            if (status.Equals("On"))
                ledColor.ChangeState(SensorStatus.On);
            else
                ledColor.ChangeState(SensorStatus.Off);
        }
        private void led_dataToWindows(string color)
        {
            if (color.Equals("red"))
                utility.sendDataToWindows(dataComms, "REDLED=" + ledRed.CurrentState.ToString());
            else if (color.Equals("green"))
                utility.sendDataToWindows(dataComms, "GREENLED=" + ledGreen.CurrentState.ToString());
        }
        /*------------------  End Button Sensor  -----------------------------*/

    }
}
