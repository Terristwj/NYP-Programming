﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

// Additional libraries
using System.Diagnostics;
using System.Threading.Tasks;
using GrovePi;
using GrovePi.Sensors;

namespace DiscussionRoomDemo
{
    public sealed class StartupTask : IBackgroundTask
    {
        /**
        // Sensor Modes - Uncomment and apply to create sensor filters
        const int MODE_SENDLIGHT = 1;
        const int MODE_SENDBUTTON = 2;
        static int curMode;             // Stores the current mode the program is at
        **/

        // For Data Comms (Connect to Windows Forms)
        DataComms dataComms;        // Used to check for any incoming data from WinForm
        
        // Raspberry Pi Hardware Settings                                                                       // Add IoT Sensors HERE
        Pin lightPin = Pin.AnalogPin1;                                                      // A1 - Light sensor
        IButtonSensor button = DeviceFactory.Build.ButtonSensor(Pin.DigitalPin4);           // D4 - Button sensor
        Pin PirMotionSensorPin = Pin.DigitalPin2;                                           // D2 - Pir Motion Sensor
        

        // Light sensor                                                                                       // Add variables for IoT Sensors HERE
        int lightValue;
        int new_lightValue = 800;
        int prev_lightValue = 800, read_lightValue, diff_lightValue = 0;
        private bool lightDark = false;
        private bool prevLightDark = false;

        // Button sensor
        private bool buttonPressed = false;

        // Motion Sensor
        private bool motionDetected = false;
        private bool prev_motionDetected = false;


        // Other classes added
        Utility utility = new Utility();

        // Track output number, you may delete this
        int numTracker = 1;

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral
            //

            dataComms = new DataComms();    // starts connection to WinForms

                                                                                                    // Add any IoT sensors that require monitoring HERE
            start_ButtonMonitoring();                                                               // Monitoring by asynchronous run
            start_MotionMonitoring();


            // This makes sure the main program runs indefinitely
            while (true)
            {
                utility.Sleep(1000);    // 1 second

                Debug.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~" + numTracker++);
                lightValue = getLight(); // Get light from sensor

                // Output for each sensor
                if (lightValue <= 500)
                    Debug.WriteLine("Light = " + lightValue + ", " + "Dark");
                else
                    Debug.WriteLine("Light = " + lightValue + ", " + "Bright");

                // Handlers for each sensor
                handleModeSendLight();
            }
        }

        /**********************************************************************
                                Light Sensor
        **********************************************************************/
        private int getLight()                                                  // Get light value from sensor
        {
            read_lightValue = DeviceFactory.Build.GrovePi().AnalogRead(lightPin);     

            if (prev_lightValue > read_lightValue)
                diff_lightValue = prev_lightValue - read_lightValue;
            else
                diff_lightValue = read_lightValue - prev_lightValue;

            prev_lightValue = read_lightValue;

            if (diff_lightValue < 100)
                new_lightValue = read_lightValue;

            return new_lightValue;
        }

        private void handleModeSendLight()          
        {
            //  1. Define Behaviour in this mode
            if (lightValue <= 500) // Must be same threshold as Winform
                lightDark = true;
            else
                lightDark = false;

            if (prevLightDark != lightDark) // Send only when change of light status. Eg: Bright / Dark
                utility.sendDataToWindows(dataComms, "LIGHT=" + lightValue);

            prevLightDark = lightDark; // Must always update
        }
        /*------------------  End Light Sensor  -----------------------------*/



        /**********************************************************************
                                Button Sensor
        **********************************************************************/
        private async void start_ButtonMonitoring()              // Runs by itself own forever, asynchronous run
        {
            await Task.Delay(100);
            while (true)
            {
                utility.Sleep(500);
                string buttonState = button.CurrentState.ToString();
                if (buttonState.Equals("On"))
                {
                    buttonState = button.CurrentState.ToString();
                    if (buttonState.Equals("On"))
                    {
                        Debug.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~" + numTracker++);
                        buttonPressed = true;
                        Debug.WriteLine("Button pressed = " + buttonPressed.ToString());

                        utility.sendDataToWindows(dataComms, "BUTTON=" + "Pressed");
                        buttonPressed = false;
                    }
                }
            }
        }
        /*------------------  End Button Sensor  -----------------------------*/



        /**********************************************************************
                                Motion Sensor
        **********************************************************************/
        private async void start_MotionMonitoring()              // Runs by itself own forever, asynchronous run
        {
            await Task.Delay(100);
            while (true)
            {
                utility.Sleep(500);
                string motionState = DeviceFactory.Build.GrovePi().DigitalRead(PirMotionSensorPin).ToString();

                if (motionState.Equals("1"))
                    motionDetected = true;
                else
                    motionDetected = false;

                if (motionDetected != prev_motionDetected)
                    {
                        Debug.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~" + numTracker++);
                        Debug.WriteLine("Movement = " + motionDetected.ToString());

                        utility.sendDataToWindows(dataComms, "MOTION=" + motionDetected.ToString());

                        prev_motionDetected = motionDetected;
                        motionDetected = !motionDetected;
                    }
                    Task.Delay(3000).Wait();
            }
        }
        /*------------------  End Button Sensor  -----------------------------*/

    }
}
