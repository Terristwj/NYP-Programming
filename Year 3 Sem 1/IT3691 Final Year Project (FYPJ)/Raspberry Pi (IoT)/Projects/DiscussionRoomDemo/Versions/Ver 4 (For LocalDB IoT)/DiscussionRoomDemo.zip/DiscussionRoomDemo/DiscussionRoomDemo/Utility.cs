﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Additional libraries
using System.Diagnostics;
using System.Threading.Tasks;

namespace DiscussionRoomDemo
{
    class Utility
    {
        public void Sleep(int NoOfMs)                      // Utility method - Set a waiting time
        {
            Task.Delay(NoOfMs).Wait();
        }

        public void sendDataToWindows(DataComms dataComms, string strDataOut)                // Utility Method - Send data to WinForms
        {
            try
            {
                dataComms.sendData(strDataOut);
            }
            catch (Exception)
            {
                Debug.WriteLine("ERROR. Did you forget to initComms()?");
            }
        }
    }
}
