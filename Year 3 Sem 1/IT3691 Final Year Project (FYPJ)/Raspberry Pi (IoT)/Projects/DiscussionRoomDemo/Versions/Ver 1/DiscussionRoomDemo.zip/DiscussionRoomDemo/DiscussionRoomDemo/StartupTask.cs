﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

// Additional libraries
using System.Diagnostics;
using System.Threading.Tasks;
using GrovePi;
using GrovePi.Sensors;

namespace DiscussionRoomDemo
{
    public sealed class StartupTask : IBackgroundTask
    {
        // State Machine variables to control different mode of operation
        const int MODE_SENDLIGHT = 1;
        const int MODE_SENDBUTTON = 2;
        static int curMode;             // Stores the current mode the program is at

        // Use A1 for light sensor and D4 for Push button
        Pin lightPin = Pin.AnalogPin1;
        IButtonSensor button = DeviceFactory.Build.ButtonSensor(Pin.DigitalPin4);

        // For Data Comms
        DataComms dataComms;
        //this is used to check for data coming in from Winform
        string strDataReceived = "";

        // Used by sensor for internal processing
        int lightAdcValue = 800;
        int iPrevAdcValue = 800, iReadAdcValue, iDiff = 0;

        //This si for main logic controller to know that a button is pressed
        private bool buttonPressed = false;
        private bool prevButtonStatus = false;

        int sensorLightAdcValue;
        private bool lightDark = false;
        private bool prevLightDark = false;

        private void Sleep(int NoOfMs)
        {
            Task.Delay(NoOfMs).Wait();
        } // End Sleep()

        private int getLight()
        {
            iReadAdcValue = DeviceFactory.Build.GrovePi().AnalogRead(lightPin);

            if (iPrevAdcValue > iReadAdcValue)
                iDiff = iPrevAdcValue - iReadAdcValue;
            else
                iDiff = iReadAdcValue - iPrevAdcValue;

            iPrevAdcValue = iReadAdcValue;
            if (iDiff < 100)
                lightAdcValue = iReadAdcValue;

            return lightAdcValue;
        } // End of getLight()

        private async void startButtonMonitoring()
        {
            await Task.Delay(100);
            while (true)
            {
                Sleep(100);
                string buttonState = button.CurrentState.ToString();
                if (buttonState.Equals("On"))
                {
                    Sleep(100);
                    buttonState = button.CurrentState.ToString();
                    if (buttonState.Equals("On"))
                    {
                        buttonPressed = true;
                    }
                }
            }
        } // End of startButtonMonitoring()

        // This method is automatically called when data comes from WinForm
        public void commsDataReceive(string dataReceived)
        {
            // You can use strDataReceived anywhere in your codes to
            // check for any data coming in from Winform
            strDataReceived = dataReceived;
            Debug.WriteLine("Data Received: " + strDataReceived);
        }

        //use this method to send data out to Winforms
        private void sendDataToWindows(string strDataOut)
        {
            try
            {
                dataComms.sendData(strDataOut);
                Debug.WriteLine("Sending Msg: " + strDataOut);
            }
            catch (Exception)
            {
                Debug.WriteLine("ERROR. Did you forget to initComms()?");
            }
        }

        // This is to setup the comms for data transfer with Winforms
        private void initComms()
        {
            dataComms = new DataComms();
            dataComms.dataReceiveEvent += new DataComms.DataReceivedDelegate(commsDataReceive);
        } // End InitComms()

        private void handleModeSendLight()
        {
            //  1. Defind Behaviour in this mode
            if (sensorLightAdcValue <= 500) // Must be same threshold as Winform
                lightDark = true;
            else
                lightDark = false;

            if (prevLightDark != lightDark) // Send only when change of status
                sendDataToWindows("Light=" + sensorLightAdcValue);

            prevLightDark = lightDark; // Must always update

            //  2. Must write the condition to move on to other modes
            if (strDataReceived.Equals("SENDBUTTON"))
            {
                // Move on to Mode Send Button status when button is pressed
                curMode = MODE_SENDBUTTON;
                Debug.WriteLine("===Entering MODE_SENDBUTTON===");
            }
            strDataReceived = ""; //Must always clear after processing;
        } // End handleModeSendLight()

        private void handleModeSendButton()
        {
            //  1. Define Behaviour in this mode
            if (buttonPressed != prevButtonStatus)
            {
                sendDataToWindows("BUTTON=" + buttonPressed);
            }

            prevButtonStatus = buttonPressed;
            buttonPressed = false;  // Clear after processing

            //  2. Must write the condition to move on to other modes
            if (strDataReceived.Equals("SENDLIGHT"))
            {
                // Move on to Mode Send Button when button is pressed
                curMode = MODE_SENDBUTTON;
                Debug.WriteLine("===Entering MODE_SENDLIGHT===");
            }
            strDataReceived = ""; // Must always clear after processing
        } // End handleModeSendButton()

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral
            //

            initComms(); // Must start before data transfer can work

            // Start the button self monitoring method
            startButtonMonitoring();

            // Init Mode
            curMode = MODE_SENDLIGHT;
            Debug.WriteLine("===Entering MODE_SENDLIGHT===");

            // This makes sure the main program runs indefinitely
            while (true)
            {
                Sleep(300);
                sensorLightAdcValue = getLight(); // Get light from esnsor
                Debug.WriteLine("Sensor Light = " + sensorLightAdcValue);

                // State machine
                if (curMode == MODE_SENDLIGHT)
                    handleModeSendLight();
                else if (curMode == MODE_SENDBUTTON)
                    handleModeSendButton();
                else
                    Debug.WriteLine("ERROR: Invalid Mode. Please check your logic");
            }
        }
    }
}
