import { Component, OnInit } from '@angular/core';
import { Product } from '../shared/models/product';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage implements OnInit {
  productList: Product[];

  constructor() {
  }

  ngOnInit() {
    this.productList = [
      new Product('Oprah Stool', 100, 'assets/img/oprah.jpg', 15, 'add'),
      new Product('Knit Cozy Stool', 80, 'assets/img/knit.jpg',  20, 'add'),
      new Product('Camila Bar Chair', 10, 'assets/img/camila.jpg', 0, 'add'),
      new Product('Holly Counter Stool', 120, 'assets/img/holly.jpg', 10, 'add'),
      new Product('Grant Contour Chair', 500, 'assets/img/grant.jpg', 0, 'add'),
    ];
  }

  getFavText(item: Product) {
    return 'Favourite';
  }

}
