import { Injectable } from '@angular/core';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class FavService {
  items: Product[] = [];

  constructor() { }

  getItems(): Product[] {
    return this.items;
  }

  isAdded(product: Product): boolean {
    let found = false;
    for (const item of this.items) {
      if (item.description === product.description) {
        found = true;
        break;
      }
    }
    return found;
  }

  add(product: Product) {
    // If product already in items, do nothing
    const found = this.isAdded(product);

    // If product not in items, add
    if (!found) {
      this.items.push(product);
    }
  }

  remove(product: Product) {
    let found;
    for (const index in this.items) {
      if (this.items[index].description === product.description) {
        found = index;
        break;
      }
    }
    if (found !== undefined) {
      this.items.splice(found, 1);
    }
  }

}
