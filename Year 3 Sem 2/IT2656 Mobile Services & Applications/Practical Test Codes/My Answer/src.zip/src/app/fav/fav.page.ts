import { Component, OnInit } from '@angular/core';
import { FavService } from '../shared/services/fav.service';
import { Product } from '../shared/models/product';

@Component({
  selector: 'app-fav',
  templateUrl: './fav.page.html',
  styleUrls: ['./fav.page.scss'],
})
export class FavPage implements OnInit {
  favItems: Product[];

  constructor(private favService: FavService) { }

  ngOnInit() {
    this.favItems = this.favService.getItems();
  }

}
