import { Component, OnInit } from '@angular/core';
import { GridService } from '../shared/services/grid.service';
import { Product } from '../shared/models/product';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.page.html',
  styleUrls: ['./grid.page.scss'],
})
export class GridPage implements OnInit {
  allProducts: Product[];
  products: Product[];

  constructor(private gridService: GridService) { }

  search(event) {
    const text = event.target.value;
    if (text && text.trim() !== '') {
      this.products = this.allProducts.filter(
        item => item.description.toLowerCase().includes(text.toLowerCase()));
    } else {
      // Blank text, clear the search, show all products
      this.products = this.allProducts;
    }
  }

  ngOnInit() {
    this.gridService.getAll().then(
      result => this.products = this.allProducts = result
    );
  }

}
