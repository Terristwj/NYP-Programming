import { Component, OnInit } from '@angular/core';
import { Product } from '../shared/models/product';
import { FavService } from '../shared/services/fav.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage implements OnInit {
  productList: Product[];
  total: number = 0;

  constructor(public toastController: ToastController
    , private favService: FavService) {
  }

  toggle(product: Product){
    if (product.icon === "add"){
      product.icon = "add-circle";
      this.total += product.price;
    } else if (product.icon === "add-circle"){
      product.icon = "add";
      this.total -= product.price;
    }
  }

  async favButton(product: Product){
    var toastMsg: string = product.description;
    if (!this.favService.isAdded(product)){
      this.favService.add(product);
      toastMsg += ' added to favourite list';
    } else {
      this.favService.remove(product);
      toastMsg += ' removed from favourite list';
    }
    
    const toast = await this.toastController.create({
      message: toastMsg,
      duration: 2000,
      position: 'top',
      color: 'secondary'
    });

    toast.present();
  }

  refresh(event) {
    for (const i in this.productList){
      if (this.productList[i].icon === "add-circle")
      this.productList[i].icon = "add";
    }
    this.total = 0;
    event.target.complete();
  }

  ngOnInit() {
    this.productList = [
      new Product('Oprah Stool', 100, 'assets/img/oprah.jpg', 15, 'add'),
      new Product('Knit Cozy Stool', 80, 'assets/img/knit.jpg',  20, 'add'),
      new Product('Camila Bar Chair', 10, 'assets/img/camila.jpg', 0, 'add'),
      new Product('Holly Counter Stool', 120, 'assets/img/holly.jpg', 10, 'add'),
      new Product('Grant Contour Chair', 500, 'assets/img/grant.jpg', 0, 'add'),
    ];
  }

  getFavText(item: Product) {
    var favItems: Product[] = this.favService.getItems();
    for (const i in favItems){
      if (item.description === favItems[i].description){
        return 'Unfavourite';
      }
    }
    return 'Favourite';
  }

}
