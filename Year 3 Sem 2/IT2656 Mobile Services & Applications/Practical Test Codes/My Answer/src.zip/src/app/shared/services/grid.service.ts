import { Injectable } from '@angular/core';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class GridService {
  products: Product[];

  constructor() {
    this.products = [
      new Product('Samsung', 949, 'assets/img/samsung.jpg', 2, 'star'),
      new Product('LG', 649, 'assets/img/lg.jpg', 3, 'star-outline'),
      new Product('Midea', 399, 'assets/img/midea.jpg', 1, 'star-outline'),
      new Product('Fisher & Parkel', 1049, 'assets/img/fisher.jpg', 3, 'star'),
      new Product('Whirlpool', 999, 'assets/img/whirlpool.jpg', 2, 'star-half'),
    ];
  }

  getAll() {
    const promise = new Promise<Product[]>((resolve, reject) => {
      resolve(this.products);
    });
    return promise;
  }
}
