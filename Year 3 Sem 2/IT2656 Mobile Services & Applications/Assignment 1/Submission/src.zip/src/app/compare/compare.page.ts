import { Component, OnInit } from '@angular/core';
import { CompareService } from '../shared/services/compare.service';
import { Course } from '../shared/models/Course';

@Component({
  selector: 'app-compare',
  templateUrl: './compare.page.html',
  styleUrls: ['./compare.page.scss'],
})
export class ComparePage implements OnInit {
  compareCourses: Course[];

  // Injected 'CompareService' (1m)
  constructor(private compareService: CompareService) { }

  // delete() used for (ionSwipe)=delete() (2m)
  delete(course: Course){
    this.compareService.remove(course);
  }

  // ngOnInit(), call 'getCourse()' and store the data (1m)
  ngOnInit() {
    this.compareCourses = this.compareService.getCourses();
  }
}

// 'ionic generate page compare' (1m)
