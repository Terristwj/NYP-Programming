import { Component } from '@angular/core';
import { ReviewService } from '../shared/services/review.service';
import { Review } from '../shared/models/review';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  allReviews: Review[];
  reviews: Review[];

  // Inject 'ReviewService' (1m)
  constructor(private reviewService: ReviewService) {
  }

  ngOnInit(){
    // Call 'ReviewService.getAll() (2.5m)
    this.reviewService.getAll().then(
      result => this.reviews = this.allReviews = result
    );
  }

  // Search function (2.5m)
  search(event){
    const text = event.target.value;
    if (text && text.trim() !== '') {
      this.reviews = this.allReviews.filter(
        item => item.course.toLowerCase().includes(text.toLowerCase()));
    } else {
      // Blank text, clear the search, show all reviews
      this.reviews = this.allReviews;
    }
  }
}
