import { Injectable } from '@angular/core';
import { Review } from '../models/review';

@Injectable({
  providedIn: 'root'
})

export class ReviewService {
  reviews: Review[];

  constructor() {
    this.reviews = [
    new Review('iOS', 'Very good', 'Amy', 5),
    new Review('iOS', 'Not comprehensive enough', 'Ben', 2),
    new Review('Android', 'Too simple, no depth', 'Candy', 1),
    new Review('Android', 'Very simple course to follow', 'Dan', 4),
    new Review('Android', 'Average, not bad', 'Eddie', 3),
    new Review('AWS', 'Had so much fun', 'Frank', 5)
    ];
  }
  
  getAll() {
    const promise = new Promise<Review[]>((resolve, reject) => {
      resolve(this.reviews);
    });
    return promise;
  }
}


// 'ionic generate service shared/services/review' (1m)