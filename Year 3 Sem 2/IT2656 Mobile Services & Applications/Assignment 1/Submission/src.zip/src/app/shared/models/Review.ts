export class Review {
    course: string;
    comment: string;
    name: string;
    rating: number;

    constructor(course: string, comment: string
        , name: string, rating: number) {
            this.course = course;
            this.comment = comment;
            this.name = name;
            this.rating = rating;
    }
}


/* 
    ____________________        (2m)
    |      Review       |
    |___________________|
    |   course: string  |
    |   comment:string  |
    |   name:   string  |
    |   rating: number  |
    |___________________|

*/