export class Course {
    title: string;
    price: number;
    picture: string;
    rating: number;
    icon: string;

    constructor(title: string, price: number
        , picture: string, rating: number
        , icon:string) {
            this.title = title;
            this.price = price;
            this.picture = picture;
            this.rating = rating;
            this.icon = icon;
    }
}


/* 
    ____________________        (2m)
    |      Course       |
    |___________________|
    |   title:  string  |
    |   price:  number  |
    |   picture:string  |
    |   rating: number  |
    |   icon:   string  |
    |___________________|

*/