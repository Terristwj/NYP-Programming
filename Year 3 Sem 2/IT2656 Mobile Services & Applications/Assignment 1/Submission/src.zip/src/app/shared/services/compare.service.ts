import { Injectable } from '@angular/core';
import { Course } from '../models/Course';

@Injectable({
  providedIn: 'root'
})
export class CompareService {
  // Create property 'compareItems' to store array of Course (1m)
  compareItems: Course[] = [];

  constructor() { }

  // Create 'getCourses() to return courses already inside 'CompareService' (2m)
  getCourses(): Course[]{
    return this.compareItems;
  }

  // Create 'isInCompare(..) to return boolean, 
  // to check courses is inside 'CompareService' (3m)
  isInCompare(course: Course){
    var inCompare: boolean = false;

    // For each item inside 'this.compareItems',
    // check if 'course' exist.
    for(const index in this.compareItems){
      if (this.compareItems[index].title === course.title){
        inCompare = true;
        // Since can exist only ONCE, break out of ForLoop
        break;
      }
    }
    return inCompare;
  }

  // Create add() to .push() course into the 'CompareService' (2m)
  add(course: Course){
    this.compareItems.push(course);

    // Used to debug, Inspect Google Chrome -> Console to view
    console.log(course.title + ' added')
  }
  
  // Create remove() to .splice(.., 1) course from 'CompareService' (2m)
  remove(course: Course){
    this.compareItems.splice(this.compareItems.indexOf(course), 1);
    
    // Used to debug, Inspect Google Chrome -> Console to view
    console.log(course.title + ' removed')
  }
}


// 'ionic generate service shared/services/compare' (1m)


/* 
    __________________________________       (10m)
    |        CompareService           |
    |_________________________________|
    |   getCourse():  Course[]        |
    |   isInCompare(Course):  boolean |
    |   add(Course)                   | 
    |   remove(Course)                |
    |_________________________________|

*/