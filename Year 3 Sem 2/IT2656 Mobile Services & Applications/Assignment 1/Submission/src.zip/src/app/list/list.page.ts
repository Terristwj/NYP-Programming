import { Component, OnInit } from '@angular/core';
import { Course } from '../shared/models/Course';
import { ToastController } from '@ionic/angular';
import { CompareService } from '../shared/services/compare.service';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage implements OnInit {

  // Create property courseList (1m)
  courseList: Course[];       
  // Extra array to keep track of 'add' & 'add-circle' status
  inCompare: Course[] = [];   

  // Injected with ToastController
  // Injected with CompareService (1m)
  constructor(public toastController: ToastController
    , private compareService: CompareService) {
  }

  // Function for toggle between 'add' and 'add-circle'
  // Toast message implemented here (1m)
  async addToCompare(item: Course){
    // First: Retrieve a number index from "this.inCompare.indexOf(item)"
    var index = this.inCompare.indexOf(item);
    let toastMsg: string; // Declare toastMsg

    // Second: Check the value of index, tells us if item exist inside 'inCompare'
    if (index > -1) {                         // If item exist
      this.inCompare.splice(index, 1);        // Remove item
      toastMsg = ' removed from Compare';
      this.commonRemoveCourse(item);          // Call common method

    } else {                                  // If item DO NOT exist
      this.inCompare.push(item);              // Add item
      toastMsg = ' added to Compare';
      this.compareService.add(item);          // Add item into 'Service' (1m)
      this.courseList[this.courseList.indexOf(item)].icon = 'add-circle';
    }
    
    // Create Toast
    const toast = await this.toastController.create({
      message: item.title + toastMsg,
      duration: 2000,
      position: 'top',
      color: 'secondary'
    });

    // Display Toast
    toast.present();
  }

  // 'Pull-to-Refresh', change icon (3m)
  refresh(event){
    // For each item inside 'inCompare', remove it inside the 'Service'
    for (const index in this.inCompare){
      this.commonRemoveCourse(this.inCompare[index]);
    }
    // Empty 'inCompare'
    this.inCompare = [];
    event.target.complete();
  }

  // Common reuseable Code
  // Remove item and change icon
  commonRemoveCourse(course: Course){
    // Remove the item from the 'Service' (1m)add-circle + (1m)pull-refresh
    this.compareService.remove(course);
    this.courseList[this.courseList.indexOf(course)].icon = 'add';
  }

  ngOnInit() {
    // Initialize with provided dummy data
    this.courseList = [
      new Course('AWS', 1068, 'assets/img/aws.png', 2, 'add'),
      new Course('iOS', 698, 'assets/img/IOS.jpg', 3, 'add'),
      new Course('Android', 698, 'assets/img/android.png', 1, 'add'),
      new Course('MBA', 4688, 'assets/img/mba.png', 1, 'add'),
      new Course('Unity', 2999, 'assets/img/unity.jpg', 3, 'add')
    ];    // Initialize array courseList (2m)
    
    // 'course' used for the following algorithm
    var course: Course;
    // Algorithm to decide icons upon loading page
    for(const index in this.courseList){
      course = this.courseList[index];
      
      // Call 'isInCompare(course)' inside ngOnInit (1m)
      // Used to return boolean to change icon
      // If icon change, push into inCompare[] to keep track of updated courses w/ icon
      if (this.compareService.isInCompare(course)){
        course.icon = 'add-circle';
        this.inCompare.push(course);
      }
    }
  }
}
