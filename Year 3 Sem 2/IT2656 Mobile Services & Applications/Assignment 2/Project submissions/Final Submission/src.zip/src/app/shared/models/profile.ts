export class Profile {
    email: string;
    name: string;
    photoUrl: string;
    dateJoined: string;

    constructor(email?: string, name?: string, photoUrl?: string
        , dateJoined?: string) {
        this.email = email;
        this.name = name;
        this.photoUrl = photoUrl;
        this.dateJoined = dateJoined;
    }
}