import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { NewsService } from '../shared/services/news.service';
import { News } from '../shared/models/news';

@Component({
  selector: 'app-news',
  templateUrl: './news.page.html',
  styleUrls: ['./news.page.scss'],
})
export class NewsPage implements OnInit {
  // Data
  currentTopic: string;
  allNews: News[] = [];
  // Validators
  isLoading: boolean;
  isLoading_excludeSearch: boolean;
  // API Settings
  api_totalResults: number;
  api_pageSize: number = 10;
  api_page: number;
  api_totalPages: number;
  api_httpUrl_1: string;
  api_httpUrl_2: string;
  // Infinite scroll
  infiniteScroll: boolean;

  constructor(public httpClient: HttpClient,
    private newsService: NewsService) {
   }

  ngOnInit() {
    // Initial data
    this.currentTopic = "top-headlines";
    this.isLoading = true;
    this.isLoading_excludeSearch = false;

    // console.log(this.isLoading);
    // console.log(this.isLoading_excludeSearch);

    // Call API
    this.call_newsAPI();
  }

  call_newsAPI(query?) {
    // API Website:
    // https://newsapi.org/
    
    // API Key
    var apiKey = "ef301b7a12164890a55626be0e323df2";

    // "top-headlines" or "everything"
    var subject: string;
    
    if (this.currentTopic == "top-headlines"){
      subject = "country=sg"
    } else if (this.currentTopic == "everything"){
      subject = "q=" + query;
    }

    // Page size max = 100
    var pageSize = this.api_pageSize;

    // Current page
    var page = this.api_page = 1;

    //  HTTP Url
    var httpUrl = "https://newsapi.org/v2/" + this.currentTopic + "?" + subject + "&pageSize=" + pageSize + "&page=" + page + "&apiKey=" + apiKey;
    
    // Call HTTP GET
    this.httpClient.get(httpUrl).subscribe(data => {
      // console.log('my data: ', data);
      // console.log(final_data);
      // console.log(final_data.ParsedResults[0].ParsedText);

      // HTTP data
      var final_data: any = data;
      // console.log(final_data);

      // API settings
      this.api_totalResults = final_data.totalResults;
      this.api_totalPages = Math.ceil(this.api_totalResults/this.api_pageSize);
      this.api_httpUrl_1 = "https://newsapi.org/v2/" + this.currentTopic + "?" + subject + "&pageSize=" + pageSize + "&page=";
      this.api_httpUrl_2 = "&apiKey=" + apiKey;
      this.infiniteScroll = true;
      
      // Check pages
      if (this.api_page == this.api_totalPages){
        this.infiniteScroll = false;
      }

      // Save data, accordingly
      if (this.currentTopic == "top-headlines"){
        for (let news of final_data.articles){
          // console.log(news);
          const myNews = new News(news.url, news.urlToImage, news.title, news.source.name);
          this.newsService.add(myNews);
          // console.log(myNews);
        }
      } else if (this.currentTopic == "everything"){
        for (let news of final_data.articles){
          // console.log(news);
          // Format data
          var publishedAt = this.format_publishedAt(news.publishedAt);
          const myNews = new News(news.url, news.urlToImage, news.title, news.source.name, publishedAt);
          this.newsService.add(myNews);
          // console.log(myNews);
        }
      }

      // SetTimeout because we want to finish the API GET first, then display data
      setTimeout( () => { this.getNews() }, 500 );
    })
  }

  // Used in call_newsAPI(query?)
  format_publishedAt(publishedAt){
    var text1 = publishedAt.split("T", 2)[0];
    var text2 = publishedAt.split("T", 2)[1];
    text2 = text2.split("Z", 1)[0];
    var finalText = text1 + ", " + text2;
    return finalText;
  }

  // Used in call_newsAPI(query?)
  getNews(){
    this.allNews = this.newsService.allNews;
    // Remove skeleton
    this.isLoading = false;
    this.isLoading_excludeSearch = false;
    // console.log(this.newsService.allNews);
    // console.log(this.allNews);
  }

  // Segment click
  segmentChange(currentTopic){
    this.currentTopic = currentTopic;
    // Display skeleton
    this.isLoading = true;
    
    // Reset data
    this.resetNews();

    if(this.currentTopic == "top-headlines"){
      this.call_newsAPI();
    } else if (this.currentTopic == "everything"){
      this.call_newsAPI("singapore");
    }
  }

  // Infinite Scroll
  loadData($event){
    setTimeout(() => {
      // console.log("Add more");
      this.call_newsAPI_add();
      $event.target.complete();
    }, 500);
  }

  // Add next data page, if possible
  call_newsAPI_add() {
    // console.log(this.api_page + 1);
    // console.log(this.api_totalPages);

    // If current page < final page
    if (this.api_page < this.api_totalPages){
      this.api_page = this.api_page + 1;

      // The original HTTP Url, but with next data page
      var httpUrl = this.api_httpUrl_1 + this.api_page + this.api_httpUrl_2;
      
      // Call HTTP GET
      this.httpClient.get(httpUrl).subscribe(data => {
        // console.log('my data: ', data);
        // console.log(final_data);
        // console.log(final_data.ParsedResults[0].ParsedText);

        // HTTP data
        var final_data: any = data;
        // console.log(final_data);

        // Add data, accordingly
        if (this.currentTopic == "top-headlines"){
          for (let news of final_data.articles){
            // console.log(news);
            const myNews = new News(news.url, news.urlToImage, news.title, news.source.name);
            this.newsService.add(myNews);
            // console.log(myNews);
          }
        } else if (this.currentTopic == "everything"){
          for (let news of final_data.articles){
            // console.log(news);
            // Format data
            var publishedAt = this.format_publishedAt(news.publishedAt);
            const myNews = new News(news.url, news.urlToImage, news.title, news.source.name, publishedAt);
            this.newsService.add(myNews);
            // console.log(myNews);
          }
        }
      })
    
      // If already at final page, disable infinte_scroll
      if (this.api_page == this.api_totalPages){
        this.infiniteScroll = false;
        // console.log(this.infiniteScroll)
      }
    }
  }

  // Search bar
  search($event){
    var text = $event.target.value;
    text = text.replace(" ", "_");

    // Display skeleton
    this.isLoading_excludeSearch = true;

    // Reset data
    this.resetNews();

    // Call News API
    if (text == ""){
      // Default
      this.call_newsAPI("singapore");
    } else{
      this.call_newsAPI(text);
    }
  }

  resetNews(){
    this.allNews = [];
    this.newsService.reset();
  }
}
