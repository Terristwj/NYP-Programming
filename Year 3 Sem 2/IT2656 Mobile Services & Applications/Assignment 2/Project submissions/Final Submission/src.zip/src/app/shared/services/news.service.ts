import { Injectable } from '@angular/core';
import { News } from '../models/news';


@Injectable({
  providedIn: 'root'
})
export class NewsService {
  allNews: News[] = [];
  
  constructor() {}

  add(news: News){
    this.allNews.push(news);
  }

  reset(){
    this.allNews = [];
  }
}
