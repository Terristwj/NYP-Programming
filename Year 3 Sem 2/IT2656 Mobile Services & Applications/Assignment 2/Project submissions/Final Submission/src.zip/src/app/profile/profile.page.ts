import { Component, OnInit } from '@angular/core';
import { User } from '../shared/models/user';
import { AuthService } from '../shared/services/auth.service';
import { FirebaseProfileService } from '../shared/services/firebase-profile.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  toggle: boolean = false;

  user: User = new User();
  profile: any;
  
  profileForm: FormGroup;
  profileError: string;
  submitted: boolean;

  photoUrl:string = "/assets/ProfilePics/Person/boy1.png";
  email:string = "";
  name:string = "";
  dateJoined:string = "";
  
  constructor(private authService: AuthService,
     private firebaseProfile: FirebaseProfileService,
     private toastController: ToastController,
     private navCtrl: NavController) { 
      this.profileForm = new FormGroup({
        name: new FormControl('')
      });
     }

  ngOnInit() {
    // Get user name
    this.user = this.authService.getCurrentUser();

    // Get user profile
    this.getProfile();
  }

  logout() {
    this.authService.logout();
    this.navCtrl.navigateRoot(['/home']);
  }

  getProfile(){
    // Get user profile
    this.firebaseProfile.getProfile(this.user.email).subscribe(data => {
      this.profile = data.map(e => {
        return {
          id: e.payload.doc.id,
          isEdit:false,
          email: e.payload.doc.data()['email'],
          name: e.payload.doc.data()['name'],
          photoUrl: e.payload.doc.data()['photoUrl'],
          dateJoined: e.payload.doc.data()['dateJoined']
        };
      })

      // console.log(this.profile);
      // console.log(Object.keys(this.profile).length);
      
      // Debugging codes
      // Will only use if accidentally delete profile of user
      if (Object.keys(this.profile).length == 0){
        // Create user profile
        this.createProfile();
        // Checks retrieve the new created profile
        this.getProfile();
      }

      this.profile = this.profile[0];
      
      // console.log(this.profile);
      // console.log(this.profile.photoUrl[1]);

      this.toggleSkeleton();
      this.loadProfile();

      // console.log(this.photoUrl);
    });
  }

  createProfile(){
    let record = {};
    record['email'] = this.user.email;
    record['name'] = this.user.email.split("@", 1)[0];
    record['photoUrl'] = ["Person", "boy1.png"];
    record['dateJoined'] = this.getDate();

    this.firebaseProfile.createProfile(record).then(resp => {
      // console.log(resp);
    })
      .catch(error => {
        console.log(error);
      });
  }
  
  // Used in createProfile()
  getDate(){
    const monthNames = ["January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
  ];

    var todayDate = new Date();
    var dd = todayDate.getDate();
    var mm = monthNames[todayDate.getMonth()]
    var yyyy = todayDate.getFullYear();

    var date: string = dd + ' ' + mm + ' ' + yyyy;
    return date;
  }

  // Used in createProfile()
  toggleSkeleton = () => {
    this.toggle = !this.toggle;
  }

  // Used in createProfile()
  loadProfile(){
    this.photoUrl = "/assets/ProfilePics/"
    this.photoUrl += this.profile.photoUrl[0] + "/";
    this.photoUrl += this.profile.photoUrl[1];
    
    this.email = this.profile.email;
    this.name = this.profile.name;
    this.dateJoined = this.profile.dateJoined;

    this.profileForm = new FormGroup({
      name: new FormControl(this.name, [Validators.required])
    });
  }

  // Bug -> toggle will auto change when calling this function
  async save() {
    this.submitted = true;
    var toastMsg = "Profile changes cancelled.";
    var color = "danger";

    if (this.profileForm.valid) {
      if (this.name != this.profileForm.value.name){
        this.updateProfile();
  
        toastMsg = "Profile changes saved.";
        color = "secondary";
      } else{
        toastMsg = "New name is the same as old name.";
      }
    }

    const toast = await this.toastController.create({
      message: toastMsg,
      duration: 2000,
      position: 'top',
      color: color
    });
    toast.present();
  }

  // Used in save()
  updateProfile(){
    let record = {};
    record['email'] = this.email;
    record['name'] = this.profileForm.value.name;
    record['photoUrl'] = this.profile.photoUrl;
    record['dateJoined'] = this.dateJoined;

    // console.log(this.profile.id);
    // console.log(record);

    this.firebaseProfile.updateProfile(this.profile.id, record);
    this.toggleSkeleton();
  }
}
