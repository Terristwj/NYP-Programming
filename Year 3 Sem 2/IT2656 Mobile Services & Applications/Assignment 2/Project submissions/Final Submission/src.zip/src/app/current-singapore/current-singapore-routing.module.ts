import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CurrentSingaporePage } from './current-singapore.page';

const routes: Routes = [
  {
    path: '',
    component: CurrentSingaporePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CurrentSingaporePageRoutingModule {}
