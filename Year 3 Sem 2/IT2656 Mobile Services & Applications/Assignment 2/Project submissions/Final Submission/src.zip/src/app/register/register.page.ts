import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../shared/services/auth.service';
import { ToastController, ModalController } from '@ionic/angular';
import { LoginPage } from '../login/login.page';
import { FirebaseProfileService } from '../shared/services/firebase-profile.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  registerForm: FormGroup;
  registerError: string;

  constructor(private authService: AuthService,
    private toastController: ToastController,
    private modalController: ModalController,
    private firebaseProfile: FirebaseProfileService) {
      this.registerForm = new FormGroup({
        email: new FormControl(''),
        password: new FormControl(''),
        gender: new FormControl('m')
      });
  }

  ngOnInit() {
  }
  
  async back() {
    this.dismiss();
    const modal = await this.modalController.create({
      component: LoginPage
    });
    return await modal.present();
  }

  dismiss() {
    this.modalController.dismiss();
  }

  register() {
    this.authService.signup(this.registerForm.value.email, this.registerForm.value.password,).then(
        async () => {
          const toast = await this.toastController.create({
            message: 'Logged in as ' + this.registerForm.value.email,
            duration: 2000,
            position: 'top',
            color: 'secondary'
          });
          toast.present();
          this.dismiss();

          this.createProfile();
        }
      )
    .catch(
      error => this.registerError = error.message
    );
  }

  createProfile(){
    let record = {};
    record['email'] = this.registerForm.value.email;
    record['name'] = this.registerForm.value.email.split("@", 1)[0];
    record['photoUrl'] = this.getPhotoUrl();
    record['dateJoined'] = this.getDate();

    this.firebaseProfile.createProfile(record).then(resp => {
      // console.log(resp);
    })
      .catch(error => {
        console.log(error);
      });
  }

  // Used in createProfile()
  getPhotoUrl(){
    let photoUrl = [];
    if (this.registerForm.value.gender == "m"){
      photoUrl = ["Person", "boy1.png"];
    } else {
      photoUrl = ["Person", "woman1.png"];
    }
    return photoUrl;
  }

  // Used in createProfile()
  getDate(){
    const monthNames = ["January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
  ];

    var todayDate = new Date();
    var dd = todayDate.getDate();
    var mm = monthNames[todayDate.getMonth()]
    var yyyy = todayDate.getFullYear();

    var date: string = dd + ' ' + mm + ' ' + yyyy;
    return date;
  }
}