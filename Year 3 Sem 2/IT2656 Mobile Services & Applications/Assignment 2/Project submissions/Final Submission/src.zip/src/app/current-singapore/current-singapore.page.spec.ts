import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CurrentSingaporePage } from './current-singapore.page';

describe('CurrentSingaporePage', () => {
  let component: CurrentSingaporePage;
  let fixture: ComponentFixture<CurrentSingaporePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentSingaporePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CurrentSingaporePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
