import { Component } from '@angular/core';

import { Platform, MenuController, ModalController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

// Firebase Import
import * as firebase from 'firebase/app';
import 'firebase/auth';
import { LoginPage } from './login/login.page';

import { AuthService } from './shared/services/auth.service';

// Dark Mode
import { ThemeService } from './shared/services/theme.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  public appPages = [
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    }
  ];

  public appPagesAuthenticated = [
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    },
    {
      title: 'OCR',
      url: '/ocr',
      icon: 'barcode'
    },
    {
      title: 'News',
      url: '/news',
      icon: 'globe'
    },
    {
      title: 'Singapore',
      url: '/current-singapore',
      icon: 'map'
    },
    {
      title: 'Profile',
      url: '/profile',
      icon: 'happy'
    }
  ];

  isDark: boolean = false;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private menuController: MenuController,
    private modalController: ModalController,
    private theme: ThemeService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });

    // Firebase Start
    // Your web app's Firebase configuration
    var firebaseConfig = {
      apiKey: "AIzaSyA-PsJthx7lezW0JjlpFNoJkcUCUl8oJVY",
      authDomain: "staffcorps-ff2bb.firebaseapp.com",
      databaseURL: "https://staffcorps-ff2bb.firebaseio.com",
      projectId: "staffcorps-ff2bb",
      storageBucket: "staffcorps-ff2bb.appspot.com",
      messagingSenderId: "752160426197",
      appId: "1:752160426197:web:c7bc19db09555eec94fa5c",
      measurementId: "G-Q38VE7R22F"
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    AuthService.initialize();
    
    // Firebase Login Status
    firebase.auth().onAuthStateChanged((firebaseUser: firebase.User) => {
      if (firebaseUser) {
        this.menuController.enable(true, 'authenticated');
      } else {
        this.menuController.enable(true, 'unauthenticated');
      }
    });
    // Firebase End
  }

  async login() {
    const modal = await this.modalController.create({
      component: LoginPage
    });
    return await modal.present();
  }

  changeMode(){
    if (this.isDark){
      this.enableLight()
    } else {
      this.enableDark();
    }
    this.isDark = !this.isDark;
  }

  enableDark(){
    this.theme.enableDark();
  }

  enableLight(){
    this.theme.enableLight();
  }
}
