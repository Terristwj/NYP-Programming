export class News {
    url: string;
    urlToImage: string;
    title: string;
    sourceName: string;
    publishedAt: string;

    constructor(
        url: string,
        urlToImage: string,
        title: string,
        sourceName: string,
        publishedAt?: string){
            this.url = url;
            this.urlToImage = urlToImage;
            this.title = title;
            this.sourceName = sourceName;
            this.publishedAt = publishedAt;
    }
}