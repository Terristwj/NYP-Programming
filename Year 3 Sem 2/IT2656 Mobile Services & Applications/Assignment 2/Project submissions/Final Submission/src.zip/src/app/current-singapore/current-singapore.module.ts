import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CurrentSingaporePageRoutingModule } from './current-singapore-routing.module';

import { CurrentSingaporePage } from './current-singapore.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CurrentSingaporePageRoutingModule
  ],
  declarations: [CurrentSingaporePage]
})
export class CurrentSingaporePageModule {}
