import { Injectable } from '@angular/core';
import * as firebase from 'firebase/app';
import 'firebase/firestore';
import { AuthService } from './auth.service';
import { FirestoreCrudService } from './firestore-crud.service';

@Injectable({
  providedIn: 'root'
})
export class FirebaseProfileService {

  constructor(private authService: AuthService
    , private firestoreCrudService: FirestoreCrudService) { }

  getProfile(email){
    return this.firestoreCrudService.read_record("profiles", email);
  }

  createProfile(record){
    return this.firestoreCrudService.create_record("profiles", record);
  }

  updateProfile(record_id, record){
    return this.firestoreCrudService.update_record("profiles", record_id, record);
  }
}
