import { TestBed } from '@angular/core/testing';

import { FirestoreCrudService } from './firestore-crud.service';

describe('FirestoreCrudService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FirestoreCrudService = TestBed.get(FirestoreCrudService);
    expect(service).toBeTruthy();
  });
});
