import { TestBed } from '@angular/core/testing';

import { FirebaseProfileService } from './firebase-profile.service';

describe('FirebaseProfileService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FirebaseProfileService = TestBed.get(FirebaseProfileService);
    expect(service).toBeTruthy();
  });
});
