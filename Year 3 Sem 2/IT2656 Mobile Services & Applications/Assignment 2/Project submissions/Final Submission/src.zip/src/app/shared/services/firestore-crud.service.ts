import { Injectable } from '@angular/core';

import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirestoreCrudService {

  constructor(
    private firestore: AngularFirestore
  ) { }

  create_record(collection, record) {
    return this.firestore.collection(collection).add(record);
  }

  read_record(collection, email) {
    // this.firestore.collection(collection).where('user', '==', user.email)
    return this.firestore.collection(collection
      , ref=>ref.where('email', '==', email)
    ).snapshotChanges();
  }

  update_record(collection, record_id, record){
    this.firestore.doc(collection + "/" + record_id).update(record);
  }

  delete_record(collection, record_id) {
    this.firestore.doc(collection + "/" + record_id).delete();
  }
}
