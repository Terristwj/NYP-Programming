import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import { storage } from 'firebase';
import { ToastController } from '@ionic/angular';

export interface MyData {
  name: string;
  filepath: string;
  size: number;
}

@Component({
  selector: 'app-ocr',
  templateUrl: './ocr.page.html',
  styleUrls: ['./ocr.page.scss'],
})

export class OcrPage implements OnInit {
  // File handlers
  file: any;
  file_base64: string;

  // Validation handlers
  fileGiven: boolean = false;
  isLoading: boolean = false;
  hasText: boolean = false;

  constructor(public httpClient: HttpClient
    ,private toastController: ToastController) { 
  }

  ngOnInit() {
  }

//   
//  Part 1
// 
// 
// 
// 
// 
// 
// 

  
  // Step 1: Add image
  call_fileInput(){
    var fileObject = document.getElementById("fileInput");

    // Step 2: Click invisible file object
    fileObject.click();
  }

  // Step 3: Replace image placeholder
  readURL($event){
    // Get image file
    this.file = $event.target.files[0];

    // Get image preview
    var preview = document.getElementById('imagePreview');
  
    // Check if there is a file
    if (this.file) {
      this.fileGiven = true;
    } 
    else {
      this.fileGiven = false;
    }


    // Confirmed
    if (this.fileGiven){
      // Create a reader
      var reader  = new FileReader();
  
      // Perform reader action (1)
      reader.onloadend = function () {
        preview.setAttribute("src", reader.result.toString())
      }
      
      // Perform reader action (2)
      reader.readAsDataURL(this.file);

      // Remove hidden class, if already have
      if (preview.classList.contains("hidden_visibility")){
        preview.classList.remove("hidden_visibility");
      }
    } else {
      // Add hidden class, if don't have
      if (!preview.classList.contains("hidden_visibility")){
        preview.classList.add("hidden_visibility");

        // Reset src (For 2nd attempt)
        preview.setAttribute("src", "");
      }
    }
  }


//   
//  Part 2.1
// 
// 
// 
// 
// 
// 
// 

  // Convert button
  async performOCR(){
    this.save_filebase64();

    //  How it works:
    //  'picture' is the filepath and name inside Firebase Storage
    //  Eg. 'pictures/myPhoto' => inside folder 'pictures', titled 'myPhoto'

    // initialize Firebase Storage settings
    const firebaseStorage_imagePath = storage().ref('picture');

    // Save to Firebase Storage
    this.saveTo_FirebaseStorage(firebaseStorage_imagePath);

    // Retrieve downloadUrl from Firebase Storage
    var imageUrl = this.retrieveFrom_FirebaseStorage(firebaseStorage_imagePath);
    
    // Debugging
    // this.debug_imageUrl(imageUrl);

    // Move to Part 2.2
    this.toggle_loadingAPI(true);

    var sizeInKb = this.getFileSize();
    if (sizeInKb <= 1024){
      // SetTimeour because to wait for FirebaseStorage to finish uploading
      setTimeout( () => { this.retrieveText(imageUrl) }, 5000 );
    } else {
      this.retrieveText_fail();
    }
    // this.retrieveText(imageUrl);
  }

  save_filebase64(){
    // Get image preview
    var preview = document.getElementById('imagePreview');
    // Create a reader
    var reader  = new FileReader();
    // Extract raw file_base64
    this.file_base64 = preview.getAttribute("src");
  }

  saveTo_FirebaseStorage(path){
    path.putString(this.file_base64, 'data_url');
  }

  retrieveFrom_FirebaseStorage(path){
    // var downloadUrl = path.getDownloadURL();
    var downloadUrl = "https://firebasestorage.googleapis.com/v0/b/staffcorps-ff2bb.appspot.com/o/picture?alt=media";
    return downloadUrl;
  }

  debug_imageUrl(imageUrl){
    console.log(imageUrl);
    console.log(typeof imageUrl);
    console.log(imageUrl.c.c);
    console.log(Object.keys(imageUrl.c));
  }

//   
//  Part 2.2
// 
// 
// 
// 
// 
// 
// 

retrieveText_fail(){
  this.retrieveText("#");
}
  
retrieveText(imageUrl){
  // API website:
  // https://ocr.space/OCRAPI

  // Free tier: File limit = 1024KB.
  
  // API Settings
  var apiKey = "efa3047e0888957";
  // Not inuse
  var apiKeyFree = "helloworld"

  // HTTP GET url
  var httpUrl = "https://api.ocr.space/parse/imageurl?apikey=" + apiKey + "&url=" + imageUrl;
  
  // Call HTTP GET
  this.httpClient.get(httpUrl).subscribe(data => {
    // console.log('my data: ', data);
    // console.log(final_data);
    // console.log(final_data.ParsedResults[0].ParsedText);

    // HTTP data
    var final_data: any = data;

    // Display retrieved text
    var result = document.getElementById("api_data");

    // Free tier: File limit = 1024KB.
    // Error => (file size > 1024KB)
    try{
      // Display result
      result.innerText = final_data.ParsedResults[0].ParsedText;
      
      // Disable COPY when result = ""
      if (final_data.ParsedResults[0].ParsedText != ""){
        this.hasText = true;
        // Inform user
        this.toggle_toastBox(false, "Image translated");
      } else {
        this.hasText = false;
        // Inform user
        this.toggle_toastBox(true, "Could not identify any text");
      }

    } catch {
      // console.log(final_data.ErrorMessage);
      var sizeInKb = this.getFileSize();

      var message = "The image uploaded exceeds 1024KB file size. ";
      message += "File size: " + sizeInKb.toString() + "KB. ";
      message += "Please use a smaller image.";

      // Display error message
      result.innerText = message;
      
      // Disable copy because error
      this.hasText = false;

      // Inform user
      this.toggle_toastBox(true, "Image file size exceeds 1024KB");
    }

    this.toggle_loadingAPI(false);
    
    // Known Bugs (Solved):
    // API Bug -> If image file size is > 1025KB, API rejects
    // Possible API Bug -> Firebase Storage uploads too slow, and program has already called OCR API
  })
}

toggle_loadingAPI(isLoading: boolean){
  var preview = document.getElementById('imagePreview');

  if (isLoading){
    // Add loading spinner
    this.isLoading = true;
    // Remove image preview
    preview.classList.add("none_display");
  } else {
    // Remove loading spinner
    this.isLoading = false;
    // Add image preview
    preview.classList.remove("none_display");
  }
}

getFileSize(){
  var stringLength = this.file_base64.length - 'data:image/png;base64,'.length;
  var sizeInBytes = 4 * Math.ceil((stringLength / 3))*0.5624896334383812;
  var sizeInKb = Math.round(sizeInBytes/1000);
  return sizeInKb;
}

async toggle_toastBox(isError, message){
  var toastMsg = message;
  var toastColor = "secondary";
  if (isError){
    toastColor = "danger";
  }
  const toast = await this.toastController.create({
    message: toastMsg,
    duration: 3000,
    position: 'top',
    color: toastColor
  });
  toast.present();
}

//   
//  Part 3
// 
// 
// 
// 
// 
// 
// 

// Copy text
  async copyToClipboard(){
    var copiedText = document.getElementById("api_data") as HTMLInputElement;
    copiedText.select();
    document.execCommand("copy");

    // console.log("Copied text: \n" + copiedText.innerHTML)
    this.toggle_toastBox(false, "Copied to clipboard");
  }
}
