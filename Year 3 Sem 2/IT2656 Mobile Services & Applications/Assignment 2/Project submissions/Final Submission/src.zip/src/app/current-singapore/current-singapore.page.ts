import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-singapore',
  templateUrl: './current-singapore.page.html',
  styleUrls: ['./current-singapore.page.scss'],
})
export class CurrentSingaporePage implements OnInit {
  // Variables
  iframe_weather: string;
  iframe_traffic: string;
  iframe_condition: string;

  constructor() { }

  ngOnInit() {
    // From https://data.gov.sg/developer
    this.iframe_weather = "https://data.gov.sg/dataset/weather-forecast/resource/571ef5fb-ed31-48b2-85c9-61677de42ca9/view/4c127d9a-cba6-445a-8fc1-978b565f9bf7";
    this.iframe_traffic = "https://data.gov.sg/dataset/traffic-images/resource/e127e29a-bd48-47e2-a0a7-e89ce31f10c7/view/39ba8de0-6242-40d3-8664-793316c47b09";
  
    // Onload, weather is checked
    this.iframe_condition = "weather";
  }

  segmentChange(condition){
    this.iframe_condition = condition;
  }
}
